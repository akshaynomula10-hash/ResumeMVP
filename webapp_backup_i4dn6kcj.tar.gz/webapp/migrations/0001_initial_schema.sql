-- ============================================================
-- JobMatch AI - Database Schema
-- ============================================================

-- Skills table (canonical skill dictionary)
CREATE TABLE IF NOT EXISTS skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    canonical_name TEXT NOT NULL UNIQUE,
    category TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Students table
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    phone TEXT,
    location_city TEXT,
    location_state TEXT,
    willing_to_relocate INTEGER DEFAULT 0,
    remote_preference TEXT DEFAULT 'any',
    education_level TEXT,
    degree TEXT,
    university TEXT,
    graduation_year INTEGER,
    gpa REAL,
    work_auth_status TEXT,
    visa_sponsor_needed INTEGER DEFAULT 0,
    total_years_exp REAL DEFAULT 0,
    experience_json TEXT,
    projects_json TEXT,
    certifications_json TEXT,
    preferred_roles TEXT,
    preferred_locations TEXT,
    salary_expectation INTEGER,
    summary_text TEXT,
    resume_raw_text TEXT,
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

-- Student skills (many-to-many)
CREATE TABLE IF NOT EXISTS student_skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    skill_id INTEGER NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    proficiency TEXT DEFAULT 'intermediate',
    years_experience REAL,
    is_primary INTEGER DEFAULT 0,
    UNIQUE(student_id, skill_id)
);

-- Jobs table
CREATE TABLE IF NOT EXISTS jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    external_id TEXT,
    source TEXT NOT NULL DEFAULT 'manual',
    source_url TEXT,
    title TEXT NOT NULL,
    title_normalized TEXT,
    company TEXT NOT NULL,
    company_url TEXT,
    location_city TEXT,
    location_state TEXT,
    remote_type TEXT DEFAULT 'unknown',
    description TEXT NOT NULL,
    requirements TEXT,
    responsibilities TEXT,
    benefits TEXT,
    experience_min INTEGER,
    experience_max INTEGER,
    education_req TEXT,
    salary_min INTEGER,
    salary_max INTEGER,
    job_type TEXT DEFAULT 'full_time',
    seniority_level TEXT,
    visa_sponsored INTEGER,
    apply_url TEXT NOT NULL,
    extracted_skills TEXT,
    ats_keywords TEXT,
    fingerprint TEXT,
    status TEXT DEFAULT 'active',
    posted_at TEXT,
    scraped_at TEXT DEFAULT (datetime('now')),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_company ON jobs(company);
CREATE INDEX IF NOT EXISTS idx_jobs_source ON jobs(source);
CREATE INDEX IF NOT EXISTS idx_jobs_fingerprint ON jobs(fingerprint);

-- Job skills (many-to-many)
CREATE TABLE IF NOT EXISTS job_skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    skill_id INTEGER NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    importance TEXT DEFAULT 'required',
    UNIQUE(job_id, skill_id)
);

-- Matches table
CREATE TABLE IF NOT EXISTS matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    overall_score REAL NOT NULL,
    skill_score REAL DEFAULT 0,
    experience_score REAL DEFAULT 0,
    education_score REAL DEFAULT 0,
    semantic_score REAL DEFAULT 0,
    location_score REAL DEFAULT 0,
    matched_skills TEXT,
    missing_skills TEXT,
    match_reasons TEXT,
    status TEXT DEFAULT 'new',
    computed_at TEXT DEFAULT (datetime('now')),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    UNIQUE(student_id, job_id)
);

CREATE INDEX IF NOT EXISTS idx_matches_student ON matches(student_id);
CREATE INDEX IF NOT EXISTS idx_matches_score ON matches(overall_score DESC);

-- Resumes table
CREATE TABLE IF NOT EXISTS resumes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id INTEGER REFERENCES matches(id) ON DELETE SET NULL,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    content_json TEXT NOT NULL,
    ats_keywords TEXT,
    ats_score_estimate INTEGER,
    pdf_url TEXT,
    version INTEGER DEFAULT 1,
    generation_model TEXT DEFAULT 'built-in',
    status TEXT DEFAULT 'generated',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_resumes_student ON resumes(student_id);
CREATE INDEX IF NOT EXISTS idx_resumes_match ON resumes(match_id);

-- Scrape logs
CREATE TABLE IF NOT EXISTS scrape_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL,
    status TEXT,
    jobs_found INTEGER DEFAULT 0,
    jobs_new INTEGER DEFAULT 0,
    jobs_duplicated INTEGER DEFAULT 0,
    error_message TEXT,
    duration_ms INTEGER,
    started_at TEXT DEFAULT (datetime('now')),
    completed_at TEXT
);
