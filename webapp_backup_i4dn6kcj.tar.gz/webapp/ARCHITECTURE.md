# JobMatch AI - Complete System Architecture

## Production-Ready Job Matching & ATS Resume Generation Platform

---

# STEP 1 - SYSTEM ARCHITECTURE

## 1.1 High-Level Architecture Overview

```
+----------------------------------------------------------------------+
|                        CLIENT LAYER                                   |
|  +------------------+  +------------------+  +--------------------+   |
|  |  Next.js SSR     |  |  React SPA       |  |  Mobile PWA        |   |
|  |  (Dashboard)     |  |  (Student Portal) |  |  (Future)          |   |
|  +--------+---------+  +--------+---------+  +---------+----------+   |
|           |                      |                      |             |
+----------------------------------------------------------------------+
            |                      |                      |
            v                      v                      v
+----------------------------------------------------------------------+
|                      API GATEWAY / LOAD BALANCER                      |
|  +----------------------------------------------------------------+  |
|  |  Nginx / AWS ALB / Cloudflare Workers                          |  |
|  |  - Rate Limiting (100 req/min per user)                        |  |
|  |  - JWT Validation                                              |  |
|  |  - Request Routing                                             |  |
|  |  - SSL Termination                                             |  |
|  +----------------------------------------------------------------+  |
+----------------------------------------------------------------------+
            |
            v
+----------------------------------------------------------------------+
|                      APPLICATION LAYER                                |
|                                                                      |
|  +------------------+  +------------------+  +--------------------+  |
|  |  Auth Service     |  |  Student Service |  |  Job Service       |  |
|  |  (FastAPI)        |  |  (FastAPI)       |  |  (FastAPI)         |  |
|  |  - JWT tokens     |  |  - CRUD profiles |  |  - CRUD jobs       |  |
|  |  - OAuth2         |  |  - Skill mgmt    |  |  - Search/Filter   |  |
|  |  - RBAC           |  |  - Preferences   |  |  - Deduplication   |  |
|  +------------------+  +------------------+  +--------------------+  |
|                                                                      |
|  +------------------+  +------------------+  +--------------------+  |
|  |  Matching Engine  |  |  Resume Service  |  |  Scraper Orchest.  |  |
|  |  (FastAPI)        |  |  (FastAPI)       |  |  (Celery Worker)   |  |
|  |  - Skill match    |  |  - LLM generate  |  |  - Job crawlers    |  |
|  |  - Semantic sim.  |  |  - PDF render    |  |  - Normalizer      |  |
|  |  - Scoring algo   |  |  - Template mgmt |  |  - Deduplicator    |  |
|  +------------------+  +------------------+  +--------------------+  |
+----------------------------------------------------------------------+
            |                      |                      |
            v                      v                      v
+----------------------------------------------------------------------+
|                      DATA & AI LAYER                                  |
|                                                                      |
|  +------------------+  +------------------+  +--------------------+  |
|  |  PostgreSQL       |  |  Redis           |  |  S3 / R2           |  |
|  |  + pgvector       |  |  - Job cache     |  |  - Resume PDFs     |  |
|  |  - All tables     |  |  - Session store |  |  - Scraped data    |  |
|  |  - Vector embeds  |  |  - Rate limits   |  |  - Backups         |  |
|  |  - Full-text idx  |  |  - Task queue    |  |                    |  |
|  +------------------+  +------------------+  +--------------------+  |
|                                                                      |
|  +------------------+  +------------------+  +--------------------+  |
|  |  OpenAI API       |  |  Celery + Beat   |  |  Elasticsearch     |  |
|  |  - GPT-4 resume   |  |  - Cron scrapers |  |  (Optional)        |  |
|  |  - Embeddings     |  |  - Match batches |  |  - Job search      |  |
|  |  - Skill extract  |  |  - Resume gen    |  |  - Faceted filter  |  |
|  +------------------+  +------------------+  +--------------------+  |
+----------------------------------------------------------------------+
```

## 1.2 Service Communication Flow

```
[User Request] --> [API Gateway]
                      |
                      +--> [Auth Service] --> JWT validation
                      |
                      +--> [Student Service] --> PostgreSQL
                      |
                      +--> [Job Service] --> PostgreSQL + Redis cache
                      |
                      +--> [Matching Engine]
                      |        |
                      |        +--> PostgreSQL (profile + job data)
                      |        +--> pgvector (semantic similarity)
                      |        +--> OpenAI (embedding generation)
                      |        +--> Redis (cached match scores)
                      |
                      +--> [Resume Service]
                               |
                               +--> OpenAI GPT-4 (content generation)
                               +--> PDF renderer (WeasyPrint/Puppeteer)
                               +--> S3 (PDF storage)

[Celery Beat Scheduler]
    |
    +--> Every 6 hours: Run job scrapers
    +--> Every 1 hour:  Deduplicate new jobs
    +--> Every 12 hours: Re-compute match scores
    +--> Every 24 hours: Clean expired jobs
```

## 1.3 Key Architecture Decisions

| Decision | Choice | Reasoning |
|----------|--------|-----------|
| Backend Framework | FastAPI (Python) | Async support, type safety, OpenAPI docs, ML ecosystem |
| Database | PostgreSQL + pgvector | Relational data + vector search in one DB |
| Task Queue | Celery + Redis | Battle-tested, supports cron, scales horizontally |
| AI Provider | OpenAI API | Best embedding quality, GPT-4 for resume generation |
| PDF Generation | WeasyPrint | CSS-based, server-side, no browser dependency |
| Frontend | Next.js + React | SSR for SEO, React ecosystem, Vercel deployment |
| Caching | Redis | In-memory speed, pub/sub capability, session store |
| Object Storage | S3/R2 | Cheap, durable, CDN-compatible for PDFs |
| Deployment | Docker + AWS ECS | Containerized, auto-scaling, managed infrastructure |

---

# STEP 2 - DATABASE DESIGN

## 2.1 Entity-Relationship Diagram

```
+------------------+       +------------------+       +------------------+
|    students      |       |  student_skills  |       |     skills       |
+------------------+       +------------------+       +------------------+
| id (PK)          |<----->| student_id (FK)  |<----->| id (PK)          |
| email (UNIQUE)   |       | skill_id (FK)    |       | name (UNIQUE)    |
| full_name        |       | proficiency      |       | category         |
| phone            |       | years_exp        |       | embedding (vec)  |
| location_city    |       +------------------+       +------------------+
| location_state   |                                         ^
| education_level  |                                         |
| degree           |       +------------------+              |
| university       |       |   job_skills     |              |
| gpa              |       +------------------+              |
| work_auth_status |       | job_id (FK)      |--------------+
| preferred_roles  |       | skill_id (FK)    |
| summary          |       | importance       |
| resume_text      |       | required         |
| embedding (vec)  |       +------------------+
| created_at       |              ^
| updated_at       |              |
+------------------+       +------+----------+
       |                   |      jobs        |
       |                   +------------------+
       |                   | id (PK)          |
       |                   | external_id      |
       |                   | source           |
       |                   | title            |
       |                   | company          |
       |                   | location_city    |
       |                   | location_state   |
       |                   | remote_type      |
       |                   | description      |
       |                   | requirements     |
       |                   | salary_min       |
       |                   | salary_max       |
       |                   | experience_min   |
       |                   | experience_max   |
       |                   | education_req    |
       |                   | apply_url        |
       |                   | embedding (vec)  |
       |                   | status           |
       |                   | posted_at        |
       |                   | scraped_at       |
       |                   | expires_at       |
       |                   | created_at       |
       |                   +------------------+
       |                          |
       v                          v
+------+--------------------------+------+
|           matches                      |
+----------------------------------------+
| id (PK)                                |
| student_id (FK)                        |
| job_id (FK)                            |
| overall_score (0-100)                  |
| skill_score (0-100)                    |
| experience_score (0-100)               |
| education_score (0-100)                |
| semantic_score (0-100)                 |
| location_score (0-100)                 |
| match_reasons (JSONB)                  |
| status (new/viewed/applied/rejected)   |
| created_at                             |
| updated_at                             |
+--------------------+-------------------+
                     |
                     v
+----------------------------------------+
|           resumes                      |
+----------------------------------------+
| id (PK)                                |
| match_id (FK)                          |
| student_id (FK)                        |
| job_id (FK)                            |
| content_json (JSONB)                   |
| summary_text                           |
| skills_highlighted (JSONB)             |
| ats_keywords (JSONB)                   |
| pdf_url                                |
| version                                |
| generation_model                       |
| created_at                             |
+----------------------------------------+
```

## 2.2 Complete SQL Schema

```sql
-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ============================================================
-- SKILLS TABLE (Canonical skill dictionary)
-- ============================================================
CREATE TABLE skills (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(200) NOT NULL,
    canonical_name  VARCHAR(200) NOT NULL,  -- Normalized: "javascript" not "JavaScript"
    category        VARCHAR(100),           -- "programming", "framework", "soft_skill", etc.
    subcategory     VARCHAR(100),
    aliases         TEXT[],                 -- {"JS", "Javascript", "ECMAScript"}
    embedding       vector(1536),           -- OpenAI ada-002 embedding
    created_at      TIMESTAMPTZ DEFAULT NOW(),

    CONSTRAINT uq_skills_canonical UNIQUE (canonical_name)
);

CREATE INDEX idx_skills_category ON skills(category);
CREATE INDEX idx_skills_embedding ON skills USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
CREATE INDEX idx_skills_name_trgm ON skills USING gin (name gin_trgm_ops);

-- ============================================================
-- STUDENTS TABLE
-- ============================================================
CREATE TABLE students (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email               VARCHAR(255) NOT NULL UNIQUE,
    password_hash       VARCHAR(255),
    full_name           VARCHAR(255) NOT NULL,
    phone               VARCHAR(20),
    location_city       VARCHAR(100),
    location_state      VARCHAR(50),
    location_country    VARCHAR(50) DEFAULT 'US',
    willing_to_relocate BOOLEAN DEFAULT FALSE,
    remote_preference   VARCHAR(20) CHECK (remote_preference IN ('remote', 'hybrid', 'onsite', 'any')),

    -- Education
    education_level     VARCHAR(50),  -- "bachelors", "masters", "phd", "associate", "bootcamp"
    degree              VARCHAR(200), -- "Computer Science", "Data Science"
    university          VARCHAR(255),
    graduation_year     INTEGER,
    gpa                 DECIMAL(3,2),

    -- Work authorization
    work_auth_status    VARCHAR(50),  -- "us_citizen", "green_card", "h1b", "opt", "cpt", "ead"
    visa_sponsor_needed BOOLEAN DEFAULT FALSE,

    -- Experience
    total_years_exp     DECIMAL(4,1) DEFAULT 0,
    experience_json     JSONB,        -- Array of work experiences
    projects_json       JSONB,        -- Array of projects
    certifications_json JSONB,        -- Array of certifications
    
    -- Preferences
    preferred_roles     TEXT[],       -- {"Software Engineer", "Backend Developer"}
    preferred_locations TEXT[],       -- {"San Francisco, CA", "Remote"}
    salary_expectation  INTEGER,
    job_type_pref       VARCHAR(20) CHECK (job_type_pref IN ('full_time', 'part_time', 'contract', 'internship', 'any')),

    -- AI fields
    summary_text        TEXT,         -- AI-generated or manual summary
    resume_raw_text     TEXT,         -- Original uploaded resume text
    embedding           vector(1536), -- Profile embedding for semantic matching

    -- Metadata
    is_active           BOOLEAN DEFAULT TRUE,
    last_login_at       TIMESTAMPTZ,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_students_email ON students(email);
CREATE INDEX idx_students_location ON students(location_state, location_city);
CREATE INDEX idx_students_education ON students(education_level, degree);
CREATE INDEX idx_students_embedding ON students USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
CREATE INDEX idx_students_active ON students(is_active) WHERE is_active = TRUE;

-- ============================================================
-- STUDENT_SKILLS TABLE (Many-to-Many)
-- ============================================================
CREATE TABLE student_skills (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id      UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    skill_id        UUID NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    proficiency     VARCHAR(20) CHECK (proficiency IN ('beginner', 'intermediate', 'advanced', 'expert')),
    years_experience DECIMAL(4,1),
    is_primary      BOOLEAN DEFAULT FALSE,  -- Top skills to highlight
    source          VARCHAR(20) DEFAULT 'manual',  -- "manual", "parsed", "ai_extracted"
    created_at      TIMESTAMPTZ DEFAULT NOW(),

    CONSTRAINT uq_student_skill UNIQUE (student_id, skill_id)
);

CREATE INDEX idx_student_skills_student ON student_skills(student_id);
CREATE INDEX idx_student_skills_skill ON student_skills(skill_id);

-- ============================================================
-- JOBS TABLE
-- ============================================================
CREATE TABLE jobs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    external_id     VARCHAR(255),       -- ID from source platform
    source          VARCHAR(50) NOT NULL, -- "linkedin", "indeed", "greenhouse", "lever", "manual"
    source_url      VARCHAR(2048),      -- Original listing URL

    -- Core fields
    title           VARCHAR(500) NOT NULL,
    title_normalized VARCHAR(200),      -- Cleaned: "Senior Software Engineer"
    company         VARCHAR(255) NOT NULL,
    company_url     VARCHAR(2048),

    -- Location
    location_city   VARCHAR(100),
    location_state  VARCHAR(50),
    location_country VARCHAR(50) DEFAULT 'US',
    remote_type     VARCHAR(20) CHECK (remote_type IN ('remote', 'hybrid', 'onsite', 'unknown')),

    -- Description
    description     TEXT NOT NULL,
    requirements    TEXT,
    responsibilities TEXT,
    benefits        TEXT,

    -- Qualifications
    experience_min  INTEGER,           -- Minimum years
    experience_max  INTEGER,
    education_req   VARCHAR(50),       -- "bachelors", "masters", etc.
    
    -- Compensation
    salary_min      INTEGER,
    salary_max      INTEGER,
    salary_currency VARCHAR(3) DEFAULT 'USD',
    salary_period   VARCHAR(20) DEFAULT 'yearly',

    -- Job metadata
    job_type        VARCHAR(20) CHECK (job_type IN ('full_time', 'part_time', 'contract', 'internship')),
    seniority_level VARCHAR(20),       -- "entry", "mid", "senior", "lead", "staff", "principal"
    visa_sponsored  BOOLEAN,
    apply_url       VARCHAR(2048) NOT NULL,

    -- AI fields
    extracted_skills JSONB,            -- AI-extracted skills from description
    embedding        vector(1536),     -- Job description embedding
    ats_keywords     TEXT[],           -- Extracted ATS keywords

    -- Deduplication
    fingerprint     VARCHAR(64),       -- SHA256 hash for dedup
    
    -- Status
    status          VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'expired', 'closed', 'flagged')),
    posted_at       TIMESTAMPTZ,
    scraped_at      TIMESTAMPTZ DEFAULT NOW(),
    expires_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_jobs_source ON jobs(source);
CREATE INDEX idx_jobs_company ON jobs(company);
CREATE INDEX idx_jobs_location ON jobs(location_state, location_city);
CREATE INDEX idx_jobs_status ON jobs(status) WHERE status = 'active';
CREATE INDEX idx_jobs_fingerprint ON jobs(fingerprint);
CREATE INDEX idx_jobs_external ON jobs(source, external_id);
CREATE INDEX idx_jobs_embedding ON jobs USING ivfflat (embedding vector_cosine_ops) WITH (lists = 200);
CREATE INDEX idx_jobs_title_trgm ON jobs USING gin (title gin_trgm_ops);
CREATE INDEX idx_jobs_description_trgm ON jobs USING gin (description gin_trgm_ops);
CREATE INDEX idx_jobs_posted ON jobs(posted_at DESC);

-- ============================================================
-- JOB_SKILLS TABLE (Many-to-Many)
-- ============================================================
CREATE TABLE job_skills (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id      UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    skill_id    UUID NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    importance  VARCHAR(20) CHECK (importance IN ('required', 'preferred', 'nice_to_have')),
    mentioned_count INTEGER DEFAULT 1,
    source      VARCHAR(20) DEFAULT 'ai_extracted',
    created_at  TIMESTAMPTZ DEFAULT NOW(),

    CONSTRAINT uq_job_skill UNIQUE (job_id, skill_id)
);

CREATE INDEX idx_job_skills_job ON job_skills(job_id);
CREATE INDEX idx_job_skills_skill ON job_skills(skill_id);
CREATE INDEX idx_job_skills_importance ON job_skills(importance);

-- ============================================================
-- MATCHES TABLE
-- ============================================================
CREATE TABLE matches (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id      UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    job_id          UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,

    -- Composite scores (0-100)
    overall_score   DECIMAL(5,2) NOT NULL,
    skill_score     DECIMAL(5,2) DEFAULT 0,
    experience_score DECIMAL(5,2) DEFAULT 0,
    education_score DECIMAL(5,2) DEFAULT 0,
    semantic_score  DECIMAL(5,2) DEFAULT 0,
    location_score  DECIMAL(5,2) DEFAULT 0,

    -- Detailed breakdown
    matched_skills  JSONB,   -- Skills that matched
    missing_skills  JSONB,   -- Skills the student lacks
    match_reasons   JSONB,   -- Explanation of scoring
    recommendations JSONB,   -- Tips to improve match

    -- Score weights used
    weights_used    JSONB DEFAULT '{"skill":0.35,"experience":0.20,"education":0.10,"semantic":0.25,"location":0.10}',

    -- Status tracking
    status          VARCHAR(20) DEFAULT 'new' CHECK (status IN ('new', 'viewed', 'saved', 'applied', 'rejected', 'expired')),
    
    -- Metadata
    algorithm_version VARCHAR(20) DEFAULT 'v1.0',
    computed_at     TIMESTAMPTZ DEFAULT NOW(),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),

    CONSTRAINT uq_student_job_match UNIQUE (student_id, job_id)
);

CREATE INDEX idx_matches_student ON matches(student_id);
CREATE INDEX idx_matches_job ON matches(job_id);
CREATE INDEX idx_matches_score ON matches(overall_score DESC);
CREATE INDEX idx_matches_status ON matches(status);
CREATE INDEX idx_matches_student_score ON matches(student_id, overall_score DESC);

-- ============================================================
-- RESUMES TABLE
-- ============================================================
CREATE TABLE resumes (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    match_id            UUID REFERENCES matches(id) ON DELETE SET NULL,
    student_id          UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    job_id              UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,

    -- Generated content (structured)
    content_json        JSONB NOT NULL,
    /*
    content_json structure:
    {
        "header": { "name", "email", "phone", "location", "linkedin", "portfolio" },
        "summary": "Tailored professional summary...",
        "skills": { "technical": [...], "tools": [...], "soft_skills": [...] },
        "experience": [
            { "title", "company", "dates", "bullets": [...] }
        ],
        "projects": [
            { "name", "description", "technologies": [...], "bullets": [...] }
        ],
        "education": [
            { "degree", "university", "year", "gpa", "relevant_courses": [...] }
        ],
        "certifications": [
            { "name", "issuer", "date" }
        ]
    }
    */

    -- ATS Optimization
    ats_keywords        TEXT[],         -- Keywords injected for ATS
    ats_score_estimate  INTEGER,        -- Estimated ATS compatibility (0-100)
    keyword_density     JSONB,          -- { "python": 5, "aws": 3 }
    
    -- Output
    pdf_url             VARCHAR(2048),  -- S3/R2 URL to generated PDF
    pdf_size_bytes      INTEGER,
    
    -- Generation metadata
    generation_model    VARCHAR(50) DEFAULT 'gpt-4',
    prompt_tokens       INTEGER,
    completion_tokens   INTEGER,
    generation_time_ms  INTEGER,
    version             INTEGER DEFAULT 1,
    
    -- Status
    status              VARCHAR(20) DEFAULT 'generated' CHECK (status IN ('generating', 'generated', 'failed', 'archived')),
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_resumes_student ON resumes(student_id);
CREATE INDEX idx_resumes_job ON resumes(job_id);
CREATE INDEX idx_resumes_match ON resumes(match_id);
CREATE INDEX idx_resumes_student_job ON resumes(student_id, job_id);

-- ============================================================
-- SCRAPE_LOGS TABLE (Operational tracking)
-- ============================================================
CREATE TABLE scrape_logs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source          VARCHAR(50) NOT NULL,
    status          VARCHAR(20) CHECK (status IN ('running', 'completed', 'failed', 'partial')),
    jobs_found      INTEGER DEFAULT 0,
    jobs_new        INTEGER DEFAULT 0,
    jobs_updated    INTEGER DEFAULT 0,
    jobs_duplicated INTEGER DEFAULT 0,
    error_message   TEXT,
    duration_ms     INTEGER,
    started_at      TIMESTAMPTZ DEFAULT NOW(),
    completed_at    TIMESTAMPTZ
);

CREATE INDEX idx_scrape_logs_source ON scrape_logs(source, started_at DESC);

-- ============================================================
-- VIEWS for common queries
-- ============================================================
CREATE OR REPLACE VIEW v_student_matches AS
SELECT
    m.id as match_id,
    s.full_name as student_name,
    s.email as student_email,
    j.title as job_title,
    j.company,
    j.location_city,
    j.location_state,
    j.remote_type,
    j.apply_url,
    m.overall_score,
    m.skill_score,
    m.experience_score,
    m.education_score,
    m.semantic_score,
    m.matched_skills,
    m.missing_skills,
    m.status as match_status,
    r.pdf_url as resume_pdf_url,
    r.ats_score_estimate,
    m.created_at
FROM matches m
JOIN students s ON m.student_id = s.id
JOIN jobs j ON m.job_id = j.id
LEFT JOIN resumes r ON r.match_id = m.id AND r.version = (
    SELECT MAX(version) FROM resumes WHERE match_id = m.id
)
WHERE j.status = 'active'
ORDER BY m.overall_score DESC;
```

---

# STEP 3 - JOB SCRAPER DESIGN

## 3.1 Architecture

```
                   +-------------------+
                   |   Celery Beat     |
                   |   (Scheduler)     |
                   +--------+----------+
                            |
                            | Triggers every 6h
                            v
+----------------------------------------------------------+
|               Scraper Orchestrator                         |
|  +------------------------------------------------------+ |
|  | 1. Determine which sources to scrape                  | |
|  | 2. Check rate limits per source                       | |
|  | 3. Dispatch individual scraper tasks                  | |
|  | 4. Collect results                                    | |
|  | 5. Log scrape metrics                                 | |
|  +------------------------------------------------------+ |
+----------------------------------------------------------+
          |            |            |            |
          v            v            v            v
+----------+  +--------+  +--------+  +----------+
| LinkedIn |  | Indeed  |  | Green- |  | Lever    |
| Scraper  |  | Scraper |  | house  |  | Scraper  |
|          |  |         |  | Scraper|  |          |
+----+-----+  +----+----+  +---+----+  +----+-----+
     |              |            |            |
     v              v            v            v
+----------------------------------------------------------+
|               Raw Job Processor Pipeline                   |
|                                                            |
|  1. [Parse & Extract Fields]                               |
|     - Title, Company, Location, Description                |
|     - Salary, Experience requirements                      |
|                                                            |
|  2. [Normalize]                                            |
|     - Standardize location (city, state)                   |
|     - Normalize title ("Sr." -> "Senior")                  |
|     - Parse salary ranges                                  |
|     - Classify remote_type                                 |
|                                                            |
|  3. [Deduplicate]                                          |
|     - Generate fingerprint: SHA256(company + title_norm +  |
|       location_state + first_200_chars_description)        |
|     - Check existing fingerprints                          |
|     - Update if exists, insert if new                      |
|                                                            |
|  4. [AI Enrichment]                                        |
|     - Extract skills via GPT-4                             |
|     - Generate embedding via text-embedding-ada-002        |
|     - Extract ATS keywords                                 |
|     - Classify seniority level                             |
|                                                            |
|  5. [Store]                                                |
|     - Insert into PostgreSQL                               |
|     - Link skills in job_skills table                      |
|     - Update scrape_logs                                   |
+----------------------------------------------------------+
```

## 3.2 Scraper Strategy Per Source

| Source | Method | Rate Limit | Notes |
|--------|--------|------------|-------|
| LinkedIn | LinkedIn Jobs API / RapidAPI proxy | 100 req/day | Use official API or authorized data partner |
| Indeed | Indeed Publisher API | 500 req/day | Requires publisher account |
| Greenhouse | Public Greenhouse Board API | 1000 req/hour | `https://boards-api.greenhouse.io/v1/boards/{company}/jobs` |
| Lever | Public Lever API | 500 req/hour | `https://api.lever.co/v0/postings/{company}` |
| Company Pages | Playwright headless browser | Varies | Respect robots.txt, use rotating proxies |
| Public APIs | USA Jobs API, GitHub Jobs | Per API limits | Free government job data |

## 3.3 Deduplication Algorithm

```python
def generate_fingerprint(job: dict) -> str:
    """Generate a unique fingerprint for deduplication."""
    normalized = (
        normalize_company(job['company']).lower() +
        normalize_title(job['title']).lower() +
        (job.get('location_state', '') or '').lower() +
        (job.get('description', '')[:200] or '').lower()
    )
    return hashlib.sha256(normalized.encode()).hexdigest()

def deduplicate(new_job: dict) -> str:
    """Returns 'new', 'duplicate', or 'updated'."""
    fp = generate_fingerprint(new_job)
    existing = db.query("SELECT id, updated_at FROM jobs WHERE fingerprint = %s", fp)
    
    if not existing:
        return 'new'  # Insert
    
    # Check if job details have changed (salary, description update)
    if has_meaningful_changes(existing, new_job):
        return 'updated'  # Update existing record
    
    return 'duplicate'  # Skip
```

## 3.4 AI Skill Extraction Prompt

```
System: You are an expert job analyst. Extract skills from the job description.

User: Extract all technical skills, tools, frameworks, and qualifications from 
this job description. Categorize each as "required" or "preferred".

Job Description: {description}

Return JSON:
{
    "skills": [
        {"name": "Python", "category": "programming", "importance": "required"},
        {"name": "AWS", "category": "cloud", "importance": "preferred"}
    ],
    "experience_years": {"min": 3, "max": 7},
    "education": "bachelors",
    "seniority": "mid"
}
```

---

# STEP 4 - MATCHING ALGORITHM

## 4.1 Multi-Dimensional Scoring System

```
Overall Score = Weighted Sum of Component Scores

Components:
  1. Skill Match Score      (weight: 0.35) - Hard skill overlap
  2. Semantic Similarity     (weight: 0.25) - Embedding cosine similarity
  3. Experience Match        (weight: 0.20) - Years of experience alignment
  4. Education Match         (weight: 0.10) - Degree/level requirements
  5. Location Match          (weight: 0.10) - Geographic compatibility

Overall = (0.35 * skill) + (0.25 * semantic) + (0.20 * experience)
        + (0.10 * education) + (0.10 * location)
```

## 4.2 Detailed Scoring Algorithms

### Skill Match Score (0-100)

```python
def compute_skill_score(student_skills: set, job_skills: list) -> float:
    """
    Weighted Jaccard similarity with importance weighting.
    Required skills count more than preferred skills.
    """
    required = {s['skill_id'] for s in job_skills if s['importance'] == 'required'}
    preferred = {s['skill_id'] for s in job_skills if s['importance'] == 'preferred'}
    nice_to_have = {s['skill_id'] for s in job_skills if s['importance'] == 'nice_to_have'}
    
    # Calculate matches per tier
    req_matched = len(required & student_skills)
    req_total = len(required) or 1
    pref_matched = len(preferred & student_skills)
    pref_total = len(preferred) or 1
    nth_matched = len(nice_to_have & student_skills)
    nth_total = len(nice_to_have) or 1
    
    # Weighted score
    score = (
        0.60 * (req_matched / req_total) +    # Required skills matter most
        0.30 * (pref_matched / pref_total) +   # Preferred skills
        0.10 * (nth_matched / nth_total)        # Nice-to-have bonus
    )
    
    return round(score * 100, 2)
```

### Semantic Similarity Score (0-100)

```python
async def compute_semantic_score(student_embedding, job_embedding) -> float:
    """
    Cosine similarity between student profile embedding and job description embedding.
    Uses pgvector for efficient computation.
    """
    # SQL query using pgvector
    result = await db.fetch_one("""
        SELECT 1 - (student_embed <=> job_embed) as similarity
        FROM (
            SELECT 
                $1::vector as student_embed,
                $2::vector as job_embed
        ) t
    """, student_embedding, job_embedding)
    
    # Cosine similarity is 0-1, scale to 0-100
    # Apply sigmoid-like scaling to spread mid-range scores
    raw = result['similarity']
    # Most embeddings cluster 0.6-0.9, so we rescale
    normalized = max(0, (raw - 0.5) / 0.5)  # Map 0.5-1.0 -> 0-1
    return round(normalized * 100, 2)
```

### Experience Match Score (0-100)

```python
def compute_experience_score(student_years: float, job_min: int, job_max: int) -> float:
    """
    Gaussian-like scoring centered on the job's experience range.
    Perfect score if within range, penalty for over/under.
    """
    if job_min is None and job_max is None:
        return 75.0  # No requirement stated = neutral score
    
    job_min = job_min or 0
    job_max = job_max or job_min + 5
    midpoint = (job_min + job_max) / 2
    range_size = (job_max - job_min) / 2 or 1
    
    if job_min <= student_years <= job_max:
        return 100.0  # Perfect match
    
    # Penalty for being outside range
    if student_years < job_min:
        deficit = job_min - student_years
        return max(0, 100 - (deficit / range_size) * 40)
    else:  # Overqualified
        surplus = student_years - job_max
        return max(50, 100 - (surplus / range_size) * 20)  # Less penalty for over-qualification
```

### Education Match Score (0-100)

```python
EDUCATION_HIERARCHY = {
    'phd': 5, 'masters': 4, 'bachelors': 3,
    'associate': 2, 'bootcamp': 1, 'high_school': 0
}

def compute_education_score(student_level: str, job_required: str) -> float:
    student_rank = EDUCATION_HIERARCHY.get(student_level, 0)
    job_rank = EDUCATION_HIERARCHY.get(job_required, 0)
    
    if student_rank >= job_rank:
        return 100.0
    
    gap = job_rank - student_rank
    return max(0, 100 - (gap * 30))  # 30-point penalty per level below
```

### Location Match Score (0-100)

```python
def compute_location_score(student, job) -> float:
    # Remote jobs always match
    if job.remote_type == 'remote':
        return 100.0
    
    if student.remote_preference == 'remote' and job.remote_type != 'remote':
        return 30.0  # Student wants remote, job isn't
    
    # Same city = perfect
    if student.location_city == job.location_city and student.location_state == job.location_state:
        return 100.0
    
    # Same state
    if student.location_state == job.location_state:
        return 80.0
    
    # Willing to relocate
    if student.willing_to_relocate:
        return 60.0
    
    # Hybrid has some flexibility
    if job.remote_type == 'hybrid':
        return 50.0
    
    return 20.0  # Different location, not willing to relocate
```

## 4.3 Batch Matching Pipeline

```
[Celery Task: recompute_matches]
    |
    +--> For each active student:
    |     1. Get student embedding + skills
    |     2. Query top-500 jobs by semantic similarity (pgvector ANN search)
    |     3. For each candidate job:
    |        a. Compute skill_score
    |        b. Compute experience_score
    |        c. Compute education_score
    |        d. Compute semantic_score (already from step 2)
    |        e. Compute location_score
    |        f. Weighted sum -> overall_score
    |     4. Filter: overall_score >= 40 (minimum threshold)
    |     5. Upsert into matches table
    |     6. Cache top-20 matches in Redis
    |
    +--> Metrics: log match computation time, avg scores
```

---

# STEP 5 - ATS RESUME GENERATOR

## 5.1 Architecture

```
[Generate Resume Request]
    |
    v
+-----------------------------------+
|   Resume Generation Pipeline       |
|                                   |
|   1. [Gather Context]             |
|      - Student profile data       |
|      - Job description            |
|      - Match analysis             |
|      - Matched/missing skills     |
|                                   |
|   2. [AI Content Generation]      |
|      - GPT-4 generates resume     |
|      - Tailored to job desc       |
|      - ATS keyword injection      |
|      - Structured JSON output     |
|                                   |
|   3. [ATS Optimization]           |
|      - Keyword density check      |
|      - Section order validation   |
|      - Format compliance          |
|      - Score estimation           |
|                                   |
|   4. [PDF Rendering]              |
|      - HTML template + CSS        |
|      - WeasyPrint -> PDF          |
|      - Single-column ATS layout   |
|      - Standard fonts             |
|                                   |
|   5. [Storage]                    |
|      - Upload PDF to S3/R2        |
|      - Save content_json to DB    |
|      - Return URL                 |
+-----------------------------------+
```

## 5.2 GPT-4 Resume Generation Prompt

```
System:
You are an expert resume writer specializing in ATS-optimized resumes. 
Your resumes consistently score 90+ on ATS systems like Workday, Taleo, and Greenhouse.

Rules:
1. Use keywords from the job description naturally in context
2. Quantify achievements with numbers and percentages
3. Use strong action verbs (Developed, Implemented, Architected, Led, Optimized)
4. Keep bullet points to 1-2 lines each
5. Prioritize skills and experiences most relevant to THIS specific job
6. Use standard section headers: Summary, Skills, Experience, Projects, Education
7. NO graphics, tables, columns, or special characters
8. NO headers/footers (ATS can't read them)
9. Use standard fonts (Arial, Calibri, Times New Roman)

User:
Generate an ATS-optimized resume for this candidate applying to this job.

**CANDIDATE PROFILE:**
{student_profile_json}

**JOB DESCRIPTION:**
{job_description}

**KEY MATCHED SKILLS:** {matched_skills}
**MISSING SKILLS TO POTENTIALLY ADDRESS:** {missing_skills}
**ATS KEYWORDS TO INCLUDE:** {ats_keywords}

Generate a complete resume in this exact JSON structure:
{
    "header": {
        "name": "...",
        "email": "...",
        "phone": "...",
        "location": "City, State",
        "linkedin": "...",
        "portfolio": "..."
    },
    "summary": "3-4 sentence tailored professional summary...",
    "skills": {
        "technical": ["skill1", "skill2"],
        "tools": ["tool1", "tool2"],
        "other": ["skill"]
    },
    "experience": [
        {
            "title": "Job Title",
            "company": "Company Name",
            "location": "City, State",
            "dates": "Jan 2022 - Present",
            "bullets": [
                "Action verb + quantified achievement + relevant tech..."
            ]
        }
    ],
    "projects": [
        {
            "name": "Project Name",
            "technologies": ["tech1", "tech2"],
            "description": "Brief description",
            "bullets": ["Achievement..."]
        }
    ],
    "education": [
        {
            "degree": "BS Computer Science",
            "university": "University Name",
            "year": "2023",
            "gpa": "3.8",
            "relevant_courses": ["Course 1", "Course 2"]
        }
    ],
    "certifications": [
        {
            "name": "AWS Solutions Architect",
            "issuer": "Amazon",
            "date": "2023"
        }
    ]
}
```

## 5.3 ATS Optimization Rules

```
1. KEYWORD DENSITY CHECK:
   - Each required skill should appear 2-3 times
   - Each preferred skill should appear 1-2 times
   - Job title variations should appear in summary

2. FORMAT COMPLIANCE:
   - Single column layout only
   - No tables, text boxes, or images
   - Standard section headers
   - 10-12pt font size
   - 0.5-1 inch margins
   - .pdf format (not .docx)

3. SECTION ORDER (ATS Priority):
   1. Name & Contact Info
   2. Professional Summary
   3. Skills
   4. Work Experience
   5. Projects
   6. Education
   7. Certifications

4. ESTIMATED ATS SCORE:
   - 90-100: All required keywords present, perfect format
   - 70-89:  Most keywords, minor format issues
   - 50-69:  Some keywords missing
   - Below 50: Major issues
```

---

# STEP 6 - API DESIGN

## 6.1 Complete API Endpoints

### Authentication APIs
```
POST   /api/v1/auth/register          - Register new student
POST   /api/v1/auth/login             - Login (returns JWT)
POST   /api/v1/auth/refresh           - Refresh JWT token
POST   /api/v1/auth/forgot-password   - Password reset request
POST   /api/v1/auth/reset-password    - Reset password with token
GET    /api/v1/auth/me                - Get current user profile
```

### Student APIs
```
GET    /api/v1/students               - List all students (admin, paginated)
GET    /api/v1/students/:id           - Get student profile
POST   /api/v1/students               - Create student profile
PUT    /api/v1/students/:id           - Update student profile
DELETE /api/v1/students/:id           - Deactivate student
PATCH  /api/v1/students/:id/skills    - Update student skills
POST   /api/v1/students/:id/resume    - Upload raw resume (parse & extract)
GET    /api/v1/students/:id/stats     - Get student dashboard stats
```

### Job APIs
```
GET    /api/v1/jobs                   - List jobs (paginated, filterable)
GET    /api/v1/jobs/:id               - Get job details
POST   /api/v1/jobs                   - Create job manually
PUT    /api/v1/jobs/:id               - Update job
DELETE /api/v1/jobs/:id               - Remove job
GET    /api/v1/jobs/search            - Full-text search jobs
GET    /api/v1/jobs/stats             - Job aggregation stats
GET    /api/v1/jobs/:id/skills        - Get extracted skills for job
```

### Matching APIs
```
GET    /api/v1/students/:id/matches           - Get matched jobs for student
POST   /api/v1/students/:id/matches/compute   - Trigger match computation
GET    /api/v1/matches/:id                     - Get match details
PATCH  /api/v1/matches/:id/status              - Update match status (viewed/applied/etc)
GET    /api/v1/jobs/:id/candidates             - Get matched students for job
GET    /api/v1/matches/stats                   - Overall matching statistics
```

### Resume APIs
```
POST   /api/v1/matches/:id/resume/generate    - Generate resume for match
GET    /api/v1/resumes/:id                     - Get resume details
GET    /api/v1/resumes/:id/pdf                 - Download resume PDF
GET    /api/v1/students/:id/resumes            - All resumes for student
POST   /api/v1/resumes/:id/regenerate          - Regenerate with feedback
DELETE /api/v1/resumes/:id                     - Delete resume
```

### Scraper / Admin APIs
```
POST   /api/v1/admin/scrape/trigger           - Manually trigger scrape
GET    /api/v1/admin/scrape/logs               - Get scrape history
GET    /api/v1/admin/scrape/stats              - Scraper statistics
POST   /api/v1/admin/jobs/deduplicate          - Run deduplication
GET    /api/v1/admin/dashboard                 - Admin dashboard stats
POST   /api/v1/admin/matches/recompute-all     - Recompute all matches
```

### Analytics APIs
```
GET    /api/v1/analytics/jobs/by-source        - Jobs count per source
GET    /api/v1/analytics/jobs/by-location      - Jobs geographic distribution
GET    /api/v1/analytics/skills/trending        - Most in-demand skills
GET    /api/v1/analytics/matches/distribution   - Match score distribution
```

## 6.2 API Response Format

```json
{
    "success": true,
    "data": { ... },
    "meta": {
        "page": 1,
        "per_page": 20,
        "total": 150,
        "total_pages": 8
    },
    "errors": null,
    "request_id": "uuid-v4"
}
```

---

# STEP 7 - FRONTEND STRUCTURE

## 7.1 Page Hierarchy

```
/                               - Landing page
/auth/login                     - Login page
/auth/register                  - Registration page

/dashboard                      - Admin dashboard (overview stats)
  /dashboard/students           - Student list
  /dashboard/students/:id       - Student detail page
    -> Tabs: Profile | Matches | Resumes | Analytics
  /dashboard/jobs               - Job listings (admin view)
  /dashboard/jobs/:id           - Job detail page
  /dashboard/analytics          - Platform analytics
  /dashboard/scrapers           - Scraper status & logs

/student/:id                    - Student portal
  /student/:id/profile          - Edit profile
  /student/:id/matches          - Matched jobs list
  /student/:id/matches/:jobId   - Match detail + resume
  /student/:id/resumes          - All generated resumes
  /student/:id/settings         - Account settings
```

## 7.2 Key UI Components

```
Components/
├── Layout/
│   ├── Navbar.tsx               - Top navigation
│   ├── Sidebar.tsx              - Dashboard sidebar
│   ├── Footer.tsx
│   └── PageContainer.tsx
│
├── Students/
│   ├── StudentList.tsx          - Sortable, filterable table
│   ├── StudentCard.tsx          - Summary card
│   ├── StudentProfile.tsx       - Full profile view
│   ├── SkillEditor.tsx          - Add/remove skills
│   └── ExperienceTimeline.tsx   - Work history visual
│
├── Jobs/
│   ├── JobList.tsx              - Job listings grid/table
│   ├── JobCard.tsx              - Job summary card
│   ├── JobDetail.tsx            - Full job description
│   ├── JobFilters.tsx           - Filter sidebar
│   └── SkillBadge.tsx           - Colored skill tag
│
├── Matches/
│   ├── MatchList.tsx            - Matched jobs for student
│   ├── MatchCard.tsx            - Match with score bar
│   ├── ScoreBreakdown.tsx       - Radar chart of scores
│   ├── SkillComparison.tsx      - Visual skill gap analysis
│   └── MatchStatus.tsx          - Applied/Saved/New badges
│
├── Resumes/
│   ├── ResumeViewer.tsx         - PDF preview
│   ├── ResumeGenerator.tsx      - Generate button + progress
│   ├── ResumeList.tsx           - All versions
│   └── ATSScoreBadge.tsx        - ATS score visual
│
├── Dashboard/
│   ├── StatsOverview.tsx        - Key metrics cards
│   ├── SkillTrendsChart.tsx     - Trending skills chart
│   ├── MatchDistribution.tsx    - Score histogram
│   ├── JobSourcePie.tsx         - Jobs by source
│   └── ActivityFeed.tsx         - Recent actions
│
└── Common/
    ├── DataTable.tsx            - Reusable sortable table
    ├── SearchBar.tsx            - Global search
    ├── Pagination.tsx           - Page navigation
    ├── LoadingSpinner.tsx
    ├── EmptyState.tsx
    └── ConfirmDialog.tsx
```

## 7.3 Student Detail Page Layout

```
+-------------------------------------------------------------------+
| [< Back] Student: John Doe                    [Edit] [Generate All]|
+-------------------------------------------------------------------+
| Profile  | Matched Jobs (47) | Resumes (12) | Analytics           |
+-------------------------------------------------------------------+
|                                                                     |
| +--LEFT PANEL (30%)----------+ +--RIGHT PANEL (70%)-------------+ |
| |                             | |                                 | |
| | [Avatar]                    | | Matched Jobs                    | |
| | John Doe                    | | +-------------------------------+| |
| | john@email.com              | | | Sr. Software Engineer  [95%] || |
| | San Francisco, CA           | | | Google - Mountain View, CA   || |
| |                             | | | Skills: Python, Go, K8s      || |
| | Education:                  | | | [View Match] [Resume] [Apply]|| |
| | MS Computer Science         | | +-------------------------------+| |
| | Stanford University         | | | Full Stack Developer   [88%] || |
| |                             | | | Meta - Remote                || |
| | Skills:                     | | | Skills: React, Node, AWS     || |
| | [Python] [React] [AWS]     | | | [View Match] [Resume] [Apply]|| |
| | [Docker] [PostgreSQL]      | | +-------------------------------+| |
| | [TypeScript] [Go]          | | | Data Engineer          [82%] || |
| |                             | | | Netflix - Los Gatos, CA      || |
| | Experience: 4 years         | | | Skills: Python, Spark, SQL   || |
| | Work Auth: H1B (OPT)       | | | [View Match] [Resume] [Apply]|| |
| |                             | | +-------------------------------+| |
| | Preferred Roles:            | |                                 | |
| | - Software Engineer         | | [Load More...]                 | |
| | - Full Stack Developer      | |                                 | |
| +-----------------------------+ +---------------------------------+ |
+-------------------------------------------------------------------+
```

---

# STEP 8 - SCALING STRATEGY

## 8.1 Scale Targets

| Metric | MVP | Growth | Scale |
|--------|-----|--------|-------|
| Jobs | 10K | 500K | 5M+ |
| Students | 100 | 10K | 100K+ |
| Matches/day | 1K | 100K | 10M+ |
| Resumes/day | 50 | 5K | 50K+ |
| API req/sec | 10 | 500 | 5000+ |

## 8.2 Database Scaling

```
Phase 1 (MVP):
  - Single PostgreSQL instance (RDS db.r6g.large)
  - pgvector for embeddings
  - Connection pooling via PgBouncer

Phase 2 (Growth):
  - Read replicas for dashboard queries
  - Partition jobs table by posted_at (monthly)
  - Partition matches table by student_id (hash)
  - Move to RDS db.r6g.2xlarge
  
Phase 3 (Scale):
  - Citus/Timescale for horizontal sharding
  - Dedicated pgvector instance (or migrate to Pinecone)
  - Archive old jobs to cold storage (S3 + Athena)
  - Materialized views for analytics
  
  Table Partitioning:
    jobs:     RANGE partition by posted_at (monthly)
    matches:  HASH partition by student_id (16 partitions)
    resumes:  RANGE partition by created_at (monthly)
```

## 8.3 Application Scaling

```
Phase 1: Single server behind Nginx
Phase 2: 
  - Horizontal scaling: 3-5 FastAPI instances behind ALB
  - Separate worker pool for Celery (2-4 workers)
  - Redis cluster for caching + queues
Phase 3:
  - Kubernetes (EKS) with auto-scaling
  - Service mesh (Istio) for inter-service communication
  - Dedicated GPU nodes for embedding generation
  - CDN (CloudFront) for static assets + PDF delivery
```

## 8.4 AI/Embedding Scaling

```
Phase 1: Direct OpenAI API calls
Phase 2:
  - Batch embedding generation (async queue)
  - Cache embeddings aggressively (TTL: 30 days)
  - Pre-compute embeddings on job insert/student update
Phase 3:
  - Self-hosted embedding model (e5-large or bge-large)
  - GPU inference server (TensorRT/vLLM)
  - Reduces cost from ~$0.0001/embed to ~$0.00001/embed
  - Use OpenAI only for resume generation (high quality needed)
```

## 8.5 Cost Estimation (Monthly)

| Component | MVP | Growth | Scale |
|-----------|-----|--------|-------|
| PostgreSQL (RDS) | $200 | $800 | $3,000 |
| Redis | $50 | $200 | $500 |
| Compute (ECS/EKS) | $100 | $500 | $2,000 |
| OpenAI API | $50 | $500 | $5,000 |
| S3 Storage | $10 | $50 | $200 |
| **Total** | **$410** | **$2,050** | **$10,700** |

---

# STEP 9 - MVP PLAN

## 9.1 MVP Scope (4-6 weeks)

### Week 1: Foundation
```
Day 1-2: Project Setup
  - Initialize monorepo (Turborepo or Nx)
  - Set up FastAPI backend with project structure
  - Set up Next.js frontend with Tailwind
  - Docker Compose for local development
  - PostgreSQL + pgvector + Redis containers

Day 3-4: Database & Models
  - Implement complete database schema
  - Create SQLAlchemy/Prisma models
  - Write migration scripts
  - Seed data scripts (50 sample jobs, 10 sample students)

Day 5: Auth & Basic APIs
  - JWT authentication
  - Student CRUD endpoints
  - Job CRUD endpoints
  - API documentation (auto-generated Swagger)
```

### Week 2: Job Engine
```
Day 1-2: Job Scrapers
  - Greenhouse API scraper (easiest to start)
  - Lever API scraper
  - USA Jobs API scraper
  - Job normalization pipeline

Day 3-4: AI Integration
  - OpenAI embedding generation for jobs
  - GPT-4 skill extraction from descriptions
  - Store embeddings in pgvector
  - Skill dictionary seeding (200+ common tech skills)

Day 5: Deduplication & Storage
  - Fingerprint-based deduplication
  - Celery task for scheduled scraping
  - Scrape logging and monitoring
```

### Week 3: Matching Engine
```
Day 1-2: Core Algorithm
  - Implement all 5 scoring components
  - Weighted aggregation
  - pgvector ANN search for candidate selection
  - Batch matching pipeline

Day 3-4: Optimization
  - Redis caching for match results
  - Match computation Celery task
  - Incremental matching (only new jobs/updated profiles)

Day 5: Testing & Tuning
  - Unit tests for each scoring component
  - Integration test with real data
  - Score calibration (ensure good distribution)
```

### Week 4: Resume Generator
```
Day 1-2: AI Resume Generation
  - GPT-4 prompt engineering for resume content
  - JSON structured output parsing
  - ATS keyword injection and scoring

Day 3-4: PDF Generation
  - HTML/CSS resume template (ATS-friendly)
  - WeasyPrint PDF rendering
  - S3 upload and URL generation

Day 5: Resume APIs & Testing
  - Generate, retrieve, download endpoints
  - Regeneration with feedback
  - End-to-end testing
```

### Week 5: Frontend Dashboard
```
Day 1-2: Layout & Navigation
  - Dashboard shell (sidebar, navbar)
  - Authentication pages
  - Responsive layout

Day 3-4: Core Pages
  - Student list page
  - Student detail page with tabs
  - Job listing page
  - Match results page

Day 5: Integration
  - Connect all API endpoints
  - PDF viewer integration
  - Apply link functionality
```

### Week 6: Polish & Deploy
```
Day 1-2: Testing & Bug Fixes
  - E2E testing (Playwright)
  - Performance testing
  - Security audit (SQL injection, XSS, CSRF)

Day 3-4: Deployment
  - AWS infrastructure (Terraform)
  - CI/CD pipeline (GitHub Actions)
  - SSL, domain setup
  - Monitoring (Datadog/CloudWatch)

Day 5: Launch Prep
  - Load testing (k6)
  - Documentation
  - Demo video
  - Seed production database
```

## 9.2 Post-MVP Roadmap

```
V1.1 (Month 2):
  - LinkedIn and Indeed scrapers
  - Email notifications for new matches
  - Resume version comparison
  - Bulk resume generation

V1.2 (Month 3):
  - Student self-service portal
  - Resume upload + AI parsing
  - Application tracking (applied/interview/offer)
  - Chrome extension for quick apply

V2.0 (Month 4-5):
  - Real-time job alerts (WebSocket)
  - Interview prep AI module
  - Salary benchmarking
  - Company insights & reviews integration
  - Mobile app (React Native)

V3.0 (Month 6+):
  - Multi-tenant (universities/bootcamps)
  - Employer dashboard (post jobs, view candidates)
  - A/B testing for resume templates
  - Self-hosted LLM for cost reduction
  - Advanced analytics & reporting
```
