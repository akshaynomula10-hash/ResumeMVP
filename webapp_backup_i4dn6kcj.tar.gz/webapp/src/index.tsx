import { Hono } from 'hono'
import { cors } from 'hono/cors'

type Bindings = {
  DB: D1Database
}

const app = new Hono<{ Bindings: Bindings }>()

app.use('/api/*', cors())

// Favicon handler
app.get('/favicon.ico', (c) => {
  return new Response(null, { status: 204 })
})

// ============================================================
// MATCHING ENGINE - Core algorithms
// ============================================================

function computeSkillScore(studentSkillIds: Set<number>, jobSkills: any[]): { score: number, matched: string[], missing: string[] } {
  const required = jobSkills.filter(s => s.importance === 'required')
  const preferred = jobSkills.filter(s => s.importance === 'preferred')
  const niceToHave = jobSkills.filter(s => s.importance === 'nice_to_have')

  const reqMatched = required.filter(s => studentSkillIds.has(s.skill_id))
  const prefMatched = preferred.filter(s => studentSkillIds.has(s.skill_id))
  const nthMatched = niceToHave.filter(s => studentSkillIds.has(s.skill_id))

  const reqTotal = required.length || 1
  const prefTotal = preferred.length || 1
  const nthTotal = niceToHave.length || 1

  const score = (
    0.60 * (reqMatched.length / reqTotal) +
    0.30 * (prefMatched.length / prefTotal) +
    0.10 * (nthMatched.length / nthTotal)
  ) * 100

  const matched = [...reqMatched, ...prefMatched, ...nthMatched].map(s => s.skill_name)
  const missing = [...required, ...preferred].filter(s => !studentSkillIds.has(s.skill_id)).map(s => s.skill_name)

  return { score: Math.round(score * 100) / 100, matched, missing }
}

function computeExperienceScore(studentYears: number, jobMin: number | null, jobMax: number | null): number {
  if (jobMin === null && jobMax === null) return 75.0
  const min = jobMin || 0
  const max = jobMax || min + 5
  const rangeSize = (max - min) / 2 || 1

  if (studentYears >= min && studentYears <= max) return 100.0
  if (studentYears < min) {
    const deficit = min - studentYears
    return Math.max(0, 100 - (deficit / rangeSize) * 40)
  }
  const surplus = studentYears - max
  return Math.max(50, 100 - (surplus / rangeSize) * 20)
}

const EDUCATION_HIERARCHY: Record<string, number> = {
  'phd': 5, 'masters': 4, 'bachelors': 3, 'associate': 2, 'bootcamp': 1, 'high_school': 0
}

function computeEducationScore(studentLevel: string, jobRequired: string | null): number {
  if (!jobRequired) return 80.0
  const studentRank = EDUCATION_HIERARCHY[studentLevel] || 0
  const jobRank = EDUCATION_HIERARCHY[jobRequired] || 0
  if (studentRank >= jobRank) return 100.0
  return Math.max(0, 100 - (jobRank - studentRank) * 30)
}

function computeLocationScore(student: any, job: any): number {
  if (job.remote_type === 'remote') return 100.0
  if (student.remote_preference === 'remote' && job.remote_type !== 'remote') return 30.0
  if (student.location_city === job.location_city && student.location_state === job.location_state) return 100.0
  if (student.location_state === job.location_state) return 80.0
  if (student.willing_to_relocate) return 60.0
  if (job.remote_type === 'hybrid') return 50.0
  return 20.0
}

// ============================================================
// RESUME GENERATOR - ATS-optimized resume builder
// ============================================================

function generateResumeContent(student: any, job: any, matchedSkills: string[], missingSkills: string[]): any {
  const experience = JSON.parse(student.experience_json || '[]')
  const projects = JSON.parse(student.projects_json || '[]')
  const certifications = JSON.parse(student.certifications_json || '[]')
  const jobAtsKeywords = job.ats_keywords ? job.ats_keywords.split(',').map((k: string) => k.trim()) : []

  // Tailor summary to the specific job
  const summary = `Results-driven ${student.education_level ? student.education_level.charAt(0).toUpperCase() + student.education_level.slice(1) + '-level' : ''} professional with ${student.total_years_exp}+ years of experience in ${matchedSkills.slice(0, 3).join(', ')}. Proven track record at ${experience[0]?.company || 'leading technology companies'} building ${job.title.toLowerCase().includes('data') || job.title.toLowerCase().includes('ml') ? 'production ML systems and data pipelines' : job.title.toLowerCase().includes('frontend') || job.title.toLowerCase().includes('react') ? 'high-performance web applications and design systems' : job.title.toLowerCase().includes('devops') || job.title.toLowerCase().includes('cloud') || job.title.toLowerCase().includes('infrastructure') ? 'scalable cloud infrastructure and DevOps pipelines' : 'scalable, distributed systems and microservices'}. ${student.education_level === 'phd' ? 'Published researcher with' : 'Strong background in'} ${matchedSkills.slice(0, 5).join(', ')}. Seeking to leverage expertise as ${job.title} at ${job.company}.`

  // Prioritize matched skills
  const allStudentSkills = matchedSkills.concat(
    missingSkills.filter(s => s.toLowerCase().includes('agile') || s.toLowerCase().includes('git'))
  )

  // Optimize experience bullets - add relevant keywords
  const optimizedExperience = experience.map((exp: any) => ({
    ...exp,
    bullets: exp.bullets?.slice(0, 4) || []
  }))

  // Select most relevant projects
  const relevantProjects = projects.slice(0, 2).map((p: any) => ({
    ...p,
    bullets: p.bullets?.slice(0, 2) || []
  }))

  // ATS keyword analysis
  const keywordDensity: Record<string, number> = {}
  const fullText = JSON.stringify({ summary, experience: optimizedExperience, projects: relevantProjects })
  jobAtsKeywords.forEach((kw: string) => {
    const regex = new RegExp(kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi')
    const matches = fullText.match(regex)
    keywordDensity[kw] = matches ? matches.length : 0
  })

  const presentKeywords = Object.values(keywordDensity).filter(v => v > 0).length
  const totalKeywords = jobAtsKeywords.length || 1
  const atsScore = Math.min(98, Math.round((presentKeywords / totalKeywords) * 80 + (matchedSkills.length / (matchedSkills.length + missingSkills.length || 1)) * 20))

  return {
    content: {
      header: {
        name: student.full_name,
        email: student.email,
        phone: student.phone || '',
        location: `${student.location_city || ''}, ${student.location_state || ''}`.replace(/^, |, $/g, ''),
        linkedin: '',
        portfolio: ''
      },
      summary,
      skills: {
        technical: allStudentSkills.filter((_: any, i: number) => i < 10),
        tools: matchedSkills.filter((s: string) =>
          ['docker', 'kubernetes', 'git', 'jenkins', 'terraform', 'figma', 'tableau'].some(t =>
            s.toLowerCase().includes(t)
          )
        ),
        other: ['Agile/Scrum', 'Technical Documentation', 'Code Review', 'Mentoring']
      },
      experience: optimizedExperience,
      projects: relevantProjects,
      education: [{
        degree: `${student.education_level === 'masters' ? 'MS' : student.education_level === 'phd' ? 'PhD' : student.education_level === 'bachelors' ? 'BS' : ''} ${student.degree || ''}`.trim(),
        university: student.university || '',
        year: student.graduation_year?.toString() || '',
        gpa: student.gpa?.toString() || '',
        relevant_courses: []
      }],
      certifications: certifications
    },
    ats_keywords: jobAtsKeywords,
    ats_score_estimate: atsScore,
    keyword_density: keywordDensity
  }
}

// ============================================================
// API ROUTES - Students
// ============================================================

app.get('/api/v1/students', async (c) => {
  const db = c.env.DB
  const page = parseInt(c.req.query('page') || '1')
  const limit = parseInt(c.req.query('limit') || '20')
  const offset = (page - 1) * limit
  const search = c.req.query('search') || ''

  let query = 'SELECT * FROM students WHERE is_active = 1'
  const params: any[] = []

  if (search) {
    query += ' AND (full_name LIKE ? OR email LIKE ? OR degree LIKE ?)'
    params.push(`%${search}%`, `%${search}%`, `%${search}%`)
  }

  const countResult = await db.prepare(query.replace('SELECT *', 'SELECT COUNT(*) as total')).bind(...params).first<{ total: number }>()
  query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'
  params.push(limit, offset)

  const students = await db.prepare(query).bind(...params).all()

  return c.json({
    success: true,
    data: students.results,
    meta: {
      page, per_page: limit,
      total: countResult?.total || 0,
      total_pages: Math.ceil((countResult?.total || 0) / limit)
    }
  })
})

app.get('/api/v1/students/:id', async (c) => {
  const db = c.env.DB
  const id = c.req.param('id')

  const student = await db.prepare('SELECT * FROM students WHERE id = ?').bind(id).first()
  if (!student) return c.json({ success: false, error: 'Student not found' }, 404)

  const skills = await db.prepare(`
    SELECT ss.*, s.name as skill_name, s.canonical_name, s.category
    FROM student_skills ss
    JOIN skills s ON ss.skill_id = s.id
    WHERE ss.student_id = ?
    ORDER BY ss.is_primary DESC, ss.years_experience DESC
  `).bind(id).all()

  return c.json({
    success: true,
    data: { ...student, skills: skills.results }
  })
})

app.get('/api/v1/students/:id/stats', async (c) => {
  const db = c.env.DB
  const id = c.req.param('id')

  const matchCount = await db.prepare('SELECT COUNT(*) as total FROM matches WHERE student_id = ?').bind(id).first<{ total: number }>()
  const highMatches = await db.prepare('SELECT COUNT(*) as total FROM matches WHERE student_id = ? AND overall_score >= 70').bind(id).first<{ total: number }>()
  const resumeCount = await db.prepare('SELECT COUNT(*) as total FROM resumes WHERE student_id = ?').bind(id).first<{ total: number }>()
  const avgScore = await db.prepare('SELECT AVG(overall_score) as avg FROM matches WHERE student_id = ?').bind(id).first<{ avg: number }>()

  return c.json({
    success: true,
    data: {
      total_matches: matchCount?.total || 0,
      high_matches: highMatches?.total || 0,
      total_resumes: resumeCount?.total || 0,
      avg_match_score: Math.round((avgScore?.avg || 0) * 100) / 100
    }
  })
})

// ============================================================
// API ROUTES - Jobs
// ============================================================

app.get('/api/v1/jobs', async (c) => {
  const db = c.env.DB
  const page = parseInt(c.req.query('page') || '1')
  const limit = parseInt(c.req.query('limit') || '20')
  const offset = (page - 1) * limit
  const search = c.req.query('search') || ''
  const source = c.req.query('source') || ''
  const remote = c.req.query('remote') || ''
  const state = c.req.query('state') || ''

  let query = 'SELECT * FROM jobs WHERE status = ?'
  const params: any[] = ['active']

  if (search) {
    query += ' AND (title LIKE ? OR company LIKE ? OR description LIKE ?)'
    params.push(`%${search}%`, `%${search}%`, `%${search}%`)
  }
  if (source) { query += ' AND source = ?'; params.push(source) }
  if (remote) { query += ' AND remote_type = ?'; params.push(remote) }
  if (state) { query += ' AND location_state = ?'; params.push(state) }

  const countResult = await db.prepare(query.replace('SELECT *', 'SELECT COUNT(*) as total')).bind(...params).first<{ total: number }>()
  query += ' ORDER BY posted_at DESC LIMIT ? OFFSET ?'
  params.push(limit, offset)

  const jobs = await db.prepare(query).bind(...params).all()

  return c.json({
    success: true,
    data: jobs.results,
    meta: {
      page, per_page: limit,
      total: countResult?.total || 0,
      total_pages: Math.ceil((countResult?.total || 0) / limit)
    }
  })
})

app.get('/api/v1/jobs/:id', async (c) => {
  const db = c.env.DB
  const id = c.req.param('id')

  const job = await db.prepare('SELECT * FROM jobs WHERE id = ?').bind(id).first()
  if (!job) return c.json({ success: false, error: 'Job not found' }, 404)

  const skills = await db.prepare(`
    SELECT js.*, s.name as skill_name, s.canonical_name, s.category
    FROM job_skills js
    JOIN skills s ON js.skill_id = s.id
    WHERE js.job_id = ?
    ORDER BY CASE js.importance WHEN 'required' THEN 1 WHEN 'preferred' THEN 2 ELSE 3 END
  `).bind(id).all()

  return c.json({
    success: true,
    data: { ...job, skills: skills.results }
  })
})

app.get('/api/v1/jobs/stats/overview', async (c) => {
  const db = c.env.DB

  const total = await db.prepare("SELECT COUNT(*) as c FROM jobs WHERE status='active'").first<{ c: number }>()
  const bySource = await db.prepare("SELECT source, COUNT(*) as count FROM jobs WHERE status='active' GROUP BY source").all()
  const byRemote = await db.prepare("SELECT remote_type, COUNT(*) as count FROM jobs WHERE status='active' GROUP BY remote_type").all()
  const byState = await db.prepare("SELECT location_state, COUNT(*) as count FROM jobs WHERE status='active' GROUP BY location_state ORDER BY count DESC LIMIT 10").all()

  return c.json({
    success: true,
    data: {
      total_active: total?.c || 0,
      by_source: bySource.results,
      by_remote: byRemote.results,
      by_state: byState.results
    }
  })
})

// ============================================================
// API ROUTES - Matching Engine
// ============================================================

app.post('/api/v1/students/:id/matches/compute', async (c) => {
  const db = c.env.DB
  const studentId = c.req.param('id')

  const student = await db.prepare('SELECT * FROM students WHERE id = ?').bind(studentId).first()
  if (!student) return c.json({ success: false, error: 'Student not found' }, 404)

  // Get student skills
  const studentSkillsResult = await db.prepare(`
    SELECT ss.skill_id, s.name as skill_name, s.canonical_name
    FROM student_skills ss
    JOIN skills s ON ss.skill_id = s.id
    WHERE ss.student_id = ?
  `).bind(studentId).all()

  const studentSkillIds = new Set(studentSkillsResult.results.map((s: any) => s.skill_id as number))

  // Get all active jobs with their skills
  const jobs = await db.prepare("SELECT * FROM jobs WHERE status = 'active'").all()

  let matchesComputed = 0

  for (const job of jobs.results) {
    const jobSkills = await db.prepare(`
      SELECT js.skill_id, js.importance, s.name as skill_name
      FROM job_skills js
      JOIN skills s ON js.skill_id = s.id
      WHERE js.job_id = ?
    `).bind(job.id).all()

    const { score: skillScore, matched, missing } = computeSkillScore(studentSkillIds, jobSkills.results)
    const expScore = computeExperienceScore(
      (student as any).total_years_exp || 0,
      (job as any).experience_min,
      (job as any).experience_max
    )
    const eduScore = computeEducationScore(
      (student as any).education_level || '',
      (job as any).education_req
    )
    const locScore = computeLocationScore(student, job)

    // Semantic score simulation (keyword overlap based)
    const studentSkillNames = studentSkillsResult.results.map((s: any) => (s.skill_name as string).toLowerCase())
    const jobDesc = ((job as any).description || '').toLowerCase()
    const semanticHits = studentSkillNames.filter((s: string) => jobDesc.includes(s)).length
    const semanticScore = Math.min(100, (semanticHits / Math.max(studentSkillNames.length, 1)) * 120)

    // Weighted overall score
    const overall = Math.round(
      (0.35 * skillScore + 0.25 * semanticScore + 0.20 * expScore + 0.10 * eduScore + 0.10 * locScore) * 100
    ) / 100

    if (overall >= 25) {
      const reasons = {
        skill_detail: `Matched ${matched.length} skills, missing ${missing.length}`,
        experience_detail: `${(student as any).total_years_exp} years vs required ${(job as any).experience_min || '?'}-${(job as any).experience_max || '?'}`,
        education_detail: `${(student as any).education_level || 'N/A'} vs required ${(job as any).education_req || 'any'}`,
        location_detail: `${(student as any).location_city}, ${(student as any).location_state} -> ${(job as any).location_city}, ${(job as any).location_state} (${(job as any).remote_type})`
      }

      await db.prepare(`
        INSERT OR REPLACE INTO matches (student_id, job_id, overall_score, skill_score, experience_score, education_score, semantic_score, location_score, matched_skills, missing_skills, match_reasons, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new')
      `).bind(
        studentId, job.id, overall,
        Math.round(skillScore * 100) / 100,
        Math.round(expScore * 100) / 100,
        Math.round(eduScore * 100) / 100,
        Math.round(semanticScore * 100) / 100,
        Math.round(locScore * 100) / 100,
        JSON.stringify(matched),
        JSON.stringify(missing),
        JSON.stringify(reasons)
      ).run()
      matchesComputed++
    }
  }

  return c.json({
    success: true,
    data: { matches_computed: matchesComputed, student_id: studentId }
  })
})

app.get('/api/v1/students/:id/matches', async (c) => {
  const db = c.env.DB
  const studentId = c.req.param('id')
  const page = parseInt(c.req.query('page') || '1')
  const limit = parseInt(c.req.query('limit') || '20')
  const offset = (page - 1) * limit
  const minScore = parseFloat(c.req.query('min_score') || '0')

  const countResult = await db.prepare(
    'SELECT COUNT(*) as total FROM matches WHERE student_id = ? AND overall_score >= ?'
  ).bind(studentId, minScore).first<{ total: number }>()

  const matches = await db.prepare(`
    SELECT m.*, j.title, j.company, j.location_city, j.location_state, j.remote_type,
           j.salary_min, j.salary_max, j.apply_url, j.source, j.seniority_level, j.job_type,
           j.posted_at as job_posted_at
    FROM matches m
    JOIN jobs j ON m.job_id = j.id
    WHERE m.student_id = ? AND m.overall_score >= ? AND j.status = 'active'
    ORDER BY m.overall_score DESC
    LIMIT ? OFFSET ?
  `).bind(studentId, minScore, limit, offset).all()

  // Check if resumes exist for each match
  const enrichedMatches = await Promise.all(matches.results.map(async (match: any) => {
    const resume = await db.prepare(
      'SELECT id, ats_score_estimate, status FROM resumes WHERE match_id = ? ORDER BY version DESC LIMIT 1'
    ).bind(match.id).first()
    return { ...match, resume: resume || null }
  }))

  return c.json({
    success: true,
    data: enrichedMatches,
    meta: {
      page, per_page: limit,
      total: countResult?.total || 0,
      total_pages: Math.ceil((countResult?.total || 0) / limit)
    }
  })
})

// Compute matches for ALL students
app.post('/api/v1/matches/compute-all', async (c) => {
  const db = c.env.DB
  const students = await db.prepare("SELECT id FROM students WHERE is_active = 1").all()
  let totalMatches = 0

  for (const student of students.results) {
    const url = new URL(c.req.url)
    const resp = await app.fetch(
      new Request(`${url.origin}/api/v1/students/${student.id}/matches/compute`, { method: 'POST' }),
      c.env
    )
    const result: any = await resp.json()
    if (result.success) totalMatches += result.data.matches_computed
  }

  return c.json({
    success: true,
    data: { total_matches: totalMatches, students_processed: students.results.length }
  })
})

// ============================================================
// API ROUTES - Resume Generation
// ============================================================

app.post('/api/v1/matches/:id/resume/generate', async (c) => {
  const db = c.env.DB
  const matchId = c.req.param('id')

  const match = await db.prepare('SELECT * FROM matches WHERE id = ?').bind(matchId).first()
  if (!match) return c.json({ success: false, error: 'Match not found' }, 404)

  const student = await db.prepare('SELECT * FROM students WHERE id = ?').bind((match as any).student_id).first()
  const job = await db.prepare('SELECT * FROM jobs WHERE id = ?').bind((match as any).job_id).first()

  if (!student || !job) return c.json({ success: false, error: 'Student or Job not found' }, 404)

  const matchedSkills = JSON.parse((match as any).matched_skills || '[]')
  const missingSkills = JSON.parse((match as any).missing_skills || '[]')

  const resumeData = generateResumeContent(student, job, matchedSkills, missingSkills)

  // Get latest version
  const latestVersion = await db.prepare(
    'SELECT MAX(version) as v FROM resumes WHERE student_id = ? AND job_id = ?'
  ).bind((match as any).student_id, (match as any).job_id).first<{ v: number }>()

  const newVersion = (latestVersion?.v || 0) + 1

  const result = await db.prepare(`
    INSERT INTO resumes (match_id, student_id, job_id, content_json, ats_keywords, ats_score_estimate, version, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'generated')
  `).bind(
    matchId,
    (match as any).student_id,
    (match as any).job_id,
    JSON.stringify(resumeData.content),
    resumeData.ats_keywords.join(','),
    resumeData.ats_score_estimate,
    newVersion
  ).run()

  return c.json({
    success: true,
    data: {
      resume_id: result.meta.last_row_id,
      version: newVersion,
      ats_score_estimate: resumeData.ats_score_estimate,
      content: resumeData.content,
      ats_keywords: resumeData.ats_keywords,
      keyword_density: resumeData.keyword_density
    }
  })
})

app.get('/api/v1/resumes/:id', async (c) => {
  const db = c.env.DB
  const id = c.req.param('id')

  const resume = await db.prepare(`
    SELECT r.*, j.title as job_title, j.company, s.full_name as student_name
    FROM resumes r
    JOIN jobs j ON r.job_id = j.id
    JOIN students s ON r.student_id = s.id
    WHERE r.id = ?
  `).bind(id).first()

  if (!resume) return c.json({ success: false, error: 'Resume not found' }, 404)

  return c.json({ success: true, data: resume })
})

app.get('/api/v1/students/:id/resumes', async (c) => {
  const db = c.env.DB
  const studentId = c.req.param('id')

  const resumes = await db.prepare(`
    SELECT r.*, j.title as job_title, j.company
    FROM resumes r
    JOIN jobs j ON r.job_id = j.id
    WHERE r.student_id = ?
    ORDER BY r.created_at DESC
  `).bind(studentId).all()

  return c.json({ success: true, data: resumes.results })
})

// ============================================================
// API ROUTES - Dashboard Analytics
// ============================================================

app.get('/api/v1/dashboard/stats', async (c) => {
  const db = c.env.DB

  const students = await db.prepare("SELECT COUNT(*) as c FROM students WHERE is_active = 1").first<{ c: number }>()
  const jobs = await db.prepare("SELECT COUNT(*) as c FROM jobs WHERE status = 'active'").first<{ c: number }>()
  const matches = await db.prepare("SELECT COUNT(*) as c FROM matches").first<{ c: number }>()
  const resumes = await db.prepare("SELECT COUNT(*) as c FROM resumes").first<{ c: number }>()
  const avgScore = await db.prepare("SELECT AVG(overall_score) as avg FROM matches").first<{ avg: number }>()
  const highMatches = await db.prepare("SELECT COUNT(*) as c FROM matches WHERE overall_score >= 70").first<{ c: number }>()

  return c.json({
    success: true,
    data: {
      total_students: students?.c || 0,
      total_jobs: jobs?.c || 0,
      total_matches: matches?.c || 0,
      total_resumes: resumes?.c || 0,
      avg_match_score: Math.round((avgScore?.avg || 0) * 100) / 100,
      high_quality_matches: highMatches?.c || 0
    }
  })
})

app.get('/api/v1/analytics/skills/trending', async (c) => {
  const db = c.env.DB

  const skills = await db.prepare(`
    SELECT s.name, s.category, COUNT(js.id) as job_count
    FROM job_skills js
    JOIN skills s ON js.skill_id = s.id
    JOIN jobs j ON js.job_id = j.id
    WHERE j.status = 'active'
    GROUP BY s.id
    ORDER BY job_count DESC
    LIMIT 20
  `).all()

  return c.json({ success: true, data: skills.results })
})

app.get('/api/v1/analytics/matches/distribution', async (c) => {
  const db = c.env.DB

  const distribution = await db.prepare(`
    SELECT
      CASE
        WHEN overall_score >= 90 THEN '90-100'
        WHEN overall_score >= 80 THEN '80-89'
        WHEN overall_score >= 70 THEN '70-79'
        WHEN overall_score >= 60 THEN '60-69'
        WHEN overall_score >= 50 THEN '50-59'
        WHEN overall_score >= 40 THEN '40-49'
        ELSE 'Below 40'
      END as score_range,
      COUNT(*) as count
    FROM matches
    GROUP BY score_range
    ORDER BY score_range DESC
  `).all()

  return c.json({ success: true, data: distribution.results })
})

// ============================================================
// API ROUTES - Skills
// ============================================================

app.get('/api/v1/skills', async (c) => {
  const db = c.env.DB
  const category = c.req.query('category') || ''

  let query = 'SELECT * FROM skills'
  const params: any[] = []
  if (category) {
    query += ' WHERE category = ?'
    params.push(category)
  }
  query += ' ORDER BY name'

  const skills = await db.prepare(query).bind(...params).all()
  return c.json({ success: true, data: skills.results })
})

// ============================================================
// FRONTEND - Serve HTML pages
// ============================================================

const renderPage = (title: string, content: string, activeNav: string = '') => {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title} - JobMatch AI</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.0/css/all.min.css" rel="stylesheet">
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            brand: { 50:'#eff6ff', 100:'#dbeafe', 200:'#bfdbfe', 300:'#93c5fd', 400:'#60a5fa', 500:'#3b82f6', 600:'#2563eb', 700:'#1d4ed8', 800:'#1e40af', 900:'#1e3a8a' }
          }
        }
      }
    }
  </script>
  <style>
    .score-bar { transition: width 0.8s ease-out; }
    .card-hover { transition: all 0.2s ease; }
    .card-hover:hover { transform: translateY(-2px); box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); }
    .fade-in { animation: fadeIn 0.3s ease-in; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    .loading-pulse { animation: pulse 1.5s infinite; }
    @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.5; } }
    .skill-badge { display: inline-flex; align-items: center; padding: 2px 10px; border-radius: 9999px; font-size: 0.75rem; font-weight: 500; }
  </style>
</head>
<body class="bg-gray-50 min-h-screen">
  <!-- Navigation -->
  <nav class="bg-white border-b border-gray-200 sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex justify-between h-16">
        <div class="flex items-center">
          <a href="/" class="flex items-center space-x-2">
            <div class="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center">
              <i class="fas fa-briefcase text-white text-sm"></i>
            </div>
            <span class="text-xl font-bold text-gray-900">JobMatch<span class="text-brand-600">AI</span></span>
          </a>
          <div class="hidden md:flex ml-10 space-x-1">
            <a href="/" class="px-3 py-2 rounded-md text-sm font-medium ${activeNav === 'dashboard' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'}">
              <i class="fas fa-chart-line mr-1"></i> Dashboard
            </a>
            <a href="/students" class="px-3 py-2 rounded-md text-sm font-medium ${activeNav === 'students' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'}">
              <i class="fas fa-users mr-1"></i> Students
            </a>
            <a href="/jobs" class="px-3 py-2 rounded-md text-sm font-medium ${activeNav === 'jobs' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'}">
              <i class="fas fa-building mr-1"></i> Jobs
            </a>
            <a href="/analytics" class="px-3 py-2 rounded-md text-sm font-medium ${activeNav === 'analytics' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'}">
              <i class="fas fa-chart-bar mr-1"></i> Analytics
            </a>
          </div>
        </div>
        <div class="flex items-center space-x-3">
          <button onclick="computeAllMatches()" class="hidden sm:inline-flex items-center px-3 py-1.5 border border-brand-600 text-brand-600 text-sm font-medium rounded-lg hover:bg-brand-50 transition">
            <i class="fas fa-bolt mr-1"></i> Compute All Matches
          </button>
        </div>
      </div>
    </div>
    <!-- Mobile nav -->
    <div class="md:hidden border-t border-gray-200 px-2 py-2 flex space-x-1">
      <a href="/" class="flex-1 text-center py-2 text-xs font-medium rounded ${activeNav === 'dashboard' ? 'bg-brand-50 text-brand-700' : 'text-gray-600'}"><i class="fas fa-chart-line block text-lg mb-1"></i>Dashboard</a>
      <a href="/students" class="flex-1 text-center py-2 text-xs font-medium rounded ${activeNav === 'students' ? 'bg-brand-50 text-brand-700' : 'text-gray-600'}"><i class="fas fa-users block text-lg mb-1"></i>Students</a>
      <a href="/jobs" class="flex-1 text-center py-2 text-xs font-medium rounded ${activeNav === 'jobs' ? 'bg-brand-50 text-brand-700' : 'text-gray-600'}"><i class="fas fa-building block text-lg mb-1"></i>Jobs</a>
      <a href="/analytics" class="flex-1 text-center py-2 text-xs font-medium rounded ${activeNav === 'analytics' ? 'bg-brand-50 text-brand-700' : 'text-gray-600'}"><i class="fas fa-chart-bar block text-lg mb-1"></i>Analytics</a>
    </div>
  </nav>

  <!-- Main Content -->
  <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
    ${content}
  </main>

  <!-- Toast notification -->
  <div id="toast" class="fixed bottom-4 right-4 bg-gray-900 text-white px-6 py-3 rounded-lg shadow-xl transform translate-y-20 opacity-0 transition-all duration-300 z-50">
    <span id="toast-msg"></span>
  </div>

  <script>
    function showToast(msg, duration=3000) {
      const t = document.getElementById('toast');
      document.getElementById('toast-msg').textContent = msg;
      t.classList.remove('translate-y-20','opacity-0');
      setTimeout(() => t.classList.add('translate-y-20','opacity-0'), duration);
    }

    async function computeAllMatches() {
      showToast('Computing matches for all students...');
      try {
        const r = await fetch('/api/v1/matches/compute-all', { method: 'POST' });
        const d = await r.json();
        if (d.success) {
          showToast('Computed ' + d.data.total_matches + ' matches for ' + d.data.students_processed + ' students!');
          setTimeout(() => location.reload(), 1500);
        }
      } catch(e) { showToast('Error computing matches'); }
    }

    function formatSalary(min, max) {
      if (!min && !max) return 'Not specified';
      const fmt = (n) => '$' + (n/1000) + 'K';
      if (min && max) return fmt(min) + ' - ' + fmt(max);
      if (min) return fmt(min) + '+';
      return 'Up to ' + fmt(max);
    }

    function getScoreColor(score) {
      if (score >= 80) return 'text-emerald-600 bg-emerald-50';
      if (score >= 60) return 'text-blue-600 bg-blue-50';
      if (score >= 40) return 'text-amber-600 bg-amber-50';
      return 'text-red-600 bg-red-50';
    }

    function getScoreBarColor(score) {
      if (score >= 80) return 'bg-emerald-500';
      if (score >= 60) return 'bg-blue-500';
      if (score >= 40) return 'bg-amber-500';
      return 'bg-red-500';
    }

    function getBadgeColor(category) {
      const colors = {
        programming: 'bg-blue-100 text-blue-800',
        framework: 'bg-purple-100 text-purple-800',
        cloud: 'bg-orange-100 text-orange-800',
        devops: 'bg-green-100 text-green-800',
        database: 'bg-red-100 text-red-800',
        ai: 'bg-pink-100 text-pink-800',
        data: 'bg-indigo-100 text-indigo-800',
        architecture: 'bg-teal-100 text-teal-800',
        methodology: 'bg-gray-100 text-gray-800',
        systems: 'bg-yellow-100 text-yellow-800',
        security: 'bg-red-100 text-red-800',
        frontend: 'bg-cyan-100 text-cyan-800',
        design: 'bg-fuchsia-100 text-fuchsia-800'
      };
      return colors[category] || 'bg-gray-100 text-gray-700';
    }
  </script>
</body>
</html>`
}

// Dashboard Page
app.get('/', (c) => {
  return c.html(renderPage('Dashboard', `
    <div id="dashboard-content">
      <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p class="text-gray-500 mt-1">Overview of your job matching platform</p>
      </div>

      <!-- Stats Cards -->
      <div id="stats-grid" class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 loading-pulse"><div class="h-16"></div></div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 loading-pulse"><div class="h-16"></div></div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 loading-pulse"><div class="h-16"></div></div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 loading-pulse"><div class="h-16"></div></div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 loading-pulse"><div class="h-16"></div></div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 loading-pulse"><div class="h-16"></div></div>
      </div>

      <div class="grid lg:grid-cols-2 gap-6">
        <!-- Recent Students -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div class="p-4 border-b border-gray-100 flex justify-between items-center">
            <h2 class="font-semibold text-gray-900"><i class="fas fa-users mr-2 text-brand-500"></i>Students</h2>
            <a href="/students" class="text-sm text-brand-600 hover:text-brand-700">View all <i class="fas fa-arrow-right ml-1"></i></a>
          </div>
          <div id="students-list" class="divide-y divide-gray-50">
            <div class="p-4 loading-pulse"><div class="h-12 bg-gray-100 rounded"></div></div>
          </div>
        </div>

        <!-- Top Jobs -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div class="p-4 border-b border-gray-100 flex justify-between items-center">
            <h2 class="font-semibold text-gray-900"><i class="fas fa-building mr-2 text-brand-500"></i>Active Jobs</h2>
            <a href="/jobs" class="text-sm text-brand-600 hover:text-brand-700">View all <i class="fas fa-arrow-right ml-1"></i></a>
          </div>
          <div id="jobs-list" class="divide-y divide-gray-50">
            <div class="p-4 loading-pulse"><div class="h-12 bg-gray-100 rounded"></div></div>
          </div>
        </div>
      </div>

      <!-- Trending Skills -->
      <div class="mt-6 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="p-4 border-b border-gray-100">
          <h2 class="font-semibold text-gray-900"><i class="fas fa-fire mr-2 text-orange-500"></i>Trending Skills (Most In-Demand)</h2>
        </div>
        <div id="skills-chart" class="p-4">
          <div class="loading-pulse"><div class="h-40 bg-gray-100 rounded"></div></div>
        </div>
      </div>
    </div>

    <script>
      async function loadDashboard() {
        // Load stats
        const statsR = await fetch('/api/v1/dashboard/stats');
        const statsD = await statsR.json();
        if (statsD.success) {
          const s = statsD.data;
          document.getElementById('stats-grid').innerHTML = [
            { icon: 'fa-users', color: 'blue', label: 'Students', value: s.total_students },
            { icon: 'fa-building', color: 'purple', label: 'Active Jobs', value: s.total_jobs },
            { icon: 'fa-link', color: 'green', label: 'Total Matches', value: s.total_matches },
            { icon: 'fa-file-alt', color: 'orange', label: 'Resumes', value: s.total_resumes },
            { icon: 'fa-star', color: 'yellow', label: 'Avg Score', value: s.avg_match_score + '%' },
            { icon: 'fa-trophy', color: 'emerald', label: 'High Matches (70+)', value: s.high_quality_matches }
          ].map(c => \`
            <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 card-hover">
              <div class="flex items-center space-x-3">
                <div class="w-10 h-10 bg-\${c.color}-50 rounded-lg flex items-center justify-center">
                  <i class="fas \${c.icon} text-\${c.color}-500"></i>
                </div>
                <div>
                  <p class="text-2xl font-bold text-gray-900">\${c.value}</p>
                  <p class="text-xs text-gray-500">\${c.label}</p>
                </div>
              </div>
            </div>
          \`).join('');
        }

        // Load students
        const studR = await fetch('/api/v1/students?limit=5');
        const studD = await studR.json();
        if (studD.success) {
          document.getElementById('students-list').innerHTML = studD.data.map(s => \`
            <a href="/students/\${s.id}" class="flex items-center p-3 hover:bg-gray-50 transition">
              <div class="w-9 h-9 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-semibold text-sm mr-3">
                \${s.full_name.split(' ').map(n => n[0]).join('')}
              </div>
              <div class="flex-1 min-w-0">
                <p class="text-sm font-medium text-gray-900 truncate">\${s.full_name}</p>
                <p class="text-xs text-gray-500">\${s.degree || ''} \${ s.university ? '@ ' + s.university : ''}</p>
              </div>
              <div class="text-right">
                <span class="text-xs text-gray-400">\${s.total_years_exp}y exp</span>
                <p class="text-xs text-gray-400">\${s.location_city || ''}, \${s.location_state || ''}</p>
              </div>
              <i class="fas fa-chevron-right ml-2 text-gray-300 text-xs"></i>
            </a>
          \`).join('') || '<p class="p-4 text-gray-400 text-sm">No students yet</p>';
        }

        // Load jobs
        const jobsR = await fetch('/api/v1/jobs?limit=5');
        const jobsD = await jobsR.json();
        if (jobsD.success) {
          document.getElementById('jobs-list').innerHTML = jobsD.data.map(j => \`
            <a href="/jobs/\${j.id}" class="flex items-center p-3 hover:bg-gray-50 transition">
              <div class="w-9 h-9 rounded-full bg-purple-100 flex items-center justify-center text-purple-700 font-semibold text-xs mr-3">
                \${j.company.substring(0,2).toUpperCase()}
              </div>
              <div class="flex-1 min-w-0">
                <p class="text-sm font-medium text-gray-900 truncate">\${j.title}</p>
                <p class="text-xs text-gray-500">\${j.company} &middot; \${j.location_city || ''}, \${j.location_state || ''}</p>
              </div>
              <div class="text-right">
                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium \${j.remote_type==='remote'?'bg-green-100 text-green-700':j.remote_type==='hybrid'?'bg-blue-100 text-blue-700':'bg-gray-100 text-gray-700'}">\${j.remote_type}</span>
              </div>
              <i class="fas fa-chevron-right ml-2 text-gray-300 text-xs"></i>
            </a>
          \`).join('') || '<p class="p-4 text-gray-400 text-sm">No jobs yet</p>';
        }

        // Load trending skills
        const skillsR = await fetch('/api/v1/analytics/skills/trending');
        const skillsD = await skillsR.json();
        if (skillsD.success && skillsD.data.length > 0) {
          const maxCount = Math.max(...skillsD.data.map(s => s.job_count));
          document.getElementById('skills-chart').innerHTML = \`
            <div class="space-y-2">
              \${skillsD.data.slice(0, 12).map(s => \`
                <div class="flex items-center gap-3">
                  <span class="text-sm text-gray-700 w-28 text-right truncate">\${s.name}</span>
                  <div class="flex-1 bg-gray-100 rounded-full h-5 overflow-hidden">
                    <div class="h-full rounded-full score-bar \${getBadgeColor(s.category).replace('text-','bg-').split(' ')[0]}" style="width:\${(s.job_count/maxCount)*100}%">
                      <span class="text-xs font-medium px-2 leading-5 text-white">\${s.job_count} jobs</span>
                    </div>
                  </div>
                </div>
              \`).join('')}
            </div>
          \`;
        }
      }
      loadDashboard();
    </script>
  `, 'dashboard'))
})

// Students List Page
app.get('/students', (c) => {
  return c.html(renderPage('Students', `
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-3">
      <div>
        <h1 class="text-2xl font-bold text-gray-900">Students</h1>
        <p class="text-gray-500 text-sm mt-1">Manage candidate profiles and track their matches</p>
      </div>
      <div class="flex gap-2 w-full sm:w-auto">
        <div class="relative flex-1 sm:flex-initial">
          <input id="search" type="text" placeholder="Search students..." class="w-full sm:w-64 pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-brand-500 focus:border-transparent" onkeyup="searchStudents(this.value)">
          <i class="fas fa-search absolute left-3 top-2.5 text-gray-400 text-sm"></i>
        </div>
      </div>
    </div>

    <div id="students-grid" class="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
      <div class="bg-white rounded-xl p-6 shadow-sm border loading-pulse"><div class="h-32"></div></div>
      <div class="bg-white rounded-xl p-6 shadow-sm border loading-pulse"><div class="h-32"></div></div>
      <div class="bg-white rounded-xl p-6 shadow-sm border loading-pulse"><div class="h-32"></div></div>
    </div>

    <script>
      let searchTimeout;
      function searchStudents(q) {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => loadStudents(q), 300);
      }

      async function loadStudents(search='') {
        const r = await fetch('/api/v1/students?limit=50&search=' + encodeURIComponent(search));
        const d = await r.json();
        if (!d.success) return;

        const grid = document.getElementById('students-grid');
        if (d.data.length === 0) {
          grid.innerHTML = '<div class="col-span-full text-center py-12"><i class="fas fa-users text-4xl text-gray-300 mb-3"></i><p class="text-gray-400">No students found</p></div>';
          return;
        }

        grid.innerHTML = d.data.map(s => {
          const initials = s.full_name.split(' ').map(n => n[0]).join('');
          const roles = s.preferred_roles ? JSON.parse(s.preferred_roles.replace(/'/g,'"').replace(/^\\[|\\]$/g,'').split(',').map(r => '"'+r.trim().replace(/"/g,'')+'"').join(',').replace(/^/,'[').replace(/$/,']')) : [];
          return \`
          <a href="/students/\${s.id}" class="bg-white rounded-xl p-5 shadow-sm border border-gray-100 card-hover block">
            <div class="flex items-start gap-3">
              <div class="w-12 h-12 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                \${initials}
              </div>
              <div class="flex-1 min-w-0">
                <h3 class="font-semibold text-gray-900 truncate">\${s.full_name}</h3>
                <p class="text-sm text-gray-500 truncate">\${s.email}</p>
                <div class="flex items-center gap-2 mt-1 text-xs text-gray-400">
                  <span><i class="fas fa-map-marker-alt mr-1"></i>\${s.location_city || '?'}, \${s.location_state || '?'}</span>
                  <span>&middot;</span>
                  <span>\${s.total_years_exp}y exp</span>
                </div>
              </div>
            </div>
            <div class="mt-3 pt-3 border-t border-gray-50">
              <div class="flex items-center gap-1 text-xs text-gray-500 mb-2">
                <i class="fas fa-graduation-cap mr-1"></i>
                <span>\${s.degree || 'N/A'}</span>
                <span class="text-gray-300 mx-1">&middot;</span>
                <span class="truncate">\${s.university || 'N/A'}</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium \${s.work_auth_status === 'us_citizen' ? 'bg-green-100 text-green-700' : s.work_auth_status === 'green_card' ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'}">
                  \${(s.work_auth_status || 'unknown').replace('_',' ').toUpperCase()}
                </span>
                <span class="text-xs text-brand-600 font-medium">View Profile <i class="fas fa-arrow-right ml-1"></i></span>
              </div>
            </div>
          </a>
        \`}).join('');
      }
      loadStudents();
    </script>
  `, 'students'))
})

// Student Detail Page
app.get('/students/:id', (c) => {
  const id = c.req.param('id')
  return c.html(renderPage('Student Profile', `
    <div id="student-page">
      <div class="loading-pulse"><div class="h-96 bg-white rounded-xl"></div></div>
    </div>

    <script>
      const STUDENT_ID = ${id};

      async function loadStudentPage() {
        // Load student profile
        const sr = await fetch('/api/v1/students/' + STUDENT_ID);
        const sd = await sr.json();
        if (!sd.success) { document.getElementById('student-page').innerHTML = '<div class="text-center py-20"><h2 class="text-xl text-gray-500">Student not found</h2></div>'; return; }
        const s = sd.data;

        // Load stats
        const statR = await fetch('/api/v1/students/' + STUDENT_ID + '/stats');
        const statD = await statR.json();
        const stats = statD.data || {};

        const experience = JSON.parse(s.experience_json || '[]');
        const projects = JSON.parse(s.projects_json || '[]');
        const certifications = JSON.parse(s.certifications_json || '[]');
        const initials = s.full_name.split(' ').map(n => n[0]).join('');

        document.getElementById('student-page').innerHTML = \`
          <!-- Back button + header -->
          <div class="flex items-center gap-2 mb-4">
            <a href="/students" class="text-gray-400 hover:text-gray-600"><i class="fas fa-arrow-left"></i></a>
            <h1 class="text-2xl font-bold text-gray-900">\${s.full_name}</h1>
            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium \${s.work_auth_status === 'us_citizen' ? 'bg-green-100 text-green-700' : s.work_auth_status === 'green_card' ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'}">
              \${(s.work_auth_status || 'unknown').replace('_',' ').toUpperCase()}
            </span>
          </div>

          <!-- Stats row -->
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            <div class="bg-white rounded-lg p-3 shadow-sm border text-center">
              <p class="text-2xl font-bold text-brand-600">\${stats.total_matches}</p>
              <p class="text-xs text-gray-500">Matches</p>
            </div>
            <div class="bg-white rounded-lg p-3 shadow-sm border text-center">
              <p class="text-2xl font-bold text-emerald-600">\${stats.high_matches}</p>
              <p class="text-xs text-gray-500">High (70+)</p>
            </div>
            <div class="bg-white rounded-lg p-3 shadow-sm border text-center">
              <p class="text-2xl font-bold text-purple-600">\${stats.total_resumes}</p>
              <p class="text-xs text-gray-500">Resumes</p>
            </div>
            <div class="bg-white rounded-lg p-3 shadow-sm border text-center">
              <p class="text-2xl font-bold text-amber-600">\${stats.avg_match_score}%</p>
              <p class="text-xs text-gray-500">Avg Score</p>
            </div>
          </div>

          <!-- Tabs -->
          <div class="border-b border-gray-200 mb-6">
            <nav class="flex space-x-6">
              <button onclick="showTab('profile')" id="tab-profile" class="tab-btn pb-3 text-sm font-medium border-b-2 border-brand-600 text-brand-600">Profile</button>
              <button onclick="showTab('matches')" id="tab-matches" class="tab-btn pb-3 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700">Matched Jobs (\${stats.total_matches})</button>
              <button onclick="showTab('resumes')" id="tab-resumes" class="tab-btn pb-3 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700">Resumes (\${stats.total_resumes})</button>
            </nav>
          </div>

          <!-- Tab Content -->
          <div id="tab-content-profile" class="tab-content">
            <div class="grid lg:grid-cols-3 gap-6">
              <!-- Left: Info -->
              <div class="space-y-4">
                <div class="bg-white rounded-xl p-5 shadow-sm border">
                  <div class="flex items-center gap-3 mb-4">
                    <div class="w-14 h-14 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white font-bold text-lg">\${initials}</div>
                    <div>
                      <h3 class="font-semibold text-gray-900">\${s.full_name}</h3>
                      <p class="text-sm text-gray-500">\${s.email}</p>
                    </div>
                  </div>
                  <div class="space-y-2 text-sm">
                    <div class="flex justify-between"><span class="text-gray-500">Phone</span><span class="text-gray-900">\${s.phone || 'N/A'}</span></div>
                    <div class="flex justify-between"><span class="text-gray-500">Location</span><span class="text-gray-900">\${s.location_city || '?'}, \${s.location_state || '?'}</span></div>
                    <div class="flex justify-between"><span class="text-gray-500">Remote Pref</span><span class="text-gray-900 capitalize">\${s.remote_preference || 'any'}</span></div>
                    <div class="flex justify-between"><span class="text-gray-500">Relocate</span><span class="text-gray-900">\${s.willing_to_relocate ? 'Yes' : 'No'}</span></div>
                    <div class="flex justify-between"><span class="text-gray-500">Experience</span><span class="text-gray-900">\${s.total_years_exp} years</span></div>
                  </div>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border">
                  <h4 class="font-semibold text-gray-900 mb-3"><i class="fas fa-graduation-cap mr-2 text-brand-500"></i>Education</h4>
                  <p class="text-sm text-gray-900">\${s.degree || 'N/A'}</p>
                  <p class="text-sm text-gray-500">\${s.university || 'N/A'}</p>
                  <p class="text-sm text-gray-400">Class of \${s.graduation_year || 'N/A'} \${s.gpa ? '&middot; GPA: ' + s.gpa : ''}</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border">
                  <h4 class="font-semibold text-gray-900 mb-3"><i class="fas fa-certificate mr-2 text-amber-500"></i>Certifications</h4>
                  \${certifications.length > 0 ? certifications.map(c => \`
                    <div class="mb-2 last:mb-0">
                      <p class="text-sm font-medium text-gray-900">\${c.name}</p>
                      <p class="text-xs text-gray-500">\${c.issuer} &middot; \${c.date}</p>
                    </div>
                  \`).join('') : '<p class="text-sm text-gray-400">No certifications</p>'}
                </div>
              </div>

              <!-- Middle: Skills -->
              <div class="space-y-4">
                <div class="bg-white rounded-xl p-5 shadow-sm border">
                  <h4 class="font-semibold text-gray-900 mb-3"><i class="fas fa-code mr-2 text-brand-500"></i>Skills (\${s.skills?.length || 0})</h4>
                  <div class="flex flex-wrap gap-1.5">
                    \${(s.skills || []).map(sk => \`
                      <span class="skill-badge \${getBadgeColor(sk.category)} \${sk.is_primary ? 'ring-1 ring-brand-300' : ''}">
                        \${sk.skill_name}
                        <span class="ml-1 opacity-60">\${sk.proficiency === 'expert' ? '★★★' : sk.proficiency === 'advanced' ? '★★' : '★'}</span>
                      </span>
                    \`).join('')}
                  </div>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border">
                  <h4 class="font-semibold text-gray-900 mb-3"><i class="fas fa-rocket mr-2 text-purple-500"></i>Projects</h4>
                  \${projects.map(p => \`
                    <div class="mb-3 last:mb-0 p-3 bg-gray-50 rounded-lg">
                      <p class="text-sm font-medium text-gray-900">\${p.name}</p>
                      <p class="text-xs text-gray-500 mb-1">\${p.description}</p>
                      <div class="flex flex-wrap gap-1 mb-1">
                        \${(p.technologies || []).map(t => '<span class="text-xs bg-brand-50 text-brand-700 px-1.5 py-0.5 rounded">' + t + '</span>').join('')}
                      </div>
                      <ul class="text-xs text-gray-600 space-y-0.5">
                        \${(p.bullets || []).map(b => '<li class="flex"><span class="mr-1.5 text-brand-400">&bull;</span>' + b + '</li>').join('')}
                      </ul>
                    </div>
                  \`).join('') || '<p class="text-sm text-gray-400">No projects</p>'}
                </div>
              </div>

              <!-- Right: Experience -->
              <div class="space-y-4">
                <div class="bg-white rounded-xl p-5 shadow-sm border">
                  <h4 class="font-semibold text-gray-900 mb-3"><i class="fas fa-briefcase mr-2 text-green-500"></i>Experience</h4>
                  \${experience.map(e => \`
                    <div class="mb-4 last:mb-0 pb-4 last:pb-0 border-b last:border-0 border-gray-100">
                      <div class="flex justify-between items-start">
                        <div>
                          <p class="text-sm font-semibold text-gray-900">\${e.title}</p>
                          <p class="text-sm text-brand-600">\${e.company}</p>
                        </div>
                      </div>
                      <p class="text-xs text-gray-400 mt-0.5">\${e.dates} &middot; \${e.location}</p>
                      <ul class="mt-2 text-xs text-gray-600 space-y-1">
                        \${(e.bullets || []).map(b => '<li class="flex"><span class="mr-1.5 mt-0.5 text-gray-400">&bull;</span><span>' + b + '</span></li>').join('')}
                      </ul>
                    </div>
                  \`).join('') || '<p class="text-sm text-gray-400">No experience</p>'}
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border">
                  <h4 class="font-semibold text-gray-900 mb-2"><i class="fas fa-file-alt mr-2 text-gray-500"></i>Summary</h4>
                  <p class="text-sm text-gray-600 leading-relaxed">\${s.summary_text || 'No summary provided.'}</p>
                </div>
              </div>
            </div>
          </div>

          <div id="tab-content-matches" class="tab-content hidden"></div>
          <div id="tab-content-resumes" class="tab-content hidden"></div>
        \`;

        // Load matches
        loadMatches();
        loadResumes();
      }

      function showTab(tab) {
        document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
        document.querySelectorAll('.tab-btn').forEach(el => {
          el.classList.remove('border-brand-600','text-brand-600');
          el.classList.add('border-transparent','text-gray-500');
        });
        document.getElementById('tab-content-' + tab).classList.remove('hidden');
        const btn = document.getElementById('tab-' + tab);
        btn.classList.remove('border-transparent','text-gray-500');
        btn.classList.add('border-brand-600','text-brand-600');
      }

      async function computeMatches() {
        showToast('Computing matches...');
        const r = await fetch('/api/v1/students/' + STUDENT_ID + '/matches/compute', { method: 'POST' });
        const d = await r.json();
        if (d.success) {
          showToast('Computed ' + d.data.matches_computed + ' matches!');
          setTimeout(loadMatches, 500);
        }
      }

      async function loadMatches() {
        const r = await fetch('/api/v1/students/' + STUDENT_ID + '/matches?limit=50');
        const d = await r.json();

        const container = document.getElementById('tab-content-matches');
        if (!d.success || d.data.length === 0) {
          container.innerHTML = \`
            <div class="text-center py-12">
              <i class="fas fa-search text-4xl text-gray-300 mb-3"></i>
              <p class="text-gray-500 mb-4">No matches yet. Compute matches to find relevant jobs.</p>
              <button onclick="computeMatches()" class="px-6 py-2 bg-brand-600 text-white rounded-lg text-sm hover:bg-brand-700 transition">
                <i class="fas fa-bolt mr-2"></i>Compute Matches
              </button>
            </div>
          \`;
          return;
        }

        container.innerHTML = \`
          <div class="flex justify-between items-center mb-4">
            <p class="text-sm text-gray-500">\${d.meta.total} matched jobs found</p>
            <button onclick="computeMatches()" class="text-sm text-brand-600 hover:text-brand-700"><i class="fas fa-sync-alt mr-1"></i>Recompute</button>
          </div>
          <div class="space-y-3">
            \${d.data.map(m => {
              const matched = JSON.parse(m.matched_skills || '[]');
              const missing = JSON.parse(m.missing_skills || '[]');
              return \`
              <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 card-hover fade-in">
                <div class="flex items-start gap-4">
                  <div class="flex-shrink-0">
                    <div class="w-14 h-14 rounded-lg flex items-center justify-center text-lg font-bold \${getScoreColor(m.overall_score)}">
                      \${Math.round(m.overall_score)}%
                    </div>
                  </div>
                  <div class="flex-1 min-w-0">
                    <div class="flex items-start justify-between">
                      <div>
                        <h3 class="font-semibold text-gray-900">\${m.title}</h3>
                        <p class="text-sm text-gray-500">\${m.company} &middot; \${m.location_city || ''}, \${m.location_state || ''}</p>
                      </div>
                      <div class="flex items-center gap-2 flex-shrink-0">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium \${m.remote_type==='remote'?'bg-green-100 text-green-700':m.remote_type==='hybrid'?'bg-blue-100 text-blue-700':'bg-gray-100 text-gray-700'}">\${m.remote_type}</span>
                        \${m.salary_min ? '<span class="text-xs text-gray-500">' + formatSalary(m.salary_min, m.salary_max) + '</span>' : ''}
                      </div>
                    </div>

                    <!-- Score breakdown -->
                    <div class="grid grid-cols-5 gap-2 mt-3">
                      \${[
                        { label: 'Skill', score: m.skill_score },
                        { label: 'Semantic', score: m.semantic_score },
                        { label: 'Experience', score: m.experience_score },
                        { label: 'Education', score: m.education_score },
                        { label: 'Location', score: m.location_score }
                      ].map(sc => \`
                        <div>
                          <div class="flex justify-between text-xs mb-0.5">
                            <span class="text-gray-400">\${sc.label}</span>
                            <span class="font-medium text-gray-600">\${Math.round(sc.score)}</span>
                          </div>
                          <div class="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div class="h-full rounded-full score-bar \${getScoreBarColor(sc.score)}" style="width:\${sc.score}%"></div>
                          </div>
                        </div>
                      \`).join('')}
                    </div>

                    <!-- Skills -->
                    <div class="mt-3 flex flex-wrap gap-1">
                      \${matched.slice(0,6).map(s => '<span class="skill-badge bg-green-100 text-green-800"><i class="fas fa-check text-green-500 mr-1" style="font-size:8px"></i>' + s + '</span>').join('')}
                      \${missing.slice(0,3).map(s => '<span class="skill-badge bg-red-50 text-red-600"><i class="fas fa-times text-red-400 mr-1" style="font-size:8px"></i>' + s + '</span>').join('')}
                      \${matched.length + missing.length > 9 ? '<span class="skill-badge bg-gray-100 text-gray-500">+' + (matched.length + missing.length - 9) + ' more</span>' : ''}
                    </div>

                    <!-- Actions -->
                    <div class="flex items-center gap-2 mt-3 pt-3 border-t border-gray-50">
                      \${m.resume ? \`
                        <a href="/resumes/\${m.resume.id}" class="inline-flex items-center px-3 py-1.5 text-xs font-medium bg-green-50 text-green-700 rounded-lg hover:bg-green-100">
                          <i class="fas fa-file-pdf mr-1"></i>View Resume (ATS: \${m.resume.ats_score_estimate}%)
                        </a>
                      \` : \`
                        <button onclick="generateResume(\${m.id})" class="inline-flex items-center px-3 py-1.5 text-xs font-medium bg-brand-50 text-brand-700 rounded-lg hover:bg-brand-100">
                          <i class="fas fa-magic mr-1"></i>Generate Resume
                        </button>
                      \`}
                      <a href="\${m.apply_url}" target="_blank" class="inline-flex items-center px-3 py-1.5 text-xs font-medium bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100">
                        <i class="fas fa-external-link-alt mr-1"></i>Apply
                      </a>
                      <a href="/jobs/\${m.job_id}" class="inline-flex items-center px-3 py-1.5 text-xs font-medium text-gray-500 hover:text-gray-700">
                        <i class="fas fa-info-circle mr-1"></i>Job Details
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            \`}).join('')}
          </div>
        \`;
      }

      async function generateResume(matchId) {
        showToast('Generating ATS-optimized resume...');
        const r = await fetch('/api/v1/matches/' + matchId + '/resume/generate', { method: 'POST' });
        const d = await r.json();
        if (d.success) {
          showToast('Resume generated! ATS Score: ' + d.data.ats_score_estimate + '%');
          setTimeout(loadMatches, 500);
          setTimeout(loadResumes, 600);
        } else {
          showToast('Error generating resume');
        }
      }

      async function loadResumes() {
        const r = await fetch('/api/v1/students/' + STUDENT_ID + '/resumes');
        const d = await r.json();

        const container = document.getElementById('tab-content-resumes');
        if (!d.success || d.data.length === 0) {
          container.innerHTML = '<div class="text-center py-12"><i class="fas fa-file-alt text-4xl text-gray-300 mb-3"></i><p class="text-gray-400">No resumes generated yet. Match jobs first, then generate resumes.</p></div>';
          return;
        }

        container.innerHTML = \`
          <div class="space-y-3">
            \${d.data.map(r => \`
              <a href="/resumes/\${r.id}" class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 card-hover flex items-center gap-4 block">
                <div class="w-12 h-12 rounded-lg bg-red-50 flex items-center justify-center flex-shrink-0">
                  <i class="fas fa-file-pdf text-red-500 text-lg"></i>
                </div>
                <div class="flex-1 min-w-0">
                  <h3 class="font-medium text-gray-900 truncate">\${r.job_title}</h3>
                  <p class="text-sm text-gray-500">\${r.company} &middot; Version \${r.version}</p>
                </div>
                <div class="text-right flex-shrink-0">
                  <div class="inline-flex items-center px-2.5 py-1 rounded-full text-sm font-bold \${getScoreColor(r.ats_score_estimate)}">
                    ATS: \${r.ats_score_estimate}%
                  </div>
                  <p class="text-xs text-gray-400 mt-1">\${new Date(r.created_at).toLocaleDateString()}</p>
                </div>
              </a>
            \`).join('')}
          </div>
        \`;
      }

      loadStudentPage();
    </script>
  `, 'students'))
})

// Jobs List Page
app.get('/jobs', (c) => {
  return c.html(renderPage('Jobs', `
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-3">
      <div>
        <h1 class="text-2xl font-bold text-gray-900">Job Listings</h1>
        <p class="text-gray-500 text-sm mt-1">Browse aggregated job listings from multiple sources</p>
      </div>
      <div class="flex gap-2 flex-wrap">
        <input id="job-search" type="text" placeholder="Search jobs..." class="pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-brand-500 focus:border-transparent relative" onkeyup="searchJobs()">
        <select id="filter-remote" onchange="searchJobs()" class="py-2 px-3 border border-gray-300 rounded-lg text-sm">
          <option value="">All Types</option>
          <option value="remote">Remote</option>
          <option value="hybrid">Hybrid</option>
          <option value="onsite">Onsite</option>
        </select>
        <select id="filter-source" onchange="searchJobs()" class="py-2 px-3 border border-gray-300 rounded-lg text-sm">
          <option value="">All Sources</option>
          <option value="greenhouse">Greenhouse</option>
          <option value="lever">Lever</option>
          <option value="linkedin">LinkedIn</option>
          <option value="indeed">Indeed</option>
        </select>
      </div>
    </div>

    <div id="jobs-grid" class="space-y-3">
      <div class="bg-white rounded-xl p-6 shadow-sm border loading-pulse"><div class="h-20"></div></div>
      <div class="bg-white rounded-xl p-6 shadow-sm border loading-pulse"><div class="h-20"></div></div>
    </div>

    <script>
      let jobSearchTimeout;
      function searchJobs() {
        clearTimeout(jobSearchTimeout);
        jobSearchTimeout = setTimeout(loadJobs, 300);
      }

      async function loadJobs() {
        const search = document.getElementById('job-search').value;
        const remote = document.getElementById('filter-remote').value;
        const source = document.getElementById('filter-source').value;

        let url = '/api/v1/jobs?limit=50';
        if (search) url += '&search=' + encodeURIComponent(search);
        if (remote) url += '&remote=' + remote;
        if (source) url += '&source=' + source;

        const r = await fetch(url);
        const d = await r.json();
        const grid = document.getElementById('jobs-grid');

        if (!d.success || d.data.length === 0) {
          grid.innerHTML = '<div class="text-center py-12"><i class="fas fa-building text-4xl text-gray-300 mb-3"></i><p class="text-gray-400">No jobs found</p></div>';
          return;
        }

        grid.innerHTML = d.data.map(j => \`
          <a href="/jobs/\${j.id}" class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 card-hover block fade-in">
            <div class="flex items-start gap-4">
              <div class="w-11 h-11 rounded-lg bg-purple-50 flex items-center justify-center text-purple-700 font-bold text-xs flex-shrink-0">
                \${j.company.substring(0,2).toUpperCase()}
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-start justify-between gap-2">
                  <div>
                    <h3 class="font-semibold text-gray-900">\${j.title}</h3>
                    <p class="text-sm text-gray-500">\${j.company}</p>
                  </div>
                  <div class="flex items-center gap-2 flex-shrink-0">
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium \${j.remote_type==='remote'?'bg-green-100 text-green-700':j.remote_type==='hybrid'?'bg-blue-100 text-blue-700':'bg-gray-100 text-gray-700'}">\${j.remote_type}</span>
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600">\${j.source}</span>
                  </div>
                </div>
                <div class="flex items-center gap-3 mt-2 text-xs text-gray-400">
                  <span><i class="fas fa-map-marker-alt mr-1"></i>\${j.location_city || '?'}, \${j.location_state || '?'}</span>
                  \${j.salary_min ? '<span><i class="fas fa-dollar-sign mr-1"></i>' + formatSalary(j.salary_min, j.salary_max) + '</span>' : ''}
                  \${j.experience_min ? '<span><i class="fas fa-clock mr-1"></i>' + j.experience_min + '-' + (j.experience_max||'?') + ' years</span>' : ''}
                  \${j.seniority_level ? '<span class="capitalize"><i class="fas fa-level-up-alt mr-1"></i>' + j.seniority_level + '</span>' : ''}
                  \${j.posted_at ? '<span><i class="fas fa-calendar mr-1"></i>' + new Date(j.posted_at).toLocaleDateString() + '</span>' : ''}
                </div>
              </div>
            </div>
          </a>
        \`).join('');
      }
      loadJobs();
    </script>
  `, 'jobs'))
})

// Job Detail Page
app.get('/jobs/:id', (c) => {
  const id = c.req.param('id')
  return c.html(renderPage('Job Details', `
    <div id="job-detail">
      <div class="loading-pulse"><div class="h-96 bg-white rounded-xl"></div></div>
    </div>
    <script>
      async function loadJob() {
        const r = await fetch('/api/v1/jobs/${id}');
        const d = await r.json();
        if (!d.success) { document.getElementById('job-detail').innerHTML = '<div class="text-center py-20"><h2 class="text-xl text-gray-500">Job not found</h2></div>'; return; }
        const j = d.data;
        const skills = j.skills || [];

        document.getElementById('job-detail').innerHTML = \`
          <div class="flex items-center gap-2 mb-4">
            <a href="/jobs" class="text-gray-400 hover:text-gray-600"><i class="fas fa-arrow-left"></i></a>
            <h1 class="text-2xl font-bold text-gray-900">\${j.title}</h1>
          </div>

          <div class="grid lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 space-y-4">
              <div class="bg-white rounded-xl p-6 shadow-sm border">
                <div class="flex items-center gap-3 mb-4">
                  <div class="w-12 h-12 rounded-lg bg-purple-50 flex items-center justify-center text-purple-700 font-bold">\${j.company.substring(0,2).toUpperCase()}</div>
                  <div>
                    <h2 class="text-lg font-semibold text-gray-900">\${j.company}</h2>
                    <div class="flex items-center gap-2 text-sm text-gray-500">
                      <span>\${j.location_city || '?'}, \${j.location_state || '?'}</span>
                      <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium \${j.remote_type==='remote'?'bg-green-100 text-green-700':j.remote_type==='hybrid'?'bg-blue-100 text-blue-700':'bg-gray-100 text-gray-700'}">\${j.remote_type}</span>
                    </div>
                  </div>
                </div>
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                  <div class="bg-gray-50 rounded-lg p-2.5 text-center">
                    <p class="text-xs text-gray-500">Salary</p>
                    <p class="text-sm font-semibold text-gray-900">\${formatSalary(j.salary_min, j.salary_max)}</p>
                  </div>
                  <div class="bg-gray-50 rounded-lg p-2.5 text-center">
                    <p class="text-xs text-gray-500">Experience</p>
                    <p class="text-sm font-semibold text-gray-900">\${j.experience_min || '?'}-\${j.experience_max || '?'} years</p>
                  </div>
                  <div class="bg-gray-50 rounded-lg p-2.5 text-center">
                    <p class="text-xs text-gray-500">Education</p>
                    <p class="text-sm font-semibold text-gray-900 capitalize">\${j.education_req || 'Any'}</p>
                  </div>
                  <div class="bg-gray-50 rounded-lg p-2.5 text-center">
                    <p class="text-xs text-gray-500">Visa</p>
                    <p class="text-sm font-semibold text-gray-900">\${j.visa_sponsored ? 'Sponsored' : 'Not Sponsored'}</p>
                  </div>
                </div>
                <a href="\${j.apply_url}" target="_blank" class="inline-flex items-center px-6 py-2.5 bg-brand-600 text-white rounded-lg text-sm font-medium hover:bg-brand-700 transition w-full justify-center sm:w-auto">
                  <i class="fas fa-external-link-alt mr-2"></i>Apply Now
                </a>
              </div>

              <div class="bg-white rounded-xl p-6 shadow-sm border">
                <h3 class="font-semibold text-gray-900 mb-3">Job Description</h3>
                <div class="text-sm text-gray-600 leading-relaxed whitespace-pre-line">\${j.description}</div>
              </div>

              \${j.requirements ? \`
              <div class="bg-white rounded-xl p-6 shadow-sm border">
                <h3 class="font-semibold text-gray-900 mb-3">Requirements</h3>
                <div class="text-sm text-gray-600 leading-relaxed whitespace-pre-line">\${j.requirements}</div>
              </div>
              \` : ''}
            </div>

            <div class="space-y-4">
              <div class="bg-white rounded-xl p-5 shadow-sm border">
                <h3 class="font-semibold text-gray-900 mb-3"><i class="fas fa-code mr-2 text-brand-500"></i>Required Skills</h3>
                <div class="space-y-1.5">
                  \${skills.filter(s => s.importance === 'required').map(s => \`
                    <div class="flex items-center gap-2">
                      <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                      <span class="text-sm text-gray-700">\${s.skill_name}</span>
                      <span class="skill-badge bg-red-50 text-red-600 ml-auto">Required</span>
                    </div>
                  \`).join('')}
                </div>
                \${skills.filter(s => s.importance === 'preferred').length > 0 ? \`
                  <h4 class="font-medium text-gray-700 mt-4 mb-2 text-sm">Preferred</h4>
                  <div class="space-y-1.5">
                    \${skills.filter(s => s.importance === 'preferred').map(s => \`
                      <div class="flex items-center gap-2">
                        <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                        <span class="text-sm text-gray-700">\${s.skill_name}</span>
                        <span class="skill-badge bg-amber-50 text-amber-600 ml-auto">Preferred</span>
                      </div>
                    \`).join('')}
                  </div>
                \` : ''}
                \${skills.filter(s => s.importance === 'nice_to_have').length > 0 ? \`
                  <h4 class="font-medium text-gray-700 mt-4 mb-2 text-sm">Nice to Have</h4>
                  <div class="space-y-1.5">
                    \${skills.filter(s => s.importance === 'nice_to_have').map(s => \`
                      <div class="flex items-center gap-2">
                        <span class="w-1.5 h-1.5 rounded-full bg-gray-400"></span>
                        <span class="text-sm text-gray-700">\${s.skill_name}</span>
                      </div>
                    \`).join('')}
                  </div>
                \` : ''}
              </div>
              <div class="bg-white rounded-xl p-5 shadow-sm border">
                <h3 class="font-semibold text-gray-900 mb-3"><i class="fas fa-info-circle mr-2 text-gray-400"></i>Listing Info</h3>
                <div class="space-y-2 text-sm">
                  <div class="flex justify-between"><span class="text-gray-500">Source</span><span class="text-gray-900 capitalize">\${j.source}</span></div>
                  <div class="flex justify-between"><span class="text-gray-500">Type</span><span class="text-gray-900 capitalize">\${(j.job_type||'').replace('_',' ')}</span></div>
                  <div class="flex justify-between"><span class="text-gray-500">Seniority</span><span class="text-gray-900 capitalize">\${j.seniority_level || 'N/A'}</span></div>
                  <div class="flex justify-between"><span class="text-gray-500">Posted</span><span class="text-gray-900">\${j.posted_at ? new Date(j.posted_at).toLocaleDateString() : 'N/A'}</span></div>
                </div>
              </div>
            </div>
          </div>
        \`;
      }
      loadJob();
    </script>
  `, 'jobs'))
})

// Resume Detail Page
app.get('/resumes/:id', (c) => {
  const id = c.req.param('id')
  return c.html(renderPage('Resume', `
    <div id="resume-page">
      <div class="loading-pulse"><div class="h-96 bg-white rounded-xl"></div></div>
    </div>
    <script>
      async function loadResume() {
        const r = await fetch('/api/v1/resumes/${id}');
        const d = await r.json();
        if (!d.success) { document.getElementById('resume-page').innerHTML = '<div class="text-center py-20"><h2 class="text-xl text-gray-500">Resume not found</h2></div>'; return; }
        const res = d.data;
        const content = JSON.parse(res.content_json);
        const atsKw = (res.ats_keywords || '').split(',').filter(Boolean);

        document.getElementById('resume-page').innerHTML = \`
          <div class="flex items-center justify-between mb-4">
            <div class="flex items-center gap-2">
              <a href="/students/\${res.student_id}" class="text-gray-400 hover:text-gray-600"><i class="fas fa-arrow-left"></i></a>
              <h1 class="text-xl font-bold text-gray-900">Resume for \${res.student_name}</h1>
              <span class="text-sm text-gray-400">v\${res.version}</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-bold \${getScoreColor(res.ats_score_estimate)}">
                <i class="fas fa-robot mr-1"></i>ATS Score: \${res.ats_score_estimate}%
              </span>
            </div>
          </div>

          <div class="grid lg:grid-cols-3 gap-6">
            <!-- Resume Preview -->
            <div class="lg:col-span-2">
              <div class="bg-white rounded-xl shadow-sm border p-8" style="font-family: 'Georgia', serif;">
                <!-- Header -->
                <div class="text-center mb-4 pb-3 border-b-2 border-gray-800">
                  <h1 class="text-2xl font-bold text-gray-900 tracking-wide">\${content.header?.name || ''}</h1>
                  <p class="text-sm text-gray-600 mt-1">
                    \${[content.header?.email, content.header?.phone, content.header?.location].filter(Boolean).join(' | ')}
                  </p>
                </div>

                <!-- Summary -->
                <div class="mb-4">
                  <h2 class="text-sm font-bold text-gray-800 uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Professional Summary</h2>
                  <p class="text-sm text-gray-700 leading-relaxed">\${content.summary || ''}</p>
                </div>

                <!-- Skills -->
                <div class="mb-4">
                  <h2 class="text-sm font-bold text-gray-800 uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Technical Skills</h2>
                  <div class="text-sm text-gray-700">
                    \${content.skills?.technical?.length ? '<p><strong>Languages & Frameworks:</strong> ' + content.skills.technical.join(', ') + '</p>' : ''}
                    \${content.skills?.tools?.length ? '<p class="mt-1"><strong>Tools & Platforms:</strong> ' + content.skills.tools.join(', ') + '</p>' : ''}
                    \${content.skills?.other?.length ? '<p class="mt-1"><strong>Other:</strong> ' + content.skills.other.join(', ') + '</p>' : ''}
                  </div>
                </div>

                <!-- Experience -->
                \${content.experience?.length ? \`
                <div class="mb-4">
                  <h2 class="text-sm font-bold text-gray-800 uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Professional Experience</h2>
                  \${content.experience.map(e => \`
                    <div class="mb-3">
                      <div class="flex justify-between items-baseline">
                        <h3 class="text-sm font-bold text-gray-800">\${e.title}</h3>
                        <span class="text-xs text-gray-500">\${e.dates}</span>
                      </div>
                      <p class="text-sm text-gray-600 italic">\${e.company}\${e.location ? ', ' + e.location : ''}</p>
                      <ul class="mt-1 space-y-0.5">
                        \${(e.bullets || []).map(b => '<li class="text-sm text-gray-700 flex"><span class="mr-2">&bull;</span><span>' + b + '</span></li>').join('')}
                      </ul>
                    </div>
                  \`).join('')}
                </div>
                \` : ''}

                <!-- Projects -->
                \${content.projects?.length ? \`
                <div class="mb-4">
                  <h2 class="text-sm font-bold text-gray-800 uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Key Projects</h2>
                  \${content.projects.map(p => \`
                    <div class="mb-2">
                      <div class="flex items-baseline gap-2">
                        <h3 class="text-sm font-bold text-gray-800">\${p.name}</h3>
                        <span class="text-xs text-gray-500">\${(p.technologies || []).join(', ')}</span>
                      </div>
                      <ul class="mt-0.5 space-y-0.5">
                        \${(p.bullets || []).map(b => '<li class="text-sm text-gray-700 flex"><span class="mr-2">&bull;</span><span>' + b + '</span></li>').join('')}
                      </ul>
                    </div>
                  \`).join('')}
                </div>
                \` : ''}

                <!-- Education -->
                \${content.education?.length ? \`
                <div class="mb-4">
                  <h2 class="text-sm font-bold text-gray-800 uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Education</h2>
                  \${content.education.map(e => \`
                    <div class="flex justify-between items-baseline">
                      <div>
                        <p class="text-sm font-bold text-gray-800">\${e.degree}</p>
                        <p class="text-sm text-gray-600">\${e.university}\${e.gpa ? ' | GPA: ' + e.gpa : ''}</p>
                      </div>
                      <span class="text-xs text-gray-500">\${e.year}</span>
                    </div>
                  \`).join('')}
                </div>
                \` : ''}

                <!-- Certifications -->
                \${content.certifications?.length ? \`
                <div>
                  <h2 class="text-sm font-bold text-gray-800 uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Certifications</h2>
                  <ul class="space-y-0.5">
                    \${content.certifications.map(c => \`
                      <li class="text-sm text-gray-700">\${c.name} - \${c.issuer} (\${c.date})</li>
                    \`).join('')}
                  </ul>
                </div>
                \` : ''}
              </div>
            </div>

            <!-- ATS Analysis Sidebar -->
            <div class="space-y-4">
              <div class="bg-white rounded-xl p-5 shadow-sm border">
                <h3 class="font-semibold text-gray-900 mb-3"><i class="fas fa-robot mr-2 text-brand-500"></i>ATS Analysis</h3>
                <div class="text-center mb-4">
                  <div class="inline-flex items-center justify-center w-20 h-20 rounded-full \${getScoreColor(res.ats_score_estimate)}">
                    <span class="text-2xl font-bold">\${res.ats_score_estimate}%</span>
                  </div>
                  <p class="text-sm text-gray-500 mt-1">Estimated ATS Score</p>
                </div>
                <div class="space-y-1.5">
                  <div class="flex items-center gap-2 text-sm">
                    <i class="fas fa-check-circle text-green-500"></i>
                    <span class="text-gray-700">Single-column layout</span>
                  </div>
                  <div class="flex items-center gap-2 text-sm">
                    <i class="fas fa-check-circle text-green-500"></i>
                    <span class="text-gray-700">Standard section headers</span>
                  </div>
                  <div class="flex items-center gap-2 text-sm">
                    <i class="fas fa-check-circle text-green-500"></i>
                    <span class="text-gray-700">No tables or graphics</span>
                  </div>
                  <div class="flex items-center gap-2 text-sm">
                    <i class="fas fa-check-circle text-green-500"></i>
                    <span class="text-gray-700">Standard fonts used</span>
                  </div>
                  <div class="flex items-center gap-2 text-sm">
                    <i class="fas fa-check-circle text-green-500"></i>
                    <span class="text-gray-700">Keywords optimized</span>
                  </div>
                </div>
              </div>

              <div class="bg-white rounded-xl p-5 shadow-sm border">
                <h3 class="font-semibold text-gray-900 mb-3"><i class="fas fa-key mr-2 text-amber-500"></i>ATS Keywords</h3>
                <div class="flex flex-wrap gap-1">
                  \${atsKw.map(k => '<span class="skill-badge bg-amber-50 text-amber-700">' + k.trim() + '</span>').join('')}
                </div>
              </div>

              <div class="bg-white rounded-xl p-5 shadow-sm border">
                <h3 class="font-semibold text-gray-900 mb-3"><i class="fas fa-info-circle mr-2 text-gray-400"></i>Details</h3>
                <div class="space-y-2 text-sm">
                  <div class="flex justify-between"><span class="text-gray-500">Target Job</span><span class="text-gray-900">\${res.job_title}</span></div>
                  <div class="flex justify-between"><span class="text-gray-500">Company</span><span class="text-gray-900">\${res.company}</span></div>
                  <div class="flex justify-between"><span class="text-gray-500">Version</span><span class="text-gray-900">\${res.version}</span></div>
                  <div class="flex justify-between"><span class="text-gray-500">Model</span><span class="text-gray-900">\${res.generation_model}</span></div>
                  <div class="flex justify-between"><span class="text-gray-500">Created</span><span class="text-gray-900">\${new Date(res.created_at).toLocaleDateString()}</span></div>
                </div>
              </div>
            </div>
          </div>
        \`;
      }
      loadResume();
    </script>
  `, ''))
})

// Analytics Page
app.get('/analytics', (c) => {
  return c.html(renderPage('Analytics', `
    <div class="mb-6">
      <h1 class="text-2xl font-bold text-gray-900">Analytics</h1>
      <p class="text-gray-500 text-sm mt-1">Platform insights and trends</p>
    </div>

    <div class="grid lg:grid-cols-2 gap-6">
      <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div class="p-4 border-b"><h2 class="font-semibold text-gray-900"><i class="fas fa-fire mr-2 text-orange-500"></i>Most In-Demand Skills</h2></div>
        <div id="skills-analytics" class="p-4"><div class="loading-pulse h-48 bg-gray-100 rounded"></div></div>
      </div>

      <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div class="p-4 border-b"><h2 class="font-semibold text-gray-900"><i class="fas fa-chart-bar mr-2 text-brand-500"></i>Match Score Distribution</h2></div>
        <div id="match-dist" class="p-4"><div class="loading-pulse h-48 bg-gray-100 rounded"></div></div>
      </div>

      <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div class="p-4 border-b"><h2 class="font-semibold text-gray-900"><i class="fas fa-database mr-2 text-purple-500"></i>Jobs by Source</h2></div>
        <div id="source-stats" class="p-4"><div class="loading-pulse h-48 bg-gray-100 rounded"></div></div>
      </div>

      <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div class="p-4 border-b"><h2 class="font-semibold text-gray-900"><i class="fas fa-map mr-2 text-green-500"></i>Jobs by Location</h2></div>
        <div id="location-stats" class="p-4"><div class="loading-pulse h-48 bg-gray-100 rounded"></div></div>
      </div>
    </div>

    <script>
      async function loadAnalytics() {
        // Skills
        const sr = await fetch('/api/v1/analytics/skills/trending');
        const sd = await sr.json();
        if (sd.success) {
          const max = Math.max(...sd.data.map(s => s.job_count));
          document.getElementById('skills-analytics').innerHTML = sd.data.slice(0,15).map(s => \`
            <div class="flex items-center gap-3 mb-2">
              <span class="text-sm text-gray-700 w-28 text-right truncate">\${s.name}</span>
              <div class="flex-1 bg-gray-100 rounded-full h-6 overflow-hidden">
                <div class="h-full rounded-full bg-brand-500 flex items-center score-bar" style="width:\${(s.job_count/max)*100}%">
                  <span class="text-xs font-medium px-2 text-white">\${s.job_count} jobs</span>
                </div>
              </div>
            </div>
          \`).join('');
        }

        // Match distribution
        const mr = await fetch('/api/v1/analytics/matches/distribution');
        const md = await mr.json();
        if (md.success && md.data.length > 0) {
          const maxC = Math.max(...md.data.map(d => d.count));
          document.getElementById('match-dist').innerHTML = md.data.map(d => \`
            <div class="flex items-center gap-3 mb-3">
              <span class="text-sm text-gray-700 w-20 text-right">\${d.score_range}</span>
              <div class="flex-1 bg-gray-100 rounded-full h-7 overflow-hidden">
                <div class="h-full rounded-full score-bar \${d.score_range.startsWith('9') || d.score_range.startsWith('8') ? 'bg-emerald-500' : d.score_range.startsWith('7') || d.score_range.startsWith('6') ? 'bg-blue-500' : 'bg-amber-500'} flex items-center" style="width:\${(d.count/maxC)*100}%">
                  <span class="text-xs font-bold px-2 text-white">\${d.count}</span>
                </div>
              </div>
            </div>
          \`).join('');
        } else {
          document.getElementById('match-dist').innerHTML = '<p class="text-gray-400 text-sm text-center py-8">No match data yet. Compute matches first.</p>';
        }

        // Job stats
        const jr = await fetch('/api/v1/jobs/stats/overview');
        const jd = await jr.json();
        if (jd.success) {
          const colors = ['bg-blue-500','bg-purple-500','bg-green-500','bg-orange-500','bg-red-500','bg-pink-500'];
          const totalJobs = jd.data.total_active;
          document.getElementById('source-stats').innerHTML = \`
            <div class="space-y-3">
              \${jd.data.by_source.map((s, i) => \`
                <div class="flex items-center gap-3">
                  <span class="text-sm text-gray-700 w-24 text-right capitalize">\${s.source}</span>
                  <div class="flex-1 bg-gray-100 rounded-full h-6 overflow-hidden">
                    <div class="h-full rounded-full \${colors[i%colors.length]} flex items-center score-bar" style="width:\${(s.count/totalJobs)*100}%">
                      <span class="text-xs font-medium px-2 text-white">\${s.count}</span>
                    </div>
                  </div>
                  <span class="text-xs text-gray-400 w-12">\${Math.round(s.count/totalJobs*100)}%</span>
                </div>
              \`).join('')}
            </div>
          \`;

          document.getElementById('location-stats').innerHTML = \`
            <div class="space-y-3">
              \${jd.data.by_state.map(s => \`
                <div class="flex items-center gap-3">
                  <span class="text-sm text-gray-700 w-16 text-right">\${s.location_state}</span>
                  <div class="flex-1 bg-gray-100 rounded-full h-6 overflow-hidden">
                    <div class="h-full rounded-full bg-green-500 flex items-center score-bar" style="width:\${(s.count/totalJobs)*100}%">
                      <span class="text-xs font-medium px-2 text-white">\${s.count}</span>
                    </div>
                  </div>
                  <span class="text-xs text-gray-400 w-12">\${Math.round(s.count/totalJobs*100)}%</span>
                </div>
              \`).join('')}
            </div>
          \`;
        }
      }
      loadAnalytics();
    </script>
  `, 'analytics'))
})

export default app
