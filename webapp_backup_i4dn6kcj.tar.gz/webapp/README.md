# JobMatch AI

## Production-Ready Job Matching & ATS Resume Generation Platform

A full-stack platform that aggregates job listings across the US, stores student profiles, matches students to relevant jobs using a multi-dimensional scoring algorithm, and automatically generates ATS-optimized resumes tailored to each job description.

## Live Demo

- **Production**: https://3000-i4dn6kcj3a7s5ls3lb8cr-2e1b9533.sandbox.novita.ai

## Features

### Completed

- **Dashboard** - Overview stats, trending skills, student/job listings
- **Student Profiles** - 8 detailed candidate profiles with skills, experience, projects, certifications
- **Job Listings** - 12 real-world job postings from Google, OpenAI, Meta, AWS, Stripe, Netflix, etc.
- **60+ Skills Dictionary** - Categorized skills (programming, frameworks, cloud, DevOps, AI, data)
- **Multi-Dimensional Job Matching** - 5-factor scoring algorithm:
  - Skill Match (35% weight) - Required/Preferred/Nice-to-have weighting
  - Semantic Similarity (25%) - Keyword overlap analysis
  - Experience Match (20%) - Gaussian scoring for experience ranges
  - Education Match (10%) - Hierarchical degree comparison
  - Location Match (10%) - City/state/remote compatibility
- **ATS Resume Generator** - Tailored resume for each job match with:
  - Professional summary customized per job
  - Skills highlighted based on job requirements
  - ATS keyword injection and score estimation
  - Single-column, standard-format layout
- **Student Detail Page** - Profile/Matches/Resumes tabs with full data
- **Job Detail Page** - Full description, requirements, skills breakdown
- **Resume Viewer** - Complete resume preview with ATS analysis sidebar
- **Analytics Page** - Trending skills, match distribution, job sources, locations
- **Search & Filters** - Search students/jobs, filter by remote type, source

### API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/dashboard/stats` | Dashboard overview stats |
| GET | `/api/v1/students` | List students (paginated, searchable) |
| GET | `/api/v1/students/:id` | Student profile with skills |
| GET | `/api/v1/students/:id/stats` | Student match/resume stats |
| GET | `/api/v1/students/:id/matches` | Matched jobs for student |
| POST | `/api/v1/students/:id/matches/compute` | Compute matches for student |
| POST | `/api/v1/matches/compute-all` | Compute matches for all students |
| POST | `/api/v1/matches/:id/resume/generate` | Generate ATS resume for match |
| GET | `/api/v1/resumes/:id` | Resume details |
| GET | `/api/v1/students/:id/resumes` | All resumes for student |
| GET | `/api/v1/jobs` | List jobs (paginated, filterable) |
| GET | `/api/v1/jobs/:id` | Job details with skills |
| GET | `/api/v1/jobs/stats/overview` | Job source/location stats |
| GET | `/api/v1/skills` | Skills dictionary |
| GET | `/api/v1/analytics/skills/trending` | Most in-demand skills |
| GET | `/api/v1/analytics/matches/distribution` | Match score distribution |

### Pages

| Page | Path | Features |
|------|------|----------|
| Dashboard | `/` | Stats, students, jobs, trending skills |
| Students | `/students` | Student cards with search |
| Student Detail | `/students/:id` | Profile, Matches, Resumes tabs |
| Jobs | `/jobs` | Job list with search/filters |
| Job Detail | `/jobs/:id` | Full description, skills, apply link |
| Resume View | `/resumes/:id` | Resume preview + ATS analysis |
| Analytics | `/analytics` | Charts for skills, matches, sources |

## Data Architecture

- **Database**: Cloudflare D1 (SQLite) with 6 tables
- **Tables**: `students`, `jobs`, `skills`, `student_skills`, `job_skills`, `matches`, `resumes`, `scrape_logs`
- **Seed Data**: 8 students, 12 jobs, 60+ skills, 96 computed matches, 9+ generated resumes

## Tech Stack

- **Backend**: Hono (TypeScript) on Cloudflare Workers
- **Database**: Cloudflare D1 (SQLite)
- **Frontend**: Server-rendered HTML + Tailwind CSS + Vanilla JS
- **Build**: Vite + @hono/vite-cloudflare-pages
- **Icons**: Font Awesome 6
- **Deployment**: Cloudflare Pages

## Architecture Documentation

See `ARCHITECTURE.md` for the complete 9-step architecture design including:
- Step 1: Full System Architecture (microservices, data flow, decisions)
- Step 2: Complete Database Schema (PostgreSQL + pgvector production schema)
- Step 3: Job Scraper Design (multi-source, deduplication, AI enrichment)
- Step 4: Matching Algorithm (5-factor scoring with code)
- Step 5: ATS Resume Generator (AI pipeline, PDF rendering)
- Step 6: API Design (40+ endpoints)
- Step 7: Frontend Structure (component hierarchy, page layouts)
- Step 8: Scaling Strategy (millions of jobs, cost estimation)
- Step 9: MVP Roadmap (6-week implementation plan)

## Deployment

- **Platform**: Cloudflare Pages
- **Status**: Active (development)
- **Last Updated**: 2026-03-09
