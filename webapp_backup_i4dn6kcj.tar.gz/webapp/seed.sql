-- ============================================================
-- JobMatch AI - Seed Data
-- ============================================================

-- Skills Dictionary
INSERT OR IGNORE INTO skills (name, canonical_name, category) VALUES
('Python', 'python', 'programming'),
('JavaScript', 'javascript', 'programming'),
('TypeScript', 'typescript', 'programming'),
('Java', 'java', 'programming'),
('C++', 'cpp', 'programming'),
('Go', 'go', 'programming'),
('Rust', 'rust', 'programming'),
('SQL', 'sql', 'programming'),
('R', 'r', 'programming'),
('Swift', 'swift', 'programming'),
('Kotlin', 'kotlin', 'programming'),
('Ruby', 'ruby', 'programming'),
('PHP', 'php', 'programming'),
('React', 'react', 'framework'),
('Angular', 'angular', 'framework'),
('Vue.js', 'vuejs', 'framework'),
('Node.js', 'nodejs', 'framework'),
('Django', 'django', 'framework'),
('Flask', 'flask', 'framework'),
('Spring Boot', 'spring-boot', 'framework'),
('FastAPI', 'fastapi', 'framework'),
('Express.js', 'expressjs', 'framework'),
('Next.js', 'nextjs', 'framework'),
('TailwindCSS', 'tailwindcss', 'framework'),
('AWS', 'aws', 'cloud'),
('Google Cloud', 'gcp', 'cloud'),
('Azure', 'azure', 'cloud'),
('Docker', 'docker', 'devops'),
('Kubernetes', 'kubernetes', 'devops'),
('Terraform', 'terraform', 'devops'),
('CI/CD', 'cicd', 'devops'),
('Git', 'git', 'devops'),
('Jenkins', 'jenkins', 'devops'),
('PostgreSQL', 'postgresql', 'database'),
('MySQL', 'mysql', 'database'),
('MongoDB', 'mongodb', 'database'),
('Redis', 'redis', 'database'),
('Elasticsearch', 'elasticsearch', 'database'),
('DynamoDB', 'dynamodb', 'database'),
('Machine Learning', 'machine-learning', 'ai'),
('Deep Learning', 'deep-learning', 'ai'),
('TensorFlow', 'tensorflow', 'ai'),
('PyTorch', 'pytorch', 'ai'),
('NLP', 'nlp', 'ai'),
('Computer Vision', 'computer-vision', 'ai'),
('LLMs', 'llms', 'ai'),
('Data Analysis', 'data-analysis', 'data'),
('Apache Spark', 'apache-spark', 'data'),
('Pandas', 'pandas', 'data'),
('Tableau', 'tableau', 'data'),
('Power BI', 'power-bi', 'data'),
('REST APIs', 'rest-apis', 'architecture'),
('GraphQL', 'graphql', 'architecture'),
('Microservices', 'microservices', 'architecture'),
('System Design', 'system-design', 'architecture'),
('Agile/Scrum', 'agile-scrum', 'methodology'),
('Linux', 'linux', 'systems'),
('Cybersecurity', 'cybersecurity', 'security'),
('HTML/CSS', 'html-css', 'frontend'),
('Figma', 'figma', 'design');

-- ============================================================
-- Students
-- ============================================================

INSERT OR IGNORE INTO students (id, email, full_name, phone, location_city, location_state, willing_to_relocate, remote_preference, education_level, degree, university, graduation_year, gpa, work_auth_status, visa_sponsor_needed, total_years_exp, experience_json, projects_json, certifications_json, preferred_roles, summary_text) VALUES
(1, 'alex.chen@email.com', 'Alex Chen', '(415) 555-0101', 'San Francisco', 'CA', 1, 'any', 'masters', 'Computer Science', 'Stanford University', 2023, 3.9, 'us_citizen', 0, 3.5,
'[{"title":"Software Engineer","company":"Stripe","location":"San Francisco, CA","dates":"Jun 2023 - Present","bullets":["Built real-time payment processing pipeline handling 50K transactions/sec using Python and Go","Designed and implemented microservices architecture reducing API latency by 40%","Led migration of legacy monolith to Kubernetes, improving deployment frequency by 300%","Mentored 3 junior engineers on distributed systems best practices"]},{"title":"Software Engineering Intern","company":"Google","location":"Mountain View, CA","dates":"Jun 2022 - Sep 2022","bullets":["Developed full-stack feature for Google Maps reducing load time by 25%","Implemented A/B testing framework used across 3 product teams","Contributed to open-source TensorFlow documentation"]}]',
'[{"name":"DistroCache","technologies":["Go","Redis","gRPC"],"description":"Distributed caching system","bullets":["Built a distributed cache with consistent hashing supporting 100K ops/sec","Implemented Raft consensus for cache coherence across 5 nodes"]},{"name":"CodeReview AI","technologies":["Python","GPT-4","React"],"description":"AI-powered code review tool","bullets":["Created an LLM-based code review assistant that reduced review time by 60%","Deployed to production serving 200+ developers daily"]}]',
'[{"name":"AWS Solutions Architect Associate","issuer":"Amazon Web Services","date":"2023"},{"name":"Google Cloud Professional Cloud Developer","issuer":"Google","date":"2022"}]',
'["Software Engineer","Backend Engineer","Full Stack Engineer"]',
'Experienced software engineer with 3.5 years of expertise in distributed systems, microservices, and cloud-native development. Strong background in Python, Go, and cloud infrastructure with a passion for building scalable, reliable systems.'),

(2, 'priya.sharma@email.com', 'Priya Sharma', '(212) 555-0202', 'New York', 'NY', 0, 'hybrid', 'masters', 'Data Science', 'Columbia University', 2023, 3.85, 'opt', 1, 2.0,
'[{"title":"Data Scientist","company":"JPMorgan Chase","location":"New York, NY","dates":"Jul 2023 - Present","bullets":["Built ML models for credit risk assessment achieving 94% accuracy, saving $2M annually","Developed NLP pipeline for sentiment analysis of financial news processing 10K articles/day","Created automated reporting dashboard in Tableau used by 50+ analysts","Implemented A/B testing framework for marketing campaigns"]},{"title":"ML Research Assistant","company":"Columbia University","location":"New York, NY","dates":"Sep 2021 - Jun 2023","bullets":["Published 2 papers on transformer-based time series forecasting","Achieved state-of-the-art results on 3 benchmark datasets","Built custom PyTorch training pipeline with distributed data parallel"]}]',
'[{"name":"FinSentiment","technologies":["Python","BERT","FastAPI"],"description":"Financial sentiment analysis","bullets":["Fine-tuned BERT model achieving 91% accuracy on financial text classification","Deployed as REST API handling 1000 requests/minute"]},{"name":"StockPredictor","technologies":["Python","LSTM","Streamlit"],"description":"Stock price prediction","bullets":["Built LSTM model for stock price prediction with 15% improvement over baseline","Created interactive Streamlit dashboard for visualization"]}]',
'[{"name":"AWS Machine Learning Specialty","issuer":"Amazon Web Services","date":"2023"},{"name":"TensorFlow Developer Certificate","issuer":"Google","date":"2022"}]',
'["Data Scientist","ML Engineer","AI Engineer"]',
'Data scientist with expertise in machine learning, NLP, and deep learning. Skilled in building production ML systems and deriving actionable insights from complex datasets. Published researcher in transformer architectures.'),

(3, 'marcus.johnson@email.com', 'Marcus Johnson', '(512) 555-0303', 'Austin', 'TX', 1, 'remote', 'bachelors', 'Software Engineering', 'UT Austin', 2021, 3.6, 'us_citizen', 0, 4.0,
'[{"title":"Senior Frontend Engineer","company":"Shopify","location":"Remote","dates":"Mar 2022 - Present","bullets":["Led redesign of merchant dashboard serving 2M+ active stores","Built React component library adopted by 8 engineering teams","Improved Core Web Vitals by 45% through performance optimization","Architected microfrontend migration reducing bundle size by 60%"]},{"title":"Frontend Developer","company":"Dell Technologies","location":"Austin, TX","dates":"Jul 2021 - Feb 2022","bullets":["Developed responsive e-commerce interfaces using React and TypeScript","Implemented real-time inventory tracking dashboard","Contributed to design system used across 5 product lines"]}]',
'[{"name":"ReactFlow","technologies":["React","TypeScript","D3.js"],"description":"Visual workflow builder","bullets":["Created drag-and-drop workflow builder used by 500+ users","Open-sourced with 1.2K GitHub stars"]},{"name":"A11yKit","technologies":["TypeScript","WCAG","Jest"],"description":"Accessibility testing library","bullets":["Built automated accessibility testing library for React components","Integrated with CI/CD pipelines at Shopify"]}]',
'[{"name":"Meta Frontend Developer Professional Certificate","issuer":"Meta","date":"2022"}]',
'["Frontend Engineer","Full Stack Engineer","UI Engineer"]',
'Senior frontend engineer specializing in React, TypeScript, and performance optimization. Passionate about building accessible, high-performance web applications at scale.'),

(4, 'sarah.williams@email.com', 'Sarah Williams', '(206) 555-0404', 'Seattle', 'WA', 0, 'any', 'masters', 'Computer Science', 'University of Washington', 2022, 3.75, 'green_card', 0, 3.0,
'[{"title":"Cloud Infrastructure Engineer","company":"Amazon Web Services","location":"Seattle, WA","dates":"Aug 2022 - Present","bullets":["Managed Kubernetes clusters serving 100+ microservices with 99.99% uptime","Automated infrastructure provisioning with Terraform reducing setup time from days to hours","Implemented observability stack (Prometheus, Grafana, Jaeger) across 50+ services","Led incident response for critical production issues serving 10M+ users"]},{"title":"DevOps Intern","company":"Microsoft","location":"Redmond, WA","dates":"Jun 2021 - Sep 2021","bullets":["Built CI/CD pipelines for Azure DevOps reducing deployment time by 50%","Automated security scanning in build pipeline catching 200+ vulnerabilities"]}]',
'[{"name":"InfraBot","technologies":["Python","Terraform","Slack API"],"description":"Infrastructure automation bot","bullets":["Created Slack bot for automated infrastructure provisioning","Reduced manual ops tickets by 70%"]},{"name":"K8sMonitor","technologies":["Go","Prometheus","Grafana"],"description":"Kubernetes monitoring","bullets":["Built custom Kubernetes operator for automated scaling","Reduced cloud costs by 30% through intelligent resource allocation"]}]',
'[{"name":"AWS Solutions Architect Professional","issuer":"Amazon Web Services","date":"2023"},{"name":"Certified Kubernetes Administrator","issuer":"CNCF","date":"2023"},{"name":"HashiCorp Terraform Associate","issuer":"HashiCorp","date":"2022"}]',
'["Cloud Engineer","DevOps Engineer","Site Reliability Engineer","Platform Engineer"]',
'Cloud infrastructure engineer with deep expertise in AWS, Kubernetes, and Terraform. Proven track record of building and maintaining highly available, scalable infrastructure at AWS scale.'),

(5, 'jason.park@email.com', 'Jason Park', '(408) 555-0505', 'San Jose', 'CA', 1, 'hybrid', 'bachelors', 'Computer Science', 'UC Berkeley', 2020, 3.7, 'h1b', 1, 5.0,
'[{"title":"Staff Software Engineer","company":"Apple","location":"Cupertino, CA","dates":"Jan 2022 - Present","bullets":["Architected iOS payment processing system handling $1B+ in annual transactions","Led team of 8 engineers building next-generation privacy features","Designed distributed event-driven architecture reducing system coupling by 70%","Improved app performance by 35% through profiling and optimization"]},{"title":"Senior Software Engineer","company":"Uber","location":"San Francisco, CA","dates":"Jul 2020 - Dec 2021","bullets":["Built real-time driver matching algorithm serving 5M+ daily rides","Optimized geospatial queries reducing response time from 200ms to 50ms","Developed fraud detection system saving $10M annually","Mentored 5 engineers and led technical design reviews"]}]',
'[{"name":"EventForge","technologies":["Java","Kafka","PostgreSQL"],"description":"Event sourcing framework","bullets":["Built open-source event sourcing framework with 3K GitHub stars","Used in production at 5+ companies"]},{"name":"GeoMatch","technologies":["Go","PostGIS","Redis"],"description":"Real-time geospatial matching","bullets":["Developed sub-millisecond geospatial matching engine","Handled 100K concurrent connections"]}]',
'[{"name":"System Design Interview Expert","issuer":"Educative","date":"2022"},{"name":"Oracle Certified Professional Java SE","issuer":"Oracle","date":"2021"}]',
'["Staff Engineer","Principal Engineer","Engineering Manager","Software Architect"]',
'Staff-level engineer with 5 years of experience building large-scale distributed systems at Apple and Uber. Expert in system design, performance optimization, and technical leadership.'),

(6, 'emily.rodriguez@email.com', 'Emily Rodriguez', '(720) 555-0606', 'Denver', 'CO', 1, 'remote', 'masters', 'Artificial Intelligence', 'Carnegie Mellon University', 2024, 3.92, 'us_citizen', 0, 1.5,
'[{"title":"AI/ML Engineer","company":"OpenAI","location":"San Francisco, CA (Remote)","dates":"Jun 2024 - Present","bullets":["Developing fine-tuning pipelines for GPT models improving task-specific performance by 40%","Built evaluation framework for LLM safety and alignment testing","Implemented RAG system processing 1M+ documents for enterprise clients","Contributed to RLHF training infrastructure"]},{"title":"ML Research Intern","company":"Meta AI","location":"Menlo Park, CA","dates":"May 2023 - Aug 2023","bullets":["Researched multimodal learning combining vision and language models","Achieved 5% improvement on VQA benchmark","Published findings at NeurIPS workshop"]}]',
'[{"name":"PromptForge","technologies":["Python","LangChain","ChromaDB"],"description":"LLM prompt optimization framework","bullets":["Built automated prompt engineering tool improving LLM output quality by 30%","Supports GPT-4, Claude, and open-source models"]},{"name":"VisionLang","technologies":["PyTorch","CLIP","Transformers"],"description":"Multimodal AI system","bullets":["Created multimodal AI system combining CLIP and GPT for image captioning","Achieved state-of-the-art on Flickr30k dataset"]}]',
'[{"name":"Deep Learning Specialization","issuer":"Coursera/DeepLearning.AI","date":"2023"}]',
'["AI/ML Engineer","Research Engineer","LLM Engineer","Applied Scientist"]',
'AI/ML engineer specializing in large language models, RAG systems, and multimodal AI. Experience at OpenAI building production LLM systems. Published researcher in NLP and computer vision.'),

(7, 'david.kim@email.com', 'David Kim', '(312) 555-0707', 'Chicago', 'IL', 0, 'hybrid', 'bachelors', 'Information Systems', 'University of Illinois', 2022, 3.5, 'us_citizen', 0, 2.5,
'[{"title":"Backend Engineer","company":"Salesforce","location":"Chicago, IL","dates":"Sep 2022 - Present","bullets":["Designed RESTful APIs handling 10K requests/second for CRM platform","Implemented event-driven architecture using Kafka reducing data sync latency by 80%","Built automated testing framework achieving 95% code coverage","Optimized database queries reducing p99 latency from 500ms to 100ms"]},{"title":"Software Developer Intern","company":"Accenture","location":"Chicago, IL","dates":"Jun 2021 - Aug 2021","bullets":["Developed microservices for insurance claims processing","Automated data migration reducing manual effort by 90%"]}]',
'[{"name":"APIGateway","technologies":["Node.js","Express","Redis"],"description":"API gateway service","bullets":["Built rate-limited API gateway handling 50K concurrent connections","Implemented JWT authentication and role-based access control"]}]',
'[{"name":"AWS Developer Associate","issuer":"Amazon Web Services","date":"2023"}]',
'["Backend Engineer","Software Engineer","API Developer"]',
'Backend engineer focused on building scalable APIs and distributed systems. Strong experience with Java, Node.js, and cloud services at enterprise scale.'),

(8, 'lisa.thompson@email.com', 'Lisa Thompson', '(617) 555-0808', 'Boston', 'MA', 0, 'any', 'phd', 'Computer Science', 'MIT', 2024, 3.95, 'us_citizen', 0, 2.0,
'[{"title":"Research Scientist","company":"Google DeepMind","location":"Cambridge, MA","dates":"Sep 2024 - Present","bullets":["Leading research on efficient transformer architectures for edge deployment","Published 5 papers in top-tier venues (NeurIPS, ICML, ICLR)","Developed novel attention mechanism reducing compute by 50% with minimal accuracy loss","Collaborating with hardware team on ML accelerator design"]},{"title":"Research Intern","company":"Google Brain","location":"Mountain View, CA","dates":"Jun 2023 - Sep 2023","bullets":["Developed new training technique for sparse neural networks","Achieved 3x speedup with less than 1% accuracy drop","Paper accepted at ICML 2024"]}]',
'[{"name":"SparseFormer","technologies":["Python","JAX","TPU"],"description":"Sparse transformer research","bullets":["Created novel sparse attention mechanism for large language models","Code released as open-source with 2K+ GitHub stars"]},{"name":"EdgeML","technologies":["Python","TensorRT","ONNX"],"description":"ML model compression","bullets":["Built model compression toolkit for deploying LLMs on edge devices","Achieved 10x compression with 95% accuracy retention"]}]',
'[{"name":"5 published papers at NeurIPS, ICML, ICLR","issuer":"Various","date":"2021-2024"}]',
'["Research Scientist","Principal Research Engineer","ML Architect"]',
'PhD researcher and scientist at Google DeepMind specializing in efficient ML systems, transformer architectures, and model compression. Published extensively in top venues.');

-- ============================================================
-- Student Skills Mappings
-- ============================================================

-- Alex Chen (id=1) - Backend/Systems Engineer
INSERT OR IGNORE INTO student_skills (student_id, skill_id, proficiency, years_experience, is_primary) VALUES
(1, (SELECT id FROM skills WHERE canonical_name='python'), 'expert', 4.0, 1),
(1, (SELECT id FROM skills WHERE canonical_name='go'), 'advanced', 2.0, 1),
(1, (SELECT id FROM skills WHERE canonical_name='javascript'), 'advanced', 3.0, 0),
(1, (SELECT id FROM skills WHERE canonical_name='typescript'), 'intermediate', 2.0, 0),
(1, (SELECT id FROM skills WHERE canonical_name='react'), 'intermediate', 2.0, 0),
(1, (SELECT id FROM skills WHERE canonical_name='nodejs'), 'advanced', 3.0, 0),
(1, (SELECT id FROM skills WHERE canonical_name='aws'), 'advanced', 3.0, 1),
(1, (SELECT id FROM skills WHERE canonical_name='docker'), 'advanced', 3.0, 1),
(1, (SELECT id FROM skills WHERE canonical_name='kubernetes'), 'advanced', 2.5, 1),
(1, (SELECT id FROM skills WHERE canonical_name='postgresql'), 'advanced', 3.0, 0),
(1, (SELECT id FROM skills WHERE canonical_name='redis'), 'advanced', 2.0, 0),
(1, (SELECT id FROM skills WHERE canonical_name='microservices'), 'expert', 3.0, 1),
(1, (SELECT id FROM skills WHERE canonical_name='system-design'), 'advanced', 3.0, 0),
(1, (SELECT id FROM skills WHERE canonical_name='git'), 'expert', 4.0, 0),
(1, (SELECT id FROM skills WHERE canonical_name='cicd'), 'advanced', 3.0, 0),
(1, (SELECT id FROM skills WHERE canonical_name='terraform'), 'intermediate', 1.5, 0),
(1, (SELECT id FROM skills WHERE canonical_name='rest-apis'), 'expert', 3.5, 0),
(1, (SELECT id FROM skills WHERE canonical_name='linux'), 'advanced', 4.0, 0);

-- Priya Sharma (id=2) - Data Scientist/ML
INSERT OR IGNORE INTO student_skills (student_id, skill_id, proficiency, years_experience, is_primary) VALUES
(2, (SELECT id FROM skills WHERE canonical_name='python'), 'expert', 4.0, 1),
(2, (SELECT id FROM skills WHERE canonical_name='sql'), 'advanced', 3.0, 0),
(2, (SELECT id FROM skills WHERE canonical_name='r'), 'intermediate', 2.0, 0),
(2, (SELECT id FROM skills WHERE canonical_name='machine-learning'), 'expert', 3.0, 1),
(2, (SELECT id FROM skills WHERE canonical_name='deep-learning'), 'advanced', 2.5, 1),
(2, (SELECT id FROM skills WHERE canonical_name='tensorflow'), 'advanced', 2.0, 0),
(2, (SELECT id FROM skills WHERE canonical_name='pytorch'), 'expert', 3.0, 1),
(2, (SELECT id FROM skills WHERE canonical_name='nlp'), 'expert', 2.5, 1),
(2, (SELECT id FROM skills WHERE canonical_name='pandas'), 'expert', 3.0, 0),
(2, (SELECT id FROM skills WHERE canonical_name='aws'), 'intermediate', 1.5, 0),
(2, (SELECT id FROM skills WHERE canonical_name='docker'), 'intermediate', 1.5, 0),
(2, (SELECT id FROM skills WHERE canonical_name='fastapi'), 'advanced', 1.5, 0),
(2, (SELECT id FROM skills WHERE canonical_name='tableau'), 'advanced', 2.0, 0),
(2, (SELECT id FROM skills WHERE canonical_name='data-analysis'), 'expert', 3.0, 0),
(2, (SELECT id FROM skills WHERE canonical_name='apache-spark'), 'intermediate', 1.0, 0),
(2, (SELECT id FROM skills WHERE canonical_name='llms'), 'advanced', 1.5, 0);

-- Marcus Johnson (id=3) - Frontend Engineer
INSERT OR IGNORE INTO student_skills (student_id, skill_id, proficiency, years_experience, is_primary) VALUES
(3, (SELECT id FROM skills WHERE canonical_name='javascript'), 'expert', 5.0, 1),
(3, (SELECT id FROM skills WHERE canonical_name='typescript'), 'expert', 4.0, 1),
(3, (SELECT id FROM skills WHERE canonical_name='react'), 'expert', 4.5, 1),
(3, (SELECT id FROM skills WHERE canonical_name='nextjs'), 'advanced', 2.5, 1),
(3, (SELECT id FROM skills WHERE canonical_name='html-css'), 'expert', 5.0, 1),
(3, (SELECT id FROM skills WHERE canonical_name='tailwindcss'), 'expert', 3.0, 0),
(3, (SELECT id FROM skills WHERE canonical_name='nodejs'), 'advanced', 3.0, 0),
(3, (SELECT id FROM skills WHERE canonical_name='graphql'), 'advanced', 2.0, 0),
(3, (SELECT id FROM skills WHERE canonical_name='git'), 'expert', 4.0, 0),
(3, (SELECT id FROM skills WHERE canonical_name='docker'), 'intermediate', 1.5, 0),
(3, (SELECT id FROM skills WHERE canonical_name='cicd'), 'advanced', 2.0, 0),
(3, (SELECT id FROM skills WHERE canonical_name='figma'), 'advanced', 3.0, 0),
(3, (SELECT id FROM skills WHERE canonical_name='rest-apis'), 'advanced', 3.0, 0),
(3, (SELECT id FROM skills WHERE canonical_name='agile-scrum'), 'advanced', 4.0, 0);

-- Sarah Williams (id=4) - Cloud/DevOps Engineer
INSERT OR IGNORE INTO student_skills (student_id, skill_id, proficiency, years_experience, is_primary) VALUES
(4, (SELECT id FROM skills WHERE canonical_name='aws'), 'expert', 4.0, 1),
(4, (SELECT id FROM skills WHERE canonical_name='kubernetes'), 'expert', 3.0, 1),
(4, (SELECT id FROM skills WHERE canonical_name='terraform'), 'expert', 3.0, 1),
(4, (SELECT id FROM skills WHERE canonical_name='docker'), 'expert', 3.5, 1),
(4, (SELECT id FROM skills WHERE canonical_name='python'), 'advanced', 3.0, 0),
(4, (SELECT id FROM skills WHERE canonical_name='go'), 'advanced', 2.0, 0),
(4, (SELECT id FROM skills WHERE canonical_name='linux'), 'expert', 4.0, 1),
(4, (SELECT id FROM skills WHERE canonical_name='cicd'), 'expert', 3.0, 0),
(4, (SELECT id FROM skills WHERE canonical_name='jenkins'), 'advanced', 2.0, 0),
(4, (SELECT id FROM skills WHERE canonical_name='git'), 'expert', 3.5, 0),
(4, (SELECT id FROM skills WHERE canonical_name='postgresql'), 'intermediate', 2.0, 0),
(4, (SELECT id FROM skills WHERE canonical_name='redis'), 'intermediate', 1.5, 0),
(4, (SELECT id FROM skills WHERE canonical_name='microservices'), 'advanced', 3.0, 0);

-- Jason Park (id=5) - Staff/System Design
INSERT OR IGNORE INTO student_skills (student_id, skill_id, proficiency, years_experience, is_primary) VALUES
(5, (SELECT id FROM skills WHERE canonical_name='java'), 'expert', 5.0, 1),
(5, (SELECT id FROM skills WHERE canonical_name='go'), 'expert', 3.0, 1),
(5, (SELECT id FROM skills WHERE canonical_name='python'), 'advanced', 3.0, 0),
(5, (SELECT id FROM skills WHERE canonical_name='swift'), 'advanced', 2.0, 0),
(5, (SELECT id FROM skills WHERE canonical_name='system-design'), 'expert', 5.0, 1),
(5, (SELECT id FROM skills WHERE canonical_name='microservices'), 'expert', 4.0, 1),
(5, (SELECT id FROM skills WHERE canonical_name='postgresql'), 'expert', 4.0, 0),
(5, (SELECT id FROM skills WHERE canonical_name='redis'), 'expert', 3.0, 0),
(5, (SELECT id FROM skills WHERE canonical_name='kubernetes'), 'advanced', 2.5, 0),
(5, (SELECT id FROM skills WHERE canonical_name='aws'), 'advanced', 3.0, 0),
(5, (SELECT id FROM skills WHERE canonical_name='docker'), 'advanced', 3.0, 0),
(5, (SELECT id FROM skills WHERE canonical_name='rest-apis'), 'expert', 5.0, 0),
(5, (SELECT id FROM skills WHERE canonical_name='agile-scrum'), 'expert', 5.0, 0);

-- Emily Rodriguez (id=6) - AI/ML Engineer
INSERT OR IGNORE INTO student_skills (student_id, skill_id, proficiency, years_experience, is_primary) VALUES
(6, (SELECT id FROM skills WHERE canonical_name='python'), 'expert', 4.0, 1),
(6, (SELECT id FROM skills WHERE canonical_name='pytorch'), 'expert', 3.0, 1),
(6, (SELECT id FROM skills WHERE canonical_name='tensorflow'), 'advanced', 2.0, 0),
(6, (SELECT id FROM skills WHERE canonical_name='machine-learning'), 'expert', 3.5, 1),
(6, (SELECT id FROM skills WHERE canonical_name='deep-learning'), 'expert', 3.0, 1),
(6, (SELECT id FROM skills WHERE canonical_name='nlp'), 'expert', 3.0, 1),
(6, (SELECT id FROM skills WHERE canonical_name='llms'), 'expert', 2.0, 1),
(6, (SELECT id FROM skills WHERE canonical_name='computer-vision'), 'advanced', 2.0, 0),
(6, (SELECT id FROM skills WHERE canonical_name='aws'), 'intermediate', 1.5, 0),
(6, (SELECT id FROM skills WHERE canonical_name='docker'), 'intermediate', 1.5, 0),
(6, (SELECT id FROM skills WHERE canonical_name='sql'), 'intermediate', 2.0, 0),
(6, (SELECT id FROM skills WHERE canonical_name='fastapi'), 'intermediate', 1.0, 0),
(6, (SELECT id FROM skills WHERE canonical_name='git'), 'advanced', 3.0, 0);

-- David Kim (id=7) - Backend Engineer
INSERT OR IGNORE INTO student_skills (student_id, skill_id, proficiency, years_experience, is_primary) VALUES
(7, (SELECT id FROM skills WHERE canonical_name='java'), 'advanced', 3.0, 1),
(7, (SELECT id FROM skills WHERE canonical_name='javascript'), 'advanced', 3.0, 1),
(7, (SELECT id FROM skills WHERE canonical_name='nodejs'), 'expert', 3.0, 1),
(7, (SELECT id FROM skills WHERE canonical_name='typescript'), 'advanced', 2.0, 0),
(7, (SELECT id FROM skills WHERE canonical_name='expressjs'), 'advanced', 2.5, 0),
(7, (SELECT id FROM skills WHERE canonical_name='spring-boot'), 'advanced', 2.0, 0),
(7, (SELECT id FROM skills WHERE canonical_name='postgresql'), 'advanced', 2.5, 0),
(7, (SELECT id FROM skills WHERE canonical_name='mongodb'), 'advanced', 2.0, 0),
(7, (SELECT id FROM skills WHERE canonical_name='redis'), 'advanced', 2.0, 1),
(7, (SELECT id FROM skills WHERE canonical_name='aws'), 'intermediate', 2.0, 0),
(7, (SELECT id FROM skills WHERE canonical_name='docker'), 'intermediate', 1.5, 0),
(7, (SELECT id FROM skills WHERE canonical_name='rest-apis'), 'expert', 3.0, 1),
(7, (SELECT id FROM skills WHERE canonical_name='git'), 'advanced', 3.0, 0),
(7, (SELECT id FROM skills WHERE canonical_name='sql'), 'advanced', 3.0, 0),
(7, (SELECT id FROM skills WHERE canonical_name='cicd'), 'intermediate', 1.5, 0);

-- Lisa Thompson (id=8) - Research Scientist
INSERT OR IGNORE INTO student_skills (student_id, skill_id, proficiency, years_experience, is_primary) VALUES
(8, (SELECT id FROM skills WHERE canonical_name='python'), 'expert', 6.0, 1),
(8, (SELECT id FROM skills WHERE canonical_name='pytorch'), 'expert', 4.0, 1),
(8, (SELECT id FROM skills WHERE canonical_name='tensorflow'), 'expert', 3.0, 0),
(8, (SELECT id FROM skills WHERE canonical_name='machine-learning'), 'expert', 5.0, 1),
(8, (SELECT id FROM skills WHERE canonical_name='deep-learning'), 'expert', 5.0, 1),
(8, (SELECT id FROM skills WHERE canonical_name='nlp'), 'expert', 4.0, 1),
(8, (SELECT id FROM skills WHERE canonical_name='llms'), 'expert', 3.0, 1),
(8, (SELECT id FROM skills WHERE canonical_name='computer-vision'), 'expert', 3.0, 0),
(8, (SELECT id FROM skills WHERE canonical_name='cpp'), 'advanced', 3.0, 0),
(8, (SELECT id FROM skills WHERE canonical_name='linux'), 'expert', 5.0, 0),
(8, (SELECT id FROM skills WHERE canonical_name='docker'), 'advanced', 2.0, 0),
(8, (SELECT id FROM skills WHERE canonical_name='git'), 'expert', 5.0, 0),
(8, (SELECT id FROM skills WHERE canonical_name='data-analysis'), 'expert', 4.0, 0);

-- ============================================================
-- Jobs
-- ============================================================

INSERT OR IGNORE INTO jobs (id, source, title, title_normalized, company, location_city, location_state, remote_type, description, requirements, experience_min, experience_max, education_req, salary_min, salary_max, job_type, seniority_level, visa_sponsored, apply_url, extracted_skills, ats_keywords, status, posted_at) VALUES
(1, 'greenhouse', 'Senior Software Engineer, Backend', 'Senior Software Engineer', 'Google', 'Mountain View', 'CA', 'hybrid',
'We are looking for a Senior Software Engineer to join our Cloud Platform team. You will design and build large-scale distributed systems that power Google Cloud. You will work with a team of world-class engineers to solve complex technical challenges at scale.

Key Responsibilities:
- Design and implement scalable backend services using Go and Python
- Build and maintain microservices architecture on Kubernetes
- Optimize system performance and reliability for services handling millions of requests per second
- Collaborate with product and design teams to define technical requirements
- Mentor junior engineers and conduct code reviews
- Drive technical decisions and architecture design for new features',
'Required Qualifications:
- BS/MS in Computer Science or equivalent
- 4+ years of software development experience
- Strong proficiency in Go, Python, or Java
- Experience with distributed systems and microservices
- Experience with cloud platforms (GCP, AWS, or Azure)
- Strong understanding of data structures, algorithms, and system design

Preferred Qualifications:
- Experience with Kubernetes and container orchestration
- Experience with gRPC and Protocol Buffers
- Contributions to open-source projects
- Experience with CI/CD pipelines and DevOps practices',
4, 8, 'bachelors', 180000, 280000, 'full_time', 'senior', 1,
'https://careers.google.com/jobs/senior-software-engineer-12345',
'["go","python","java","kubernetes","docker","microservices","system-design","gcp","aws","cicd","rest-apis","postgresql"]',
'Go,Python,Java,Kubernetes,distributed systems,microservices,GCP,cloud,system design,gRPC,CI/CD',
'active', '2025-03-01'),

(2, 'lever', 'Machine Learning Engineer', 'Machine Learning Engineer', 'OpenAI', 'San Francisco', 'CA', 'hybrid',
'Join OpenAI as a Machine Learning Engineer to help build the next generation of AI systems. You will work on training, fine-tuning, and deploying large language models at unprecedented scale.

Key Responsibilities:
- Develop and optimize training pipelines for large language models
- Implement RLHF and other alignment techniques
- Build evaluation frameworks for model safety and quality
- Design and implement RAG systems for enterprise applications
- Collaborate with research teams to bring cutting-edge research to production
- Optimize inference performance for real-time applications',
'Required Qualifications:
- MS/PhD in Computer Science, AI, or related field
- 2+ years of experience with deep learning frameworks (PyTorch, TensorFlow)
- Strong experience with NLP and large language models
- Proficiency in Python
- Experience with distributed training at scale
- Published research in ML/AI is a plus

Preferred Qualifications:
- Experience with RLHF or other alignment methods
- Experience with model compression and optimization
- Familiarity with RAG systems and vector databases
- Experience with cloud infrastructure (AWS, GCP)',
2, 6, 'masters', 200000, 350000, 'full_time', 'mid', 1,
'https://openai.com/careers/ml-engineer-67890',
'["python","pytorch","tensorflow","machine-learning","deep-learning","nlp","llms","aws","docker","data-analysis"]',
'Python,PyTorch,TensorFlow,LLMs,NLP,deep learning,RLHF,RAG,distributed training,machine learning',
'active', '2025-03-03'),

(3, 'greenhouse', 'Staff Frontend Engineer', 'Staff Frontend Engineer', 'Meta', 'Menlo Park', 'CA', 'hybrid',
'Meta is looking for a Staff Frontend Engineer to lead our next-generation social platform experiences. You will architect and build high-performance web applications used by billions of people worldwide.

Key Responsibilities:
- Lead architecture decisions for large-scale React applications
- Build and maintain shared component libraries and design systems
- Optimize performance for web applications with millions of daily users
- Drive adoption of modern web technologies and best practices
- Mentor senior engineers and set technical direction
- Collaborate with design, product, and backend teams',
'Required Qualifications:
- 5+ years of frontend development experience
- Expert-level proficiency in React and TypeScript
- Deep understanding of web performance optimization
- Experience with Next.js or similar SSR frameworks
- Strong knowledge of HTML, CSS, and responsive design
- Experience leading technical projects and mentoring engineers

Preferred Qualifications:
- Experience with React Native or mobile development
- Experience with GraphQL
- Contributions to design systems or component libraries
- Experience with micro-frontend architectures
- Familiarity with Figma and design tools',
5, 10, 'bachelors', 200000, 320000, 'full_time', 'staff', 0,
'https://metacareers.com/jobs/staff-frontend-engineer-11111',
'["javascript","typescript","react","nextjs","html-css","tailwindcss","graphql","nodejs","figma","cicd","git"]',
'React,TypeScript,JavaScript,Next.js,HTML,CSS,performance,design systems,GraphQL,frontend,web',
'active', '2025-03-02'),

(4, 'indeed', 'Cloud Infrastructure Engineer', 'Cloud Infrastructure Engineer', 'Amazon Web Services', 'Seattle', 'WA', 'onsite',
'AWS is seeking a Cloud Infrastructure Engineer to help build and scale the world''s most comprehensive cloud platform. You will manage critical infrastructure serving millions of customers globally.

Key Responsibilities:
- Design and manage large-scale Kubernetes clusters
- Automate infrastructure provisioning using Terraform and CloudFormation
- Implement monitoring, alerting, and observability solutions
- Ensure 99.99% uptime for mission-critical services
- Respond to and resolve production incidents
- Optimize cloud infrastructure costs',
'Required Qualifications:
- BS in Computer Science or equivalent experience
- 3+ years of experience with AWS services
- Strong experience with Kubernetes and Docker
- Proficiency in Terraform or similar IaC tools
- Experience with Linux administration
- Strong scripting skills in Python or Bash

Preferred Qualifications:
- AWS certifications (Solutions Architect, DevOps Engineer)
- Experience with Prometheus, Grafana, and observability tools
- Experience with CI/CD pipeline automation
- Knowledge of networking and security best practices',
3, 7, 'bachelors', 150000, 250000, 'full_time', 'mid', 1,
'https://amazon.jobs/cloud-infrastructure-engineer-22222',
'["aws","kubernetes","docker","terraform","python","linux","cicd","jenkins","postgresql","redis","microservices","git"]',
'AWS,Kubernetes,Docker,Terraform,Linux,Python,infrastructure,cloud,CI/CD,monitoring,DevOps',
'active', '2025-02-28'),

(5, 'linkedin', 'Full Stack Software Engineer', 'Full Stack Software Engineer', 'Stripe', 'San Francisco', 'CA', 'remote',
'Stripe is looking for a Full Stack Software Engineer to build the future of financial infrastructure. You will work on products that process billions of dollars in payments annually.

Key Responsibilities:
- Build and maintain full-stack features for Stripe''s payment platform
- Design and implement RESTful APIs and microservices
- Develop responsive frontend interfaces using React and TypeScript
- Work with databases and optimize query performance
- Write clean, tested, and well-documented code
- Participate in code reviews and technical design discussions',
'Required Qualifications:
- 2+ years of professional software development experience
- Proficiency in one or more backend languages (Python, Ruby, Go, Java)
- Experience with React, TypeScript, and modern frontend tools
- Experience with SQL databases (PostgreSQL, MySQL)
- Understanding of RESTful API design
- Strong problem-solving and communication skills

Preferred Qualifications:
- Experience with payment systems or fintech
- Experience with microservices architecture
- Knowledge of Docker and container technologies
- Experience with AWS or GCP cloud services',
2, 5, 'bachelors', 140000, 220000, 'full_time', 'mid', 1,
'https://stripe.com/jobs/fullstack-engineer-33333',
'["python","ruby","go","java","react","typescript","javascript","postgresql","mysql","docker","aws","rest-apis","microservices","git","nodejs"]',
'Python,React,TypeScript,PostgreSQL,REST API,microservices,full stack,Docker,AWS,payments',
'active', '2025-03-05'),

(6, 'greenhouse', 'Data Scientist - NLP', 'Data Scientist NLP', 'Netflix', 'Los Gatos', 'CA', 'hybrid',
'Netflix is seeking a Data Scientist specializing in NLP to help personalize the entertainment experience for 250M+ subscribers worldwide. You will build ML models that power content recommendation and search.

Key Responsibilities:
- Build and deploy NLP models for content understanding and recommendation
- Develop text classification and sentiment analysis systems
- Create embedding-based similarity search for content matching
- Design A/B experiments to measure model impact
- Collaborate with engineering teams to productionize ML models
- Analyze large-scale user behavior data to derive insights',
'Required Qualifications:
- MS/PhD in Computer Science, Statistics, or related field
- 2+ years of experience in NLP and machine learning
- Strong proficiency in Python and ML frameworks (PyTorch, TensorFlow)
- Experience with text embeddings and similarity search
- Strong statistical analysis skills
- Experience with SQL and data analysis tools

Preferred Qualifications:
- Experience with recommendation systems
- Familiarity with LLMs and transformer architectures
- Experience with Apache Spark for large-scale data processing
- Experience with cloud platforms (AWS, GCP)
- Published research in NLP or recommendation systems',
2, 5, 'masters', 170000, 280000, 'full_time', 'mid', 1,
'https://jobs.netflix.com/data-scientist-nlp-44444',
'["python","pytorch","tensorflow","machine-learning","deep-learning","nlp","llms","sql","pandas","data-analysis","apache-spark","aws"]',
'Python,NLP,machine learning,PyTorch,TensorFlow,embeddings,recommendation,A/B testing,SQL,data science',
'active', '2025-03-01'),

(7, 'lever', 'DevOps Engineer', 'DevOps Engineer', 'Databricks', 'San Francisco', 'CA', 'remote',
'Databricks is hiring a DevOps Engineer to build and maintain the infrastructure powering our unified analytics platform. You will work on challenging infrastructure problems at massive scale.

Key Responsibilities:
- Build and maintain CI/CD pipelines for rapid deployment
- Manage Kubernetes clusters and container orchestration
- Implement infrastructure as code using Terraform
- Monitor and optimize cloud infrastructure (AWS, Azure, GCP)
- Automate operational tasks and incident response
- Ensure security compliance and best practices',
'Required Qualifications:
- 3+ years of DevOps/SRE experience
- Strong experience with Kubernetes and Docker
- Proficiency in Terraform or similar IaC tools
- Experience with at least one major cloud provider (AWS, GCP, Azure)
- Strong scripting skills (Python, Bash, Go)
- Experience with CI/CD tools (Jenkins, GitHub Actions)

Preferred Qualifications:
- Experience with multi-cloud environments
- Kubernetes certifications (CKA, CKAD)
- Experience with observability tools (Prometheus, Grafana, Datadog)
- Knowledge of security best practices and compliance
- Experience with database operations at scale',
3, 7, 'bachelors', 160000, 260000, 'full_time', 'mid', 0,
'https://databricks.com/careers/devops-engineer-55555',
'["kubernetes","docker","terraform","aws","gcp","azure","python","go","linux","cicd","jenkins","git","postgresql","redis"]',
'Kubernetes,Docker,Terraform,AWS,CI/CD,DevOps,infrastructure,automation,Python,Linux,monitoring',
'active', '2025-03-04'),

(8, 'greenhouse', 'AI Research Scientist', 'AI Research Scientist', 'Google DeepMind', 'Mountain View', 'CA', 'hybrid',
'Google DeepMind is looking for an AI Research Scientist to push the boundaries of artificial intelligence. You will conduct cutting-edge research in machine learning, with a focus on efficient model architectures and scaling.

Key Responsibilities:
- Conduct research on novel neural network architectures
- Develop efficient training methods for large-scale models
- Publish research in top-tier venues (NeurIPS, ICML, ICLR)
- Collaborate with engineering teams to implement research findings
- Mentor junior researchers and interns
- Contribute to the broader AI research community',
'Required Qualifications:
- PhD in Computer Science, Machine Learning, or related field
- Strong publication record in top ML venues
- Deep expertise in deep learning and neural network architectures
- Expert-level proficiency in Python and PyTorch/JAX
- Experience with large-scale distributed training
- Strong mathematical and analytical skills

Preferred Qualifications:
- Experience with transformer architectures and attention mechanisms
- Experience with model compression and efficiency
- Familiarity with TPU/GPU programming
- Experience with reinforcement learning
- Open-source contributions to ML frameworks',
3, 10, 'phd', 200000, 400000, 'full_time', 'senior', 1,
'https://deepmind.google/careers/ai-research-scientist-66666',
'["python","pytorch","tensorflow","machine-learning","deep-learning","nlp","llms","computer-vision","cpp","linux","data-analysis"]',
'research,deep learning,PyTorch,neural networks,NLP,transformer,machine learning,Python,publications,AI',
'active', '2025-02-25'),

(9, 'linkedin', 'Backend Engineer - Payments', 'Backend Engineer', 'Square', 'San Francisco', 'CA', 'hybrid',
'Square is looking for a Backend Engineer to join our Payments team. You will build reliable, scalable systems that process millions of transactions daily for businesses worldwide.

Key Responsibilities:
- Design and implement backend services for payment processing
- Build and maintain RESTful APIs and event-driven architectures
- Ensure system reliability and data consistency for financial transactions
- Optimize database performance and query efficiency
- Write comprehensive tests and documentation
- Collaborate with cross-functional teams on product development',
'Required Qualifications:
- 2+ years of backend development experience
- Proficiency in Java, Kotlin, or similar languages
- Experience with SQL databases (PostgreSQL, MySQL)
- Understanding of distributed systems concepts
- Experience with REST APIs and microservices
- Strong problem-solving and analytical skills

Preferred Qualifications:
- Experience with payment systems or fintech
- Experience with event-driven architectures (Kafka, RabbitMQ)
- Knowledge of Docker and Kubernetes
- Experience with Redis or other caching solutions
- AWS or GCP experience',
2, 6, 'bachelors', 140000, 220000, 'full_time', 'mid', 0,
'https://squareup.com/careers/backend-engineer-payments-77777',
'["java","kotlin","python","postgresql","mysql","redis","docker","kubernetes","aws","rest-apis","microservices","git","sql","cicd"]',
'Java,Kotlin,PostgreSQL,payments,backend,REST API,microservices,distributed systems,SQL,Redis',
'active', '2025-03-06'),

(10, 'indeed', 'React Native Developer', 'React Native Developer', 'Airbnb', 'San Francisco', 'CA', 'remote',
'Airbnb is hiring a React Native Developer to build beautiful, performant mobile experiences for our global travel platform used by millions of guests and hosts worldwide.

Key Responsibilities:
- Build cross-platform mobile features using React Native
- Collaborate with designers to implement pixel-perfect UIs
- Optimize app performance and user experience
- Write reusable components and shared libraries
- Integrate with backend APIs and real-time services
- Participate in code reviews and contribute to technical standards',
'Required Qualifications:
- 3+ years of mobile development experience
- Strong proficiency in React Native and TypeScript
- Expert knowledge of React and its ecosystem
- Experience with state management (Redux, MobX, or Zustand)
- Understanding of mobile app performance optimization
- Experience with REST APIs and GraphQL

Preferred Qualifications:
- Experience with native iOS (Swift) or Android (Kotlin) development
- Experience with animation libraries (Reanimated, Lottie)
- Knowledge of CI/CD for mobile apps
- Experience with Figma and design collaboration
- Published apps on App Store or Google Play',
3, 6, 'bachelors', 150000, 240000, 'full_time', 'mid', 1,
'https://airbnb.com/careers/react-native-developer-88888',
'["javascript","typescript","react","nodejs","html-css","graphql","figma","swift","kotlin","git","cicd","rest-apis"]',
'React Native,TypeScript,React,mobile,iOS,Android,JavaScript,GraphQL,performance,UI/UX',
'active', '2025-03-04'),

(11, 'greenhouse', 'Senior Data Engineer', 'Senior Data Engineer', 'Snowflake', 'San Mateo', 'CA', 'hybrid',
'Snowflake is seeking a Senior Data Engineer to build the data infrastructure powering our cloud data platform. You will design and implement data pipelines processing petabytes of data daily.

Key Responsibilities:
- Design and build scalable data pipelines and ETL processes
- Implement real-time and batch data processing systems
- Optimize data warehouse performance and query efficiency
- Build data quality monitoring and validation frameworks
- Collaborate with data scientists and analysts on data needs
- Ensure data security and compliance',
'Required Qualifications:
- 4+ years of data engineering experience
- Expert-level SQL skills
- Strong experience with Apache Spark and data processing frameworks
- Proficiency in Python or Scala
- Experience with cloud data warehouses (Snowflake, BigQuery, Redshift)
- Experience with workflow orchestration (Airflow, Dagster)

Preferred Qualifications:
- Experience with real-time streaming (Kafka, Kinesis)
- Knowledge of data modeling and warehouse design
- Experience with dbt or similar transformation tools
- AWS, GCP, or Azure certifications
- Experience with data governance and quality frameworks',
4, 8, 'bachelors', 170000, 270000, 'full_time', 'senior', 1,
'https://snowflake.com/careers/senior-data-engineer-99999',
'["python","sql","apache-spark","aws","gcp","postgresql","docker","kubernetes","data-analysis","rest-apis","git","cicd"]',
'SQL,Apache Spark,Python,ETL,data pipeline,Snowflake,AWS,data engineering,Kafka,Airflow',
'active', '2025-03-02'),

(12, 'lever', 'Security Engineer', 'Security Engineer', 'CrowdStrike', 'Austin', 'TX', 'remote',
'CrowdStrike is hiring a Security Engineer to help protect organizations worldwide from cyber threats. You will build and maintain security systems that defend against sophisticated adversaries.

Key Responsibilities:
- Design and implement security monitoring and detection systems
- Conduct security reviews and penetration testing
- Build automated security scanning tools and pipelines
- Respond to security incidents and conduct forensic analysis
- Develop security policies and best practices
- Collaborate with engineering teams on secure development practices',
'Required Qualifications:
- 3+ years of cybersecurity experience
- Experience with security tools (SIEM, IDS/IPS, EDR)
- Strong scripting skills in Python
- Knowledge of network security and protocols
- Experience with Linux system administration
- Understanding of cloud security (AWS, GCP, Azure)

Preferred Qualifications:
- Security certifications (CISSP, OSCP, CEH)
- Experience with threat hunting and incident response
- Experience with container security (Docker, Kubernetes)
- Knowledge of compliance frameworks (SOC 2, ISO 27001)
- Experience with Go or Rust for security tooling',
3, 7, 'bachelors', 140000, 230000, 'full_time', 'mid', 0,
'https://crowdstrike.com/careers/security-engineer-10101',
'["python","cybersecurity","linux","aws","docker","kubernetes","go","rust","cicd","git"]',
'cybersecurity,security,Python,Linux,AWS,incident response,SIEM,threat detection,cloud security',
'active', '2025-03-03');

-- ============================================================
-- Job Skills Mappings
-- ============================================================

-- Job 1: Google Senior SWE
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(1, (SELECT id FROM skills WHERE canonical_name='go'), 'required'),
(1, (SELECT id FROM skills WHERE canonical_name='python'), 'required'),
(1, (SELECT id FROM skills WHERE canonical_name='java'), 'required'),
(1, (SELECT id FROM skills WHERE canonical_name='kubernetes'), 'preferred'),
(1, (SELECT id FROM skills WHERE canonical_name='docker'), 'preferred'),
(1, (SELECT id FROM skills WHERE canonical_name='microservices'), 'required'),
(1, (SELECT id FROM skills WHERE canonical_name='system-design'), 'required'),
(1, (SELECT id FROM skills WHERE canonical_name='gcp'), 'preferred'),
(1, (SELECT id FROM skills WHERE canonical_name='aws'), 'preferred'),
(1, (SELECT id FROM skills WHERE canonical_name='cicd'), 'preferred'),
(1, (SELECT id FROM skills WHERE canonical_name='rest-apis'), 'required'),
(1, (SELECT id FROM skills WHERE canonical_name='postgresql'), 'nice_to_have');

-- Job 2: OpenAI ML Engineer
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(2, (SELECT id FROM skills WHERE canonical_name='python'), 'required'),
(2, (SELECT id FROM skills WHERE canonical_name='pytorch'), 'required'),
(2, (SELECT id FROM skills WHERE canonical_name='tensorflow'), 'preferred'),
(2, (SELECT id FROM skills WHERE canonical_name='machine-learning'), 'required'),
(2, (SELECT id FROM skills WHERE canonical_name='deep-learning'), 'required'),
(2, (SELECT id FROM skills WHERE canonical_name='nlp'), 'required'),
(2, (SELECT id FROM skills WHERE canonical_name='llms'), 'required'),
(2, (SELECT id FROM skills WHERE canonical_name='aws'), 'preferred'),
(2, (SELECT id FROM skills WHERE canonical_name='docker'), 'preferred'),
(2, (SELECT id FROM skills WHERE canonical_name='data-analysis'), 'preferred');

-- Job 3: Meta Staff Frontend
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(3, (SELECT id FROM skills WHERE canonical_name='javascript'), 'required'),
(3, (SELECT id FROM skills WHERE canonical_name='typescript'), 'required'),
(3, (SELECT id FROM skills WHERE canonical_name='react'), 'required'),
(3, (SELECT id FROM skills WHERE canonical_name='nextjs'), 'required'),
(3, (SELECT id FROM skills WHERE canonical_name='html-css'), 'required'),
(3, (SELECT id FROM skills WHERE canonical_name='tailwindcss'), 'preferred'),
(3, (SELECT id FROM skills WHERE canonical_name='graphql'), 'preferred'),
(3, (SELECT id FROM skills WHERE canonical_name='nodejs'), 'preferred'),
(3, (SELECT id FROM skills WHERE canonical_name='figma'), 'preferred'),
(3, (SELECT id FROM skills WHERE canonical_name='cicd'), 'nice_to_have'),
(3, (SELECT id FROM skills WHERE canonical_name='git'), 'required');

-- Job 4: AWS Cloud Infra
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(4, (SELECT id FROM skills WHERE canonical_name='aws'), 'required'),
(4, (SELECT id FROM skills WHERE canonical_name='kubernetes'), 'required'),
(4, (SELECT id FROM skills WHERE canonical_name='docker'), 'required'),
(4, (SELECT id FROM skills WHERE canonical_name='terraform'), 'required'),
(4, (SELECT id FROM skills WHERE canonical_name='python'), 'required'),
(4, (SELECT id FROM skills WHERE canonical_name='linux'), 'required'),
(4, (SELECT id FROM skills WHERE canonical_name='cicd'), 'preferred'),
(4, (SELECT id FROM skills WHERE canonical_name='jenkins'), 'preferred'),
(4, (SELECT id FROM skills WHERE canonical_name='postgresql'), 'nice_to_have'),
(4, (SELECT id FROM skills WHERE canonical_name='redis'), 'nice_to_have'),
(4, (SELECT id FROM skills WHERE canonical_name='microservices'), 'preferred'),
(4, (SELECT id FROM skills WHERE canonical_name='git'), 'required');

-- Job 5: Stripe Full Stack
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(5, (SELECT id FROM skills WHERE canonical_name='python'), 'required'),
(5, (SELECT id FROM skills WHERE canonical_name='go'), 'preferred'),
(5, (SELECT id FROM skills WHERE canonical_name='java'), 'preferred'),
(5, (SELECT id FROM skills WHERE canonical_name='react'), 'required'),
(5, (SELECT id FROM skills WHERE canonical_name='typescript'), 'required'),
(5, (SELECT id FROM skills WHERE canonical_name='javascript'), 'required'),
(5, (SELECT id FROM skills WHERE canonical_name='postgresql'), 'required'),
(5, (SELECT id FROM skills WHERE canonical_name='docker'), 'preferred'),
(5, (SELECT id FROM skills WHERE canonical_name='aws'), 'preferred'),
(5, (SELECT id FROM skills WHERE canonical_name='rest-apis'), 'required'),
(5, (SELECT id FROM skills WHERE canonical_name='microservices'), 'preferred'),
(5, (SELECT id FROM skills WHERE canonical_name='git'), 'required'),
(5, (SELECT id FROM skills WHERE canonical_name='nodejs'), 'preferred');

-- Job 6: Netflix Data Scientist NLP
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(6, (SELECT id FROM skills WHERE canonical_name='python'), 'required'),
(6, (SELECT id FROM skills WHERE canonical_name='pytorch'), 'required'),
(6, (SELECT id FROM skills WHERE canonical_name='tensorflow'), 'preferred'),
(6, (SELECT id FROM skills WHERE canonical_name='machine-learning'), 'required'),
(6, (SELECT id FROM skills WHERE canonical_name='deep-learning'), 'required'),
(6, (SELECT id FROM skills WHERE canonical_name='nlp'), 'required'),
(6, (SELECT id FROM skills WHERE canonical_name='llms'), 'preferred'),
(6, (SELECT id FROM skills WHERE canonical_name='sql'), 'required'),
(6, (SELECT id FROM skills WHERE canonical_name='pandas'), 'preferred'),
(6, (SELECT id FROM skills WHERE canonical_name='data-analysis'), 'required'),
(6, (SELECT id FROM skills WHERE canonical_name='apache-spark'), 'preferred'),
(6, (SELECT id FROM skills WHERE canonical_name='aws'), 'nice_to_have');

-- Job 7: Databricks DevOps
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(7, (SELECT id FROM skills WHERE canonical_name='kubernetes'), 'required'),
(7, (SELECT id FROM skills WHERE canonical_name='docker'), 'required'),
(7, (SELECT id FROM skills WHERE canonical_name='terraform'), 'required'),
(7, (SELECT id FROM skills WHERE canonical_name='aws'), 'required'),
(7, (SELECT id FROM skills WHERE canonical_name='gcp'), 'preferred'),
(7, (SELECT id FROM skills WHERE canonical_name='azure'), 'preferred'),
(7, (SELECT id FROM skills WHERE canonical_name='python'), 'required'),
(7, (SELECT id FROM skills WHERE canonical_name='go'), 'preferred'),
(7, (SELECT id FROM skills WHERE canonical_name='linux'), 'required'),
(7, (SELECT id FROM skills WHERE canonical_name='cicd'), 'required'),
(7, (SELECT id FROM skills WHERE canonical_name='jenkins'), 'preferred'),
(7, (SELECT id FROM skills WHERE canonical_name='git'), 'required'),
(7, (SELECT id FROM skills WHERE canonical_name='postgresql'), 'nice_to_have'),
(7, (SELECT id FROM skills WHERE canonical_name='redis'), 'nice_to_have');

-- Job 8: DeepMind Research Scientist
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(8, (SELECT id FROM skills WHERE canonical_name='python'), 'required'),
(8, (SELECT id FROM skills WHERE canonical_name='pytorch'), 'required'),
(8, (SELECT id FROM skills WHERE canonical_name='tensorflow'), 'preferred'),
(8, (SELECT id FROM skills WHERE canonical_name='machine-learning'), 'required'),
(8, (SELECT id FROM skills WHERE canonical_name='deep-learning'), 'required'),
(8, (SELECT id FROM skills WHERE canonical_name='nlp'), 'required'),
(8, (SELECT id FROM skills WHERE canonical_name='llms'), 'required'),
(8, (SELECT id FROM skills WHERE canonical_name='computer-vision'), 'preferred'),
(8, (SELECT id FROM skills WHERE canonical_name='cpp'), 'preferred'),
(8, (SELECT id FROM skills WHERE canonical_name='linux'), 'preferred'),
(8, (SELECT id FROM skills WHERE canonical_name='data-analysis'), 'preferred');

-- Job 9: Square Backend
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(9, (SELECT id FROM skills WHERE canonical_name='java'), 'required'),
(9, (SELECT id FROM skills WHERE canonical_name='kotlin'), 'preferred'),
(9, (SELECT id FROM skills WHERE canonical_name='python'), 'preferred'),
(9, (SELECT id FROM skills WHERE canonical_name='postgresql'), 'required'),
(9, (SELECT id FROM skills WHERE canonical_name='mysql'), 'preferred'),
(9, (SELECT id FROM skills WHERE canonical_name='redis'), 'preferred'),
(9, (SELECT id FROM skills WHERE canonical_name='docker'), 'preferred'),
(9, (SELECT id FROM skills WHERE canonical_name='kubernetes'), 'nice_to_have'),
(9, (SELECT id FROM skills WHERE canonical_name='aws'), 'preferred'),
(9, (SELECT id FROM skills WHERE canonical_name='rest-apis'), 'required'),
(9, (SELECT id FROM skills WHERE canonical_name='microservices'), 'required'),
(9, (SELECT id FROM skills WHERE canonical_name='git'), 'required'),
(9, (SELECT id FROM skills WHERE canonical_name='sql'), 'required'),
(9, (SELECT id FROM skills WHERE canonical_name='cicd'), 'preferred');

-- Job 10: Airbnb React Native
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(10, (SELECT id FROM skills WHERE canonical_name='javascript'), 'required'),
(10, (SELECT id FROM skills WHERE canonical_name='typescript'), 'required'),
(10, (SELECT id FROM skills WHERE canonical_name='react'), 'required'),
(10, (SELECT id FROM skills WHERE canonical_name='nodejs'), 'preferred'),
(10, (SELECT id FROM skills WHERE canonical_name='html-css'), 'required'),
(10, (SELECT id FROM skills WHERE canonical_name='graphql'), 'preferred'),
(10, (SELECT id FROM skills WHERE canonical_name='figma'), 'preferred'),
(10, (SELECT id FROM skills WHERE canonical_name='swift'), 'preferred'),
(10, (SELECT id FROM skills WHERE canonical_name='kotlin'), 'preferred'),
(10, (SELECT id FROM skills WHERE canonical_name='git'), 'required'),
(10, (SELECT id FROM skills WHERE canonical_name='cicd'), 'preferred'),
(10, (SELECT id FROM skills WHERE canonical_name='rest-apis'), 'required');

-- Job 11: Snowflake Data Engineer
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(11, (SELECT id FROM skills WHERE canonical_name='python'), 'required'),
(11, (SELECT id FROM skills WHERE canonical_name='sql'), 'required'),
(11, (SELECT id FROM skills WHERE canonical_name='apache-spark'), 'required'),
(11, (SELECT id FROM skills WHERE canonical_name='aws'), 'required'),
(11, (SELECT id FROM skills WHERE canonical_name='gcp'), 'preferred'),
(11, (SELECT id FROM skills WHERE canonical_name='postgresql'), 'preferred'),
(11, (SELECT id FROM skills WHERE canonical_name='docker'), 'preferred'),
(11, (SELECT id FROM skills WHERE canonical_name='kubernetes'), 'nice_to_have'),
(11, (SELECT id FROM skills WHERE canonical_name='data-analysis'), 'required'),
(11, (SELECT id FROM skills WHERE canonical_name='rest-apis'), 'preferred'),
(11, (SELECT id FROM skills WHERE canonical_name='git'), 'required'),
(11, (SELECT id FROM skills WHERE canonical_name='cicd'), 'preferred');

-- Job 12: CrowdStrike Security
INSERT OR IGNORE INTO job_skills (job_id, skill_id, importance) VALUES
(12, (SELECT id FROM skills WHERE canonical_name='python'), 'required'),
(12, (SELECT id FROM skills WHERE canonical_name='cybersecurity'), 'required'),
(12, (SELECT id FROM skills WHERE canonical_name='linux'), 'required'),
(12, (SELECT id FROM skills WHERE canonical_name='aws'), 'required'),
(12, (SELECT id FROM skills WHERE canonical_name='docker'), 'preferred'),
(12, (SELECT id FROM skills WHERE canonical_name='kubernetes'), 'preferred'),
(12, (SELECT id FROM skills WHERE canonical_name='go'), 'preferred'),
(12, (SELECT id FROM skills WHERE canonical_name='rust'), 'nice_to_have'),
(12, (SELECT id FROM skills WHERE canonical_name='cicd'), 'preferred'),
(12, (SELECT id FROM skills WHERE canonical_name='git'), 'required');
